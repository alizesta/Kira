# ARCHITECTURE — Project Kira

> آخرین به‌روزرسانی: 2026-11-10 23:28 IRST · استخراج‌شده از سورس (نه حدس). اگر با کد فرق داشت، کد درست است.
> برچسب‌ها: ✅ کد موجود و تست واحد دارد (لینوکس) · ⚠️ `IMPLEMENTED_UNTESTED` روی ویندوز/GUI/سرویس واقعی.

## ۱. اصل‌های ثابت
- **Provider-independent:** مدل فقط متن می‌بیند؛ هر Provider پشت `HybridRouter.chat_stream` است. پروتکل ابزار متنی است (`<kira_tool>{...}</kira_tool>`)؛ function calling بومی فقط روی Groq/Mistral/Google به همان پروتکل ترجمه می‌شود و در رد سرویس به متن برمی‌گردد.
- **امنیت در کد، نه در اعتماد به مدل.** مدل هرگز ابزار حساس را خودش اجرا نمی‌کند؛ تصمیم دسترسی فقط در `AccessManager` است.
- **حالت وظیفه، حافظه و تجربه بیرون از مدل** (فایل/SQLite در `DATA_DIR`)، پس عوض‌شدن Route/Provider چیزی را گم نمی‌کند.
- **هر لایه‌ی کمکی فقط «توصیه» می‌کند** (brain hint، experience hint، planner lint، skill): هیچ‌کدام مجوز/تأیید/`intent_rx` را دور نمی‌زنند و همه خطاهایشان را قورت می‌دهند (خطای کمکی ≠ خرابی چت).
- ماژول‌های منطقی (routes، api_manager، brain، tasks، experience، usage …) **بدون Qt** و جدا از UI تست می‌شوند.

## ۲. جریان یک پیام (از `main.py`)
```
MainWindow.send_message                      (main.py ~2692)
  ├─ دستورهای محلی: /usage /web /research /img …، handle_task_command (توقف/ادامه/لغو)، handle_confirmation_reply
  ├─ tool_agent.plan(text)  → ToolPlan | None      (protocol.detect_categories + دروازه‌ها)
  │     └─ AutonomyMixin.decide: ادغام وضعیت وظیفه + planner.assess → complex?
  └─ start_worker (~2949)
        ├─ brain.decide(...)  → Decision(stage=surface|deep, route_id, reasons)
        ├─ smart.best_route_id(...)  (فقط راهنمای «اول کدام route»؛ route دستی نقش‌ها برنده است)
        ├─ brain.extend_prompt(...) + حافظه (persona_memory.build_block → evidence_memory) + modes.mode_block + mood
        └─ StreamWorker(QThread)  → router.role_scope(role, route_id)
              ├─ ToolAgent.run → plan.complex ? run_planned (autonomy) : _run_simple
              └─ بدون ابزار: router.chat_stream مستقیم
  on_stream_done (~3235) → ذخیره‌ی پاسخ، TTS، brain.after_turn، experience.flush (از مسیر ابزار)
```

## ۳. اجزای اصلی و ارتباطشان

### Hybrid Brain = `hybrid_ai.py` + `routes.py` + `brain.py` + `smart.py` ✅
- **`routes.py`** — Provider (اتصال/کلید) جدا از Route (یک مدل روی یک Provider). ترتیب فهرست `settings["routes"]` همان اولویت/Failover است. مهاجرت خودکار تنظیمات قدیمی (بدون `routes`).
- **`HybridRouter`** — `_candidates()` ترتیب امتحان را می‌سازد: route ترجیحیِ نقش ← route دستی (`manual_route_id`) ← ترتیب اولویت (اگر `failover_enabled`). `_mark_success/_mark_failure` + cooldown (پیش‌فرض 45s) + متریک سرعت + `role` در متریک. **Failover فقط قبل از اولین توکن**؛ بعد از شروع متن، قطع ارتباط = پاسخ «interrupted» (هرگز تکرار نمی‌شود). `role_scope(role, route_id)` یک context manager است.
- **Providerها:** Groq، Mistral، OpenRouter، Custom OpenAI-compatible (`OpenAICompatibleProvider`)، Cloudflare، Ollama (`ollama_client.py`). `LeakGuard` (`leak_guard.py`) متن داخلی مدل (think/Harmony/پیش‌گفتار انگلیسی) را از خروجی همه‌ی Providerها حذف می‌کند؛ **تا 48 نویسه‌ی اول را بافر می‌کند** تا بتواند تصمیم بگیرد. پس «اولین توکن» برای Failover یعنی اولین متنی که واقعاً به کاربر نمایش داده شد؛ قطع ارتباط وقتی هنوز چیزی نمایش داده نشده به route بعدی می‌رود. **قاعده‌ی یکپارچه:** آنچه نگه داشته/ذخیره می‌شود دقیقاً همان است که به کاربر نمایش داده شد — Stop (`cancel()` ← `abort()` بستن HTTP؛ بدون جریمه‌ی route)، قطع ارتباط وسط پاسخ (`interrupted`، بدون تکرار/failover) و بستن پنجره (`closeEvent` متن روی صفحه را ذخیره می‌کند) همگی از آن پیروی می‌کنند؛ متن کمتر از 48 نویسه‌ی بافرشده هرگز نمایش/ذخیره نمی‌شود. تست‌هایی که باید «متن دیده‌شده» داشته باشند باید اولین chunk را ≥48 نویسه بفرستند (`tests/helpers.py: visible_partial`).
- **`brain.py`** — نقش‌ها: `surface` (مسیر عادی)، `deep` (پیام سنگین: برنامه‌ی چندگامی، وظیفه‌ی باز، تحلیل، ورودی بلند، کد، ضمیمه؛ route جدا + یک جمله‌ی اضافه در پرامپت، هرگز روی مدل محلی کوچک)، `reflection` (بعد از پاسخ؛ قواعد رایگان: ادعای کار بدون ابزار، پنهان‌کردن خطای ابزار، تناقض با واقعیت ذخیره‌شده؛ فقط یک hint برای **نوبت بعد**، پاسخ نمایش‌داده‌شده بازنویسی نمی‌شود)، `memory` (اختیاری، پیش‌فرض off). تنظیمات: `brain_mode`, `brain_reflection`, `brain_memory_writer`, `role_routes`. وضعیت: `kira_brain_state.json`.
- **`smart.py`** — `best_route_id` (قوی‌ترین مدل رایگان برای نوبت ابزار/عمیق؛ `smart_routing`)، `is_excuse` + `HoldEmit` (بهانه‌ی مدل با وجود ابزار ← یک retry بی‌صدا روی route بعدی)، اصلاح‌های کاربر (`kira_corrections.json`)، پروفایل مدل‌ها (`modelbench.py` → `kira_model_profiles.json`).
- **`usage.py`** — در `_finish` و مسیر شکست هر درخواست یک ردیف در `kira_usage.sqlite3`؛ محدودیت per-role/provider در `_candidates` (`warn|block`). توکن فقط اگر Provider گزارش کند.

### Route Manager / API Manager ✅(منطق) ⚠️(UI)
- `api_manager.py`: کاربر فقط کلید می‌زند؛ `detect()` از endpoint رسمی «list models» سرویس را تشخیص و اعتبارسنجی می‌کند، `register()` در `settings["providers"]` و `settings["routes"]` می‌نویسد (Route Engine دست‌نخورده)؛ `api_registry` هرگز کلید ندارد. `discovery.py` فهرست مدل هر Provider. UI تب Route داخل `main.py`. راهنما: `docs/ROUTE_MANAGER_GUIDE_FA.md`, `API_MANAGER_FA.md`.

### Agent (`tools/agent.py: ToolAgent`) ✅
- یک نوبت: درخواست ← (ابزار لازم؟) ← مدل بلوک ابزار می‌نویسد ← ابزار اجرا می‌شود ← **نتیجه‌ی واقعی** به مدل برمی‌گردد ← پاسخ نهایی. تاریخچه‌ی چت فقط پاسخ نهایی را می‌گیرد.
- قواعد در کد: ابزار سطح ۳/تأییدی را مدل اجرا نمی‌کند (فقط `needs_confirmation`؛ پیام «تأیید» خودِ کاربر همان آرگومان‌های ذخیره‌شده را یک‌بار و حداکثر ۵ دقیقه اجرا می‌کند)؛ فراخوانی یکسان در یک نوبت دوباره اجرا نمی‌شود؛ فراخوانی نیمه‌کاره (قطع اتصال) هرگز اجرا نمی‌شود؛ اگر مدل بعد از اجرای ابزار خراب شود، نتیجه‌ی واقعی به کاربر می‌رسد؛ `_honesty_footer`.
- `tools_block`: کاتالوگ ابزار فقط برای دسته‌های مرتبط (`protocol.detect_categories` / دروازه‌های `GATES`؛ دسته‌های `mcp` و `agents` فقط وقتی نامشان آمده) + hint تجربه + قواعد دسته (`MCP_RULES`، `DESKTOP_RULES`، `WEB_RULES`).

### Planner / Autonomy (`planner.py`, `autonomy.py`, `tasks.py`) ✅
- `planner.assess` تصمیم می‌گیرد پیام چندگامی است (فقط وقتی دسته‌ی PC تشخیص داده شده). مدل با یک بلوک `<kira_plan>` جواب می‌دهد؛ `planner.parse_plan` در کد اعتبارسنجی می‌کند: ابزار ناشناخته رد، ابزار حساس اجباراً `confirm`، سقف گام، وابستگی فقط به عقب.
- `run_planned` → `_planning_stage` → `_execute_loop`: گام‌ها یکی‌یکی از **همان registry** اجرا می‌شوند. سقف‌ها: `agent_max_steps` (پیش‌فرض 8؛ اجرای ابزار ≤ 2×)، `agent_max_replans` (3). همان فراخوانی ناموفق ≤ 2 بار؛ فراخوانی موفق هرگز دوباره؛ ابزار READ فقط برای خطای transient تکرار می‌شود.
- `TaskStore` وضعیت را در `kira_tasks.json` نگه می‌دارد (فقط خلاصه‌های ماسک‌شده؛ نه محتوای فایل/کلید). وضعیت‌های وظیفه: planning/running/waiting_user/waiting_confirm/paused/done/failed/cancelled/superseded. کنترل کاربر: توقف/ادامه/لغو.
- **`planner.lint`** (بدون مدل، حداکثر 4 یادداشت به `TASK STATE`، فیلد `checks`): ۱) گام اقدامی بدون بازخوانی که گام خواندنیِ بعدی چکش نمی‌کند؛ ۲) ابزاری که روی این PC دائماً شکست خورده؛ ۳) Skill تأییدشده‌ای که ابزارش در برنامه جا افتاده. فقط راهنما، چیزی را مسدود نمی‌کند.

### Verification (`tasks.verify`, `classify_error`, `set_verification`) ✅
- `verify(tool, args, status, text, *, level, verifies)` → `ok | unmet | unverified`. موارد: status غیر ok ← unmet؛ نتیجه‌ی خالی ← unmet؛ متن ابزار خودش «UNVERIFIED/تأیید نشد» ← unverified؛ `search_files`/`find_app` با «پیدا نشد» ← unmet؛ `open_app`/`open_url` بدون پنجره‌ی جدید ← unverified؛ ابزار اقدام (سطح ≥2) که `verifies_result` ندارد و خروجی‌اش نشانه‌ی بازخوانی (`VERIFIED`) ندارد ← unverified؛ خواندنی با 0 نتیجه ← ok ولی با یادداشت «چیزی پیدا نشد».
- سازوکار پایین‌دست: ابزار می‌تواند `access.set_verification(state)` بزند (فعلاً `close_app` و مسیر مرورگر `apps.browser_check` که پنجره‌های واقعی را بعد از `open_url` می‌خواند: matched/already/changed/none). `classify_error` → confirm/transient/missing/permanent.
- **محدودیت:** نتیجه‌ی یکنواخت `success/failed/partial/unknown` برای همه‌ی ابزارها وجود ندارد.

### ToolRegistry و Access (`registry.py`, `sysaccess.py`) ✅/⚠️
- `ToolRegistry.register/execute`: اعتبارسنجی/coerce آرگومان، clip نتیجه (پیش‌فرض 6000)، `redact_secrets`، قفل برای ثبت از thread پس‌زمینه (MCP)، `unregister_where`. `execute` هر فراخوانی را به `AccessManager` و `experience.observe` می‌دهد.
- **سطوح** (`sysaccess.py`): `READ`, `CONTROL`, `FILE`, `ELEVATED` (فقط از `elevation.py` با UAC برای همان یک عملیات؛ Kira هرگز Administrator نیست), `PROTECTED` (فقط وقتی پیام *فعلی* کاربر صریحاً همان را بخواهد؛ مثل kill اجباری، uninstall، Power). «سطح» و «نیاز به تأیید» دو مفهوم جدا هستند (`requires_confirmation`).
- **تأیید** به همان ابزار + آرگومان‌ها بسته است؛ یک‌بارمصرف، منقضی‌شونده، با Stop پاک می‌شود و داخل `execute` دوباره بررسی می‌شود. **Taint:** بعد از محتوای خارجی (وب/فایل/MCP/ایجنت) هر عملیات CONTROL/FILE بدون `intent_rx` تأیید می‌خواهد. **Journal** فقط در حافظه. هیچ Shell/PowerShell آزاد نیست؛ `winrunner.py` فقط اسکریپت‌های ثابت؛ `sysexe.py` فقط netsh/ping/pnputil با آرگومان ساخته‌ی کد. PowerShell فریز است (`POWERSHELL_FROZEN`، `docs/TECH_DEBT_FA.md`).
- ⚠️ توجه: docstring بالای `registry.py` هنوز سه سطح قدیمی READ/ACTION/SENSITIVE را شرح می‌دهد؛ مدل فعلی در `sysaccess.py` است (بدهی مستندسازی کوچک).
- مسیر فایل: `PathPolicy` (`access.py`) — پوشه‌های مجاز (Desktop/Documents/Downloads/Pictures/Videos/Music + `tools_allowed_paths`)، هرگز فایل‌های راز؛ حذف فقط به سطل بازیافت.

### Experience (`experience.py`) ✅(منطق) ⚠️(ویندوز)
- `registry.execute → experience.observe` هر فراخوانی؛ `AccessManager.begin_turn` / `ToolAgent._final` → `flush` یک Episode. جدول‌ها در `kira_experience.sqlite3`: episodes، lessons، skills، examples.
- **Lesson:** ابزار A با `error` واقعی شکست ← ابزار B همان حوزه موفق (همان نوبت). **Skill:** ترتیب نام ابزارها (۲–۶ ابزار متفاوت، همه موفق، بدون محتوای خارجی). **Example (few-shot):** هر فراخوانی نوبتِ کاملاً موفق با آرگومان‌های «امن». همه ابتدا `candidate`؛ بعد از ≥2 نوبت جدا (فاصله ≥60s) یا (برای example) بازخوانی توسط خود ابزار ← `verified`؛ نقض ≥ تأیید ← برگشت. نوبت tainted هیچ چیزی نمی‌سازد. به مدل فقط خطوط ساخته‌ی کد می‌رسد (`hints`, `example_lines`, `matching_skills`, `avoid_tools`). تنظیم: `experience_memory` auto|off. سقف‌ها: 1500 Episode، 150 درس، 60 مهارت.

### Memory (سه لایه) ✅
- `memory.py` — تاریخچه‌ی چت SQLite (backup چرخشی، قرنطینه‌ی فایل خراب، snapshot قبل از clear، import/merge).
- `storage.py` — مسیر `DATA_DIR`، مهاجرت (فقط کپی)، `backup_user_data(keep=7)`؛ پاک‌کردن پشتیبان‌های قدیمی با `_remove_tree` (پاک‌کردن read-only + تلاش مجدد؛ بی‌صدا شکست نمی‌خورد، پوشه‌ی گیرکرده در پشتیبان بعدی دوباره تلاش می‌شود).
- `persona_memory.py` — صدا/واقعیت/لحظه/عادت/خلاصه؛ `build_block(query, budget)` بلوک پرامپت را می‌سازد (fallback کامل به رفتار قبلی).
- `evidence_memory.py` — واقعیت فقط با **نقل‌قول واقعی** (substring بعد از نرمال‌سازی فارسی)؛ در غیر این‌صورت قرنطینه. Supersede/تناقض، BM25 + Embedding اختیاری (Ollama) + RRF. فایل: `kira_evidence.sqlite3`. واقعیت‌ها فقط از قواعد محلی استخراج می‌شوند؛ استخراج با مدل فقط از `brain` نقش `memory` (پیش‌فرض off).

### Web (`websearch.py`, `webintel/`, `tools/webtools.py`) ✅
- سریع: Tavily ← Gemini/Google ← DuckDuckGo، evidence check، بلوک شماره‌دار. تحقیق: `webintel.engine` چندجست‌وجو، خواندن امن صفحه (`netguard`: SSRF، سقف حجم/زمان/redirect، چک خروجی حریم‌خصوصی)، رتبه‌بندی/تازگی/اعتبار (`rank`)، گزارش با سطح اطمینان، `session` حافظه‌ی موقت قابل توقف/ادامه. **بدون هیچ فراخوانی مدل** برای خود تحقیق.

### MCP و ایجنت (`mcp/`) ✅
- `McpHub` از `kira_mcp.json` (فقط کاربر می‌نویسد) سرورها را در thread پس‌زمینه بالا می‌آورد و ابزار را `server__tool` ثبت می‌کند. سطح ابزار فقط از فایل کاربر (پیش‌فرض: SENSITIVE)؛ annotation سرور نادیده؛ سطح 1/2 فقط اگر پیام فعلی نام سرور را بیاورد. `AgentHub`/`JobStore` (`kira_jobs.json`): قرارداد HTTP `/health /ask /status /answer /stop`؛ `agent_ask`/`agent_answer` نقل‌قول کاربر می‌خواهند. `kira.mcp` فقط lazy از `ToolAgent.__init__` بار می‌شود (بدون چرخه‌ی import).

### Voice / Persona / Avatar ⚠️
- STT: `listener.py` + `vad.py` (باند گفتار، کف نویز، barge-in) → faster-whisper محلی یا `cloud_voice.py`. TTS: `voice.py` (Edge/ویندوز) یا Cloud؛ `speech_split.py` جمله‌به‌جمله‌ی استریم. Cloud Voice: هر Provider چند کلید، اولویت/Failover جدا برای STT و TTS، آخرش محلی.
- شخصیت (`personality.py`) → بلوک‌ها در system prompt؛ `modes.py` بلوک را در **انتهای** پرامپت می‌گذارد؛ `style_probe.py` «Kira ماندن» را می‌سنجد و پاسخ منحرف را به حافظه‌ی صدا نمی‌دهد.
- آواتار: `emotion/` (parser متادیتای احساس مدل ← director ← engine ← backend_png با `rig.py` soft-body) با داده‌ی `emotion_library/*.json`؛ `face.py` پلک/دهان.

## ۴. نقشه‌ی داده‌ها (همه در `DATA_DIR` = `%LOCALAPPDATA%\Kira`)
`settings.json` · `kira_memory.sqlite3` (چت) · `kira_persona_memory.json` · `kira_evidence.sqlite3` · `kira_experience.sqlite3` · `kira_usage.sqlite3` · `kira_brain_state.json` · `kira_tasks.json` · `kira_jobs.json` · `kira_mcp.json` · `kira_mood.json` · `kira_corrections.json` · `kira_model_profiles.json` · `kira_file_ops.json` (undo عامل فایل) · پشتیبان‌های چرخشی (`storage.py`). هیچ‌کدام در ZIP برنامه نیستند (تست `test_04b_no_user_data_shipped`).

## ۵. گراف وابستگی مهم (برای جلوگیری از import چرخه‌ای)
`config` ← `routes`, `personality`, `secret_store`, `storage` · `hybrid_ai` ← `routes`, `leak_guard`, `usage` (lazy) · `tools/protocol` ← `hybrid_ai.ThinkFilter` · `tools/planner` ← `protocol`, `hybrid_ai` · `tools/agent` ← `autonomy`, `planner`, `tasks`, `registry`, `experience`, `smart`, `imagetool`, `webintel.session` · `brain` ← `evidence_memory` (داخل تابع) · `main` ← همه.

## ۶. تغییر دادن چه چیزی کجاست؟
| می‌خواهم… | بروم سراغ |
|---|---|
| ابزار جدید | handler + `reg.register(Tool(...))` در `tools/builtin.py` (یا ماژول ویندوزی با `WindowsControlLayer`)؛ کلمات دروازه‌ی دسته در `tools/protocol.py (GATES)`؛ برچسب فارسی در `agent.py (TOOL_LABELS)`؛ هر عملیات جدید ویندوزی بدون Backend فریز PowerShell |
| سطح/تأیید یک ابزار | فقط اعلام در ماژول + `sysaccess.py`؛ سیستم مجوز موازی نساز |
| Provider/مدل جدید | `docs/ADD_PROVIDER_AND_MODEL_FA.md`، `hybrid_ai.provider_class`، `discovery.py`، `api_manager.py` |
| تنظیم جدید | کلید پیش‌فرض در `config.py: DEFAULTS` |
| رفتار Verification | `tasks.verify` + `tools/apps.py (browser_check)` |
| پرامپت/لحن | `personality.py`, `modes.py`, `strings.py` (متن UI) |

## T6-AppControl — کنترل برنامه‌ها (افزوده)
- `appindex.PathStore` (`app_paths.json`): نام نرمال‌شده → مسیر exe؛ هر `get` دوباره با `appcatalog.is_safe_exe` اعتبارسنجی می‌شود؛ PID هرگز ذخیره نمی‌شود.
- `apps._launch_plan`: ترتیب = مسیر ذخیره‌شده ← میان‌بر سالم ← Target تعمیرشده (`repair_missing_exe`: فقط زیر ریشه‌های نصب شناخته‌شده و با همان نام فایل) ← exe کشف‌شده ← جست‌وجوی پوشه‌ی نصب. پوشه هرگز هدف اجرا نیست. میان‌بر با Target مرده روش اجرا نیست.
- `_open_entry`: مسیر exe Process در حال اجرا (`_running_exe`) در `PATHS` ثبت می‌شود.
- `websearch.plan`: دستور محلی ویندوز بدون فعل جست‌وجو → بدون پیش‌جست‌وجو.
- `brain.check_reply`: `claim_close/open/admin_without_tool`.
