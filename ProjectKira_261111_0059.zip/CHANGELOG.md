# CHANGELOG — Project Kira

> آخرین به‌روزرسانی: 2026-11-11 00:59 IRST · جدیدترین مورد بالا.
> نسخه‌ی برنامه (`kira/config.py: VERSION`) = `"1 stable"`؛ تسک‌ها با برچسب (T0…T6-xxx، vN) شناخته می‌شوند.
> جزئیات کامل‌ترِ نسخه‌های v7–T6-Skills (جدول‌ها، چک‌لیست اعتبارسنجی ویندوز) در `docs/CHANGES_INTEGRATION_FA.md` است؛ این فایل خلاصه + فهرست مرجع است. **هر تسک جدید یک بخش تازه در بالای «تاریخچه» می‌گیرد.**

## قالب هر ورودی
`برچسب تسک — تاریخ` · فایل‌های جدید · فایل‌های تغییرکرده · حذف‌شده · رفتار · تست (نتیجه‌ی **واقعی** اجرا) · محدودیت‌ها/هشدار

---

## وضعیت تست‌ها

### ۱) اجرای واقعی روی ویندوز (گزارش کاربر، قبل از Win-Fix-1) — Windows 11 Build 26300، PySide6 6.12.0
`run_tests.bat`: **483 تست، 14 FAIL، 1 ERROR** (۱۵ مورد؛ همه در Win-Fix-1 بررسی شدند). این **تنها اجرای واقعی روی ویندوز** است؛ بعد از Win-Fix-1 هنوز روی ویندوز اجرا نشده.

### ۲) آخرین اجرای لینوکس (بعد از Win-Fix-1، Python 3.13، بدون PySide6)
دستور: `KIRA_DATA_DIR=<tmp> python3 -I -m unittest discover -s tests -t .`
**524 تست: OK، 0 failure، 0 error، 79 skipped** (78 تست GUI/PySide6 + 1 تست مخصوص ویندوز).
**اجرا نشده/آزموده نشده:** همه‌ی تست‌های GUI در محیط Claude (اصلاح‌های GUI فقط با تحلیل کد + بازتولید لایه‌ی Router تأیید شده‌اند)، همه‌ی فراخوانی‌های Win32/UIA/PowerShell/WinRT/UAC، Ollama و Providerهای ابریِ واقعی، صدا (TTS/STT واقعی)، `run_tests.bat` روی ویندوز بعد از این اصلاح‌ها.

---

## تاریخچه

### Neon UI Stage 3 — چت تعاملی و قالب‌بندی پیام‌ها — 2026-11-11
**دامنه:** UI-only؛ بدون تغییر در API/Provider، اولویت Route، ذخیره‌سازی چت، حافظه، صدا یا اجرای ابزار.

**فایل‌های تغییرکرده:**
- `kira/chat_render.py`: قالب‌بندی امن Markdown برای code fence، inline code، quote، heading و list؛ کنترل Copy با payload رمزگذاری‌شده‌ی URL-safe و escaping کامل HTML ورودی.
- `kira/main.py`: کنترل کلیک لینک Copy در کنار بازکردن لینک‌های معمولی؛ نشانگر متحرک انتظار/پردازش برای اتصال، انتظار، آپلود، failover و اجرای ابزار؛ اسکرول نرم پیام‌های جدید. در طول stream payload دکمه‌ی کپی ساخته نمی‌شود و فقط در flush نهایی اضافه می‌شود.
- `kira/theme.py`: استایل نشانگر پردازش، انتخاب متن و لینک‌های چت.
- `tests/test_chat_render.py`: تست قالب کد، escape، quote و round-trip متن Copy.
- `docs/UI_REDESIGN.md`, `PROJECT_CONTEXT.md`, `TASK_HANDOFF.md`: وضعیت UI و محدودیت‌های اعتبارسنجی به‌روز شد.

**تست واقعی:** `python3 -I -m unittest discover -s tests -t .` → **524 تست، OK، 79 skip، صفر failure/error**. `compileall` و چک whitespace نیز موفق.
**محدودیت:** PySide6 در محیط اجرا نصب نیست؛ تست‌های ویجت Qt و نمایش واقعی، کلیک Copy، انیمیشن و رفتار Windows 11 اجرا نشده‌اند و `IMPLEMENTED_UNTESTED` هستند.


### T6-AppControl — مدیریت برنامه‌ها، Process و System Tray — 2026-11-10
**علت‌ها (از سورس):** (۱) برنامه‌ی ناشناخته: میان‌بر Start Menu با Target خراب (`C:\\Users\\Programs\\...`) اولین روش اجرا بود و بدون جایگزین شکست می‌خورد؛ مسیر واقعی Process در حال اجرا هرگز خوانده/ذخیره نمی‌شد؛ پوشه با exe فرق گذاشته نمی‌شد. (۲) هیچ حافظه‌ی مسیر اجرایی نبود (فقط alias). (۳) «اند تسک/کیل» فارسی دروازه‌ی درخواست صریح `process_kill` را باز نمی‌کرد؛ پیام برنامه‌ی فقط‌Tray راهنمای عملی نداشت. (۴) `websearch.plan` دستورهای محلی («الان بازه؟») را می‌توانست به جست‌وجوی وب ببرد. (۵) `brain.check_reply` ادعای «بستم/بازش کردم/با ادمین زدم» بدون ابزار را نمی‌گرفت. (۶) Replan: فقط dedupe هم‌نوبت وجود دارد؛ پیام شکست روش‌های امتحان‌شده را فهرست می‌کند؛ حافظه‌ی شکست بین نوبت‌ها عمداً اضافه نشد (جلوگیری از مسدودشدن تلاش مجدد مجاز کاربر).
**فایل‌ها:** `kira/tools/appindex.py` (`PathStore`/`PATHS`: نام→مسیر exe، بدون PID، اعتبارسنجی مجدد در هر خواندن)، `appcatalog.py` (`known_roots`, `repair_missing_exe`, `exe_from_path`)، `apps.py` (`_launch_plan`، `broken_shortcut_targets`، `_running_exe`، `remember_app_path`، `_describe`)، `winmodules.py` + `agent.py` (ابزار `remember_app_path`)، `processes.py` (`KILL_RX`)، `appclose.py` (پیام Tray + `_pid_hint`)، `websearch.py` (`_LOCAL_CMD`)، `brain.py` (سه قاعده‌ی claim)، `protocol.py` (سه خط قانون)، `tests/test_app_control.py` (28 تست جدید).
**امنیت:** `PathPolicy`/Permission Guard/تأیید کاربر/دروازه‌ی صریح Kill دست‌نخورده؛ هیچ دستور Admin اضافه نشد؛ مسیر ذخیره‌شونده باید exe امن و (در تأیید دستی) زیر ریشه‌های نصب یا مطابق Process باشد.
**تست:** لینوکس 521 تست OK، 79 skip، 0 failure/error. **همه‌ی تست‌های جدید Mock هستند** (فایل‌های موقت واقعی ولی Process/Window/ShellExecute/.lnk شبیه‌سازی‌شده)؛ رفتار واقعی ویندوز تأیید نشده.
**محدودیت‌های واقعی:** ابزاری برای «Exit» از منوی Tray وجود ندارد (نیاز به UIA روی Tray)؛ جایگزین: `process_kill` با pid+name دقیق و تأیید کاربر. منشأ دقیق مسیر غلط `C:\\Users\\Programs` (داده‌ی میان‌بر یا parser) تأیید نشد. ناهمخوانی Windscribe با `Hss.Store.Client.exe` تأییدنشده. فراخوانی‌های `web_search` که خود مدل می‌زند تغییر نکرد (فقط پیش‌جست‌وجوی خودکار). چک‌لیست ویندوز: Opera GX با میان‌بر خراب → باز شود؛ بستن → باز کردن مجدد از مسیر ذخیره‌شده؛ Windscribe فقط‌Tray → پیام راهنما + `process_kill` با تأیید.

### Win-Fix-1 — بررسی و رفع ۱۵ مورد ناموفق `run_tests.bat` روی ویندوز — 2026-11-10
**ورودی:** گزارش واقعی ویندوز: 483 تست، 14 FAIL، 1 ERROR. **کد برنامه فقط در یک فایل تغییر کرد (`kira/storage.py`)؛ سیاست مسیرها/مجوزها (`access.py`, `sysaccess.py`, `fileagent.py`) دست‌نخورده است.**

| # | تست | علت واقعی (از سورس) | حکم | اصلاح |
|---|---|---|---|---|
| 1–7 | `test_file_agent`: append/batch/copy/create/delete_folder/organise/undo (FAIL) | روی ویندوز `tempfile` زیر `%LOCALAPPDATA%\Temp` می‌سازد و `PathPolicy._blocked_roots` درست آن را «پوشه‌ی سیستمی/AppData» می‌داند ← همه‌ی ابزارها `denied` | **تعارض تست با رفتار صحیح محصول** (fixture اشتباه) | تست |
| 8 | `test_catalog_gate_and_journal_persists` (ERROR) | همان؛ چون `create_file` رد شد، Journal خالی ماند و `.last()` = None | همان | تست |
| 9 | `test_closing_the_window_mid_answer_keeps_the_partial_reply` | متن جزئی تست ۱۱ نویسه بود؛ `LeakGuard` تا 48 نویسه بافر می‌کند ← روی صفحه نبود ← تا پایان gate (۵ ثانیه) نمایش داده نشد و پیام کامل ذخیره شد | تعارض تست با طراحی (متن نادیده هرگز ذخیره/نمایش داده نمی‌شود) | تست |
| 10 | `test_15_chat_end_to_end…` (GUI) | `main.start_worker` همیشه با `mode` می‌سازد ← `PRIORITY_BLOCK` اول پرامپت می‌آید؛ تست انتظار داشت پرامپت با هویت Kira شروع شود (رفتار قبل از Active Mode) | تست کهنه | تست |
| 11 | `test_stop_button_keeps_partial…` (GUI) | متن جزئی کوتاه (بافر LeakGuard) ← Stop قبل از دیده‌شدن متن عملاً کار نمی‌کرد؛ با پایان gate متن «نباید دیده شود» هم آمد | تعارض تست با طراحی | تست |
| 12 | `test_connection_lost_mid_answer…` (GUI) | متن جزئی 7 نویسه ← بافر ← «کاربر چیزی ندیده» ← failover/خطا و `count("بخش اول") == 0` | همان | تست |
| 13 | `test_text_appears_progressively…` (GUI) | چند حرف اول در بافر ← متن فقط بعد از پایان stream دیده شد، `w.busy` از قبل False | همان | تست |
| 14 | `test_04b_no_user_data_shipped` | `.venv` در پوشه‌ی برنامه **عمداً** هست (`install.bat` می‌سازد، `run_tests.bat` بدون آن اجرا نمی‌شود) ← این assertion روی ویندوز هرگز نمی‌توانست پاس شود. (باگ دوم: `samefile` روی `data/` ناموجود خطا می‌داد.) | تست اشتباه؛ **مسئله‌ی واقعی = ZIP Release نباید `.venv` داشته باشد** | تست + ساخت ZIP |
| 15 | `test_backup_rolls_and_is_consistent` (4 ≠ 3) | `backup_user_data` پوشه‌های قدیمی را با `shutil.rmtree(..., ignore_errors=True)` پاک می‌کرد ← هر خطای ویندوز (قفل موقت آنتی‌ویروس/ایندکس، فلگ read-only) بی‌صدا نادیده می‌ماند و سقف `keep` نقض می‌شد | **باگ محصول** (سخت‌گیری ناکافی). *علت دقیق قفل در اجرای ویندوز در دسترس نبود؛ مکانیزم با mock بازتولید شد* | کد + تست |

**فایل‌های تغییرکرده**
- `kira/storage.py`: `_remove_tree()` (+`_clear_readonly`) — پاک‌کردن با پاک‌کردن فلگ read-only و ۶ بار تلاش مجدد (۰٫۲۵ ثانیه فاصله)، فقط وقتی True که پوشه واقعاً رفته باشد؛ `backup_user_data` از آن استفاده می‌کند. پوشه‌ی پاک‌نشده در پشتیبان‌گیری بعدی دوباره تلاش می‌شود.
- `tests/test_file_agent.py`: `isolate_sandbox_from_the_real_system()` (متغیرهای محیطی APPDATA/LOCALAPPDATA/WINDIR/PROGRAMFILES/PROGRAMDATA به پوشه‌ای ساختگی داخل sandbox؛ و نام‌های اجداد خودِ temp از قاعده‌ی «نام پوشه‌ی حساس» کنار گذاشته می‌شوند). **قاعده‌های خود `PathPolicy` تغییر نکردند.** تست‌های جدید: `PathPolicyStillBlocksTests` (4: پوشه‌ی داده‌ی Kira داخل پوشه‌ی مجاز، AppData/Windows/ProgramFiles حتی اگر مجاز اضافه شوند، `.ssh`/password/id_rsa/.env/.bat/.exe، بیرون از ریشه/`..`/خود ریشه) و `UnpatchedPolicyTests` (2: مسیر دارای AppData، و temp واقعی ویندوز).
- `tests/helpers.py`: `GUARD_MIN_CHARS`, `visible_partial()` — متن جزئیِ ≥48 نویسه برای تست‌هایی که باید متن «دیده‌شده» داشته باشند.
- `tests/test_gui_routes.py`, `tests/test_chat_persistence.py`: سه + یک تست استریم با متن جزئیِ بلند؛ assertionها همان قصد قبلی را دارند.
- `tests/test_gui_offscreen.py`: تست ۱۵ ترتیب واقعی پرامپت را بررسی می‌کند (PRIORITY اول، هویت Kira کامل و بعد از آن).
- `tests/test_streaming.py`: ۳ تست جدید لایه‌ی Router — حد دقیق 47/48 نویسه؛ Stop وقتی متن هنوز در بافر است (چیزی نگه داشته/ذخیره نمی‌شود، route جریمه نمی‌شود)؛ «متن ذخیره‌شده = متن نمایش‌داده‌شده» بعد از قطع ارتباط.
- `tests/test_release.py`: `test_04b` فقط داده‌ی کاربر را بررسی می‌کند؛ `test_04c` (مجموعه‌ی فایل‌های Release هرگز `.venv`/`.uvboot`/cache/data ندارد)، `test_04d` (فیلتر روی درخت ساختگی). `SKIP_DIRS` شامل `.ruff_cache` و … شد.
- `tests/test_storage.py`: اتصال SQLite تست صریح بسته می‌شود؛ تست‌های جدید قفل موقت و فلگ read-only و گزارش صادقانه‌ی شکست پاک‌کردن.
- `tests/test_stability.py`: حد حافظه روی **دو پنجره‌ی ۳۰۰ درخواستی** (نشت واقعی در هر دو رشد می‌کند؛ `min` ملاک است). علت: اضافه شدن تست‌های جدید باعث شد realloc تک‌بلوکیِ ~۲MB جدول intern خود مفسر (در `pathlib`) در پنجره‌ی اندازه‌گیری بیفتد و تست را (روی لینوکس) بشکند؛ نشت ساختگی ۴KB/درخواست هنوز شناسایی می‌شود (آزموده شد).

**تحلیل یکپارچه‌ی Streaming / Stop / قطع ارتباط / ذخیره‌ی پاسخ ناقص (از سورس):** هر چهار رفتار روی یک قاعده سوارند: *«آنچه به کاربر نمایش داده شد = آنچه نگه داشته و ذخیره می‌شود»*. `LeakGuard` تا 48 نویسه بافر می‌کند (`hybrid_ai._execute`)؛ Stop (`cancel()` ← `abort()` ← بستن HTTP) و قطع ارتباط (`parts` غیرخالی ← `interrupted`، بدون failover) و بستن پنجره (`closeEvent` ← `_stream_text`) همگی فقط متن آزادشده را نگه می‌دارند؛ متن کمتر از 48 نویسه که نمایش داده نشده: Stop ← چیزی ذخیره نمی‌شود؛ قطع ارتباط ← failover (مستند در Tests-Fix). **هیچ باگ محصولی در این مسیر پیدا نشد؛ هر چهار تست GUI متن جزئیِ زیر آستانه می‌فرستادند.** بازتولید روی Router واقعی: متن ۱۰ نویسه‌ای قبل از پایان stream هیچ chunk تحویل نمی‌دهد؛ ≥48 نویسه فوراً تحویل می‌شود.
**بازتولید ۸ مورد File Agent روی لینوکس:** با `TMPDIR`/`LOCALAPPDATA`/`APPDATA` ساختگیِ شبیه ویندوز، فایل تست **قدیمی** دقیقاً همان 7 FAIL + 1 ERROR را می‌دهد و فایل جدید 16/16 پاس می‌شود.

**نتیجه‌ی تست‌ها (واقعی):** لینوکس: 493 تست، OK، 79 skip. **ویندوز/GUI بعد از این اصلاح‌ها اجرا نشده.** تعداد مورد انتظار روی ویندوز: حدود 496 تست (483 + 13 جدید؛ ویندوز از قبل ۳ تست بیشتر از لینوکس می‌شمرد).
**محدودیت‌ها:** ۵ تست GUI اصلاح‌شده (#9–#13) و `test_15` در محیط Claude قابل اجرا نبودند (PySide6 نیست)؛ فقط معادل Router و منطق پرامپت اجرا شد. علت دقیق قفل #15 روی ویندوز قطعی نیست (فرضیه‌ی قوی: قفل موقت فایل). ZIP Release بدون `.venv`/`.uvboot`/`__pycache__`/`.ruff_cache` ساخته می‌شود.

### Tests-Fix — رفع ۵ تست قدیمی قرمز — 2026-11-10
- **کد برنامه (`kira/`) تغییر نکرد.** فقط تست‌ها:
  - `tests/test_streaming.py`: سه تست با متن ۱–۲ حرفی نوشته شده بودند ولی `LeakGuard` عمداً متن کوتاه‌تر از 48 نویسه را تا تصمیم‌گیری بافر می‌کند (تشخیص پیش‌گفتار تحلیل داخلی). تست‌ها با اولین chunk بلند (≥48) اصلاح شدند (ثابت‌های `LONG`, `LONG_FA`). **تست جدید:** `test_connection_lost_while_text_is_still_held_back_fails_over_because_nothing_was_shown` (قطع ارتباط وقتی متن هنوز در بافر است ← کاربر چیزی ندیده، پس failover مجاز است و چیزی تکرار نمی‌شود).
  - `tests/test_release.py`: `requirements.txt` حالا `{pyside6, requests, numpy, psutil}` را انتظار دارد (psutil عمداً اختیاری اضافه شده).
  - `tests/test_image_search.py`: `BubbleTests` بدون PySide6 skip می‌شود (مثل بقیه‌ی تست‌های GUI) به‌جای ERROR.
- **نتیجه‌ی واقعی:** 480 تست OK، 78 skip. روی ویندوز/GUI آزموده نشده.
- **نتیجه‌ی رفتاری که تست‌ها حالا مستند می‌کنند:** failover «فقط قبل از اولین توکن» دقیقاً یعنی «قبل از اولین متنی که به کاربر نمایش داده شد»؛ متن کمتر از 48 نویسه که فقط در بافر LeakGuard بوده و با قطع ارتباط از دست می‌رود، دوباره از route بعدی پرسیده می‌شود.

### Docs-1 — ایجاد مستندات مرکزی — 2026-11-10
- **فایل‌های جدید (ریشه):** `PROJECT_CONTEXT.md`, `ARCHITECTURE.md`, `CHANGELOG.md`, `TASK_HANDOFF.md`.
- **کد:** هیچ فایل `.py` تغییر نکرد. هیچ تستی اضافه نشد.
- **روش:** از سورس واقعی استخراج شد (docstringها، AST، ساخت واقعی `build_registry` برای شمارش ابزارها، اجرای کل تست‌ها).
- **شمارش‌های تأییدشده:** 117 ابزار داخلی؛ 38 فایل تست (479 تست در آن زمان؛ اکنون 480)؛ ~32.8k خط Python.
- **کشف‌ها (در این فایل ثبت شد):** نبودِ ورودی برای کارهای بعد از T6-Skills در فایل تغییرات قدیمی (بخش «کارهای ثبت‌نشده» پایین)؛ docstring قدیمی `registry.py`.

### T6-Verify — ارتقای Verification، Planner-lint، few-shot، retry «بهانه»، تأیید مرورگر (وضعیت ZIP فعلی)
> این بخش از **سورس و تست‌ها بازسازی** شده؛ ورودی رسمی‌اش در `CHANGES_INTEGRATION_FA.md` نبود (فقط «گام ۴» در `docs/EXPERIENCE_FA.md` هست). فهرست دقیق فایل‌های ویرایش‌شده در آن تسک **قابل استخراج نیست** (diff در دست نیست)؛ فقط آنچه در کد و تست‌ها موجود است ثبت می‌شود. **تعلق هر مورد به همین تسک قطعی نیست:** «Verification/lint/few-shot» در `EXPERIENCE_FA.md` به‌عنوان «گام ۴» آمده؛ مواردِ native tools، retry بهانه، `browser_check` و `fixes_1109` در هیچ مستندی تاریخ ندارند و فقط می‌دانیم **در این ZIP وجود دارند**.
- **Verification** (`tools/tasks.py: verify`) پارامترهای `level` و `verifies` گرفت؛ حالت `unverified` برای اقدام بدون بازخوانی، متن «UNVERIFIED» ابزار، و `open_app/open_url` بدون پنجره‌ی جدید. فراخوانی قدیمی سازگار. تست: `tests/test_verify_planner.py` (15)، `tests/test_verify_goal.py` (7).
- **Planner-lint** (`tools/planner.py: lint`): حداکثر 4 یادداشت؛ فیلد `checks` در `kira_tasks.json` (فایل قدیمی هم بارگذاری می‌شود).
- **تأیید مرورگر** (`tools/apps.py: browser_check / browser_report`): بعد از `open_url` پنجره‌های واقعی مرورگر خوانده می‌شوند (matched/already/changed/none).
- **few-shot Example** (`experience.py: _learn_examples / example_lines`): جدول `examples`، فقط وقتی verified به prompt می‌رسد. تست: `tests/test_fewshot_retry.py` (8).
- **Retry بی‌صدای «بهانه»** (`smart.is_excuse`, `HoldEmit`; اتصال در `agent._run_simple`): اگر مدل با وجود ابزار بهانه بیاورد، یک بار روی بهترین route بعدی تکرار می‌شود؛ بهانه‌ی دوم صادقانه نمایش داده می‌شود.
- **Function calling بومی** (`hybrid_ai`: `native_tools`, `native_tools_for`، تنظیم `native_tools` = auto|off) روی Groq/Mistral/Google؛ ترجمه به پروتکل `<kira_tool>`؛ رد سرویس ← بازگشت به متن. تست: `tests/test_native_tools.py` (7).
- **اصلاحات 1109** (`tests/test_fixes_1109.py`): تشخیص کلید Google جدید، pseudo-call → call واقعی، متن تگ احساس ≠ call، `saved_path`، نام مرورگرها، دروازه‌ی Edge.
- **نتیجه‌ی تست:** در زمان ثبت ۵ شکست/خطای قدیمی داشت (بعداً در Tests-Fix رفع شد). هشدار: روی ویندوز واقعی آزموده نشده.

### T6-Skills — Skill Library
جدول `skills` در `experience.py`؛ `tests/test_experience.py` (13). گزارش تست آن زمان: 427 تست، ۵ شکست قدیمی. جزئیات: `CHANGES_INTEGRATION_FA.md`، `docs/EXPERIENCE_FA.md`.

### T6-Experience — حافظه‌ی تجربی
ماژول جدید `kira/experience.py`؛ تغییر: `tools/registry.py`, `tools/sysaccess.py`, `tools/agent.py`, `config.py` (`experience_memory`). فقط بررسی ایستا آن زمان.

### T6-GIF — ساخت GIF
بدون ماژول/ابزار جدید: `imagegen.py` (Pillow)، `tools/imagetool.py` (`frames` 1–8, `motion`, `duration_ms`, `ping_pong`)، `protocol.py`, `agent.py`، docs. ساخت واقعی GIF آزموده نشده.

### T6-ToolFix — اطمینان ابزارها
جدید: `tools/appclose.py` (`close_app`). تغییر: `winrunner.py` (مسیر واقعی PowerShell: Sysnative/System32/SysWOW64، خطاهای جداشده، CLIXML)، `protocol.py` (دروازه‌ی وب گسترده + `WEB_RULES`)، `apps.py` (گارد باز/بستن)، `builtin.py`, `agent.py`. فقط `py_compile`؛ روی ویندوز آزموده نشده.

### v14 — T5-B: تعامل با دسکتاپ
`tools/desktop.py` (+ `tests/test_desktop.py`، 14 تست با Backend جعلی). Win32/UIA واقعی آزموده نشده.

### v13 — T5-A: عامل فایل
`tools/fileagent.py` (+ `tests/test_file_agent.py`، 10). حذف همیشه به سطل بازیافت.

### v12 — یکپارچه‌سازی T0–T4
ممیزی import (بدون چرخه)، اصلاح ۸ مورد (پلنر/MCP، `brain.check_reply`، `_small_context`، embedding محلی در دفتر مصرف، `agent_ask`، کلید `model_prices`، pipe های MCP، حذف ارجاع پروژه‌ی مرجع). `tests/test_integration_t0_t4.py` (27).

### v11 — T4: مصرف و هزینه — `usage.py`، دستور `/usage`.
### v10 — T3: MCP و ایجنت‌های مستقل — `kira/mcp/*`.
### v9 — T2: مغز چندمرحله‌ای — `brain.py`، `role_scope`.
### v8 — T1: حافظه‌ی شواهدمحور — `evidence_memory.py`.
### v7 — T0: انگلیسی‌سازی — فقط ۱۳ خط/۷ فایل با کاراکتر عملکردیِ چینی/ژاپنی ← escape یونیکد + کامنت انگلیسی.

### قبل از v7 (از docs/کد، بدون تاریخ)
Route/API Manager، Cloud Voice، صدای جمله‌به‌جمله، Web Research (Web Intelligence)، System Access Manager (T5-Core) و فازهای T6 (پردازش‌ها/نرم‌افزارها/تحلیل فایل، تنظیمات کاربر، شبکه/دستگاه‌ها، Power، Elevation/UAC)، Active Mode، شخصیت، Image Generation، Audio Manager. ترتیب دقیق نسخه‌ها از سورس قابل استخراج نیست؛ مستند هر کدام در `docs/*_FA.md`.

---

## مشکلات و بدهی‌های شناخته‌شده (فعال)
1. ~~۵ تست قدیمی قرمز~~ — رفع شد (Tests-Fix). ~~۱۵ مورد ناموفق ویندوز~~ — بررسی و رفع شد (Win-Fix-1)؛ **تأیید نهایی با اجرای مجدد `run_tests.bat` روی ویندوز لازم است.**
2. **تست‌های GUI در محیط Claude اجرا نمی‌شوند** (PySide6 نیست): 78 skip. روی ویندوز اجرا می‌شوند.
3. **تمام قابلیت‌های ویندوزی `IMPLEMENTED_UNTESTED`** (UAC، SendMessage/WM_CLOSE، UIA، Audio/Bluetooth، Sysnative روی Python 32-bit، Tray Steam/Discord، …). چک‌لیست‌ها: `docs/WINDOWS11_CHECKLIST_FA.md` و بخش‌های «نیاز به اعتبارسنجی» در `docs/*_FA.md`.
4. **بدهی PowerShell ثابت** (صدا ×11، بلوتوث ×3، UIA ×4) — فریز؛ `docs/TECH_DEBT_FA.md`.
5. **از T6-ToolFix هنوز انجام نشده:** باز کردن PowerShell/Terminal/CMD با `open_app`؛ حافظه‌ی «سؤال باز»؛ نتیجه‌ی یکنواخت success/failed/partial/unknown؛ بازبینی مسیر Audio.
6. docstring بالای `tools/registry.py` سطوح قدیمی (READ/ACTION/SENSITIVE) را می‌گوید؛ مدل فعلی در `sysaccess.py` است.
7. UI برای `role_routes`، مصرف، Embedding و حافظه‌ی تجربی ندارد (فقط `settings.json`).
8. شباهت درخواست‌ها در Experience با هم‌پوشانی کلمات (Jaccard ≥ 0.34) است، نه معنا.
9. `requirements.txt` فقط 4 بسته دارد؛ بقیه (Pillow، sounddevice، edge-tts، SpeechRecognition، miniaudio، faster-whisper) را `install.bat` جدا نصب می‌کند.
