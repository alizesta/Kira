"""Image generation on top of the API Manager (no Qt, no UI): use whichever registered API can really make images.

Nothing is guessed or hard-coded per account: for every registered, enabled API that holds a key, the provider's OFFICIAL model-list endpoint is asked which models
produce images, and only those are used. Supported families (what their public APIs actually offer):

  * Google AI Studio  - Imagen (`models/<id>:predict`) and Gemini image models (`models/<id>:generateContent` with an IMAGE response)
  * Cloudflare Workers AI - models whose task is Text-to-Image (`ai/run/<model>`, e.g. FLUX / Stable Diffusion)
  * a custom OpenAI-compatible API added by the user - models that look like image models, via `POST {base}/images/generations`
  * Groq, Mistral and OpenRouter: NOT used. Groq has no image endpoint; Mistral generates images only through its Agents API; OpenRouter does it through chat
    modalities. They are reported as "not supported" instead of failing mysteriously.

A model on the list is not a guarantee of quota or paid access (Google's Imagen, for instance, may need a paid plan): the real answer comes from the request, so
`generate()` falls over to the next candidate and reports every reason. Keys never appear in messages (`redact`). Returned bytes are checked to be a real PNG / JPEG /
WebP image before anything is saved. Static checks only - nothing here was run against a real provider.
"""
from __future__ import annotations

import base64
import io
import time
from dataclasses import dataclass

import requests

from . import api_manager
from . import discovery
from .discovery import DiscoveryError
from .hybrid_ai import redact, provider_class

MAX_IMAGE_BYTES = 20 * 1024 * 1024
REQUEST_TIMEOUT = 90
TOTAL_BUDGET = 170.0
MAX_ATTEMPTS = 4
CACHE_SECONDS = 600
GEMINI_HOST = "generativelanguage.googleapis.com"
ASPECTS = ("square", "landscape", "portrait")
_IMAGEN_RATIO = {"square": "1:1", "landscape": "16:9", "portrait": "9:16"}
_OPENAI_SIZE = {"square": "1024x1024", "landscape": "1536x1024", "portrait": "1024x1536"}
_OPENAI_HINTS = ("dall-e", "gpt-image", "imagen", "flux", "stable-diffusion", "sdxl", "image")
_UNSUPPORTED = {"groq": "Groq فقط مدل متنی/صوتی دارد و API تصویر ندارد.",
                "mistral": "Mistral تصویر را فقط از راه Agents API می‌سازد که در این نسخه پشتیبانی نمی‌شود.",
                "openrouter": "OpenRouter تصویر را از راه chat modalities می‌سازد که در این نسخه پشتیبانی نمی‌شود."}
_cache: dict = {}


class ImageError(RuntimeError):
    """kind: config | auth | quota | model | content | network | timeout | server | response | unsupported"""

    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind


@dataclass(frozen=True)
class Candidate:
    pid: str
    label: str
    service: str                 # google | cloudflare | openai_compat
    model: str
    cfg: dict


def _short(text, n=160) -> str:
    t = " ".join(str(text or "").split())
    return t if len(t) <= n else t[:n - 1] + "…"


# ---------------------------------------------------------------------------------------------------------------- which models make images
def _image_models_google(cfg: dict, timeout: int) -> list[str]:
    key = str(cfg.get("api_key") or "").strip()
    data = discovery._get(f"https://{GEMINI_HOST}/v1beta/models", {"x-goog-api-key": key}, key, timeout, params={"pageSize": 1000})
    out = []
    for m in (data.get("models") or []) if isinstance(data, dict) else []:
        if not isinstance(m, dict):
            continue
        mid = str(m.get("name") or "").removeprefix("models/")
        methods = m.get("supportedGenerationMethods") if isinstance(m.get("supportedGenerationMethods"), list) else []
        low = mid.lower()
        if "veo" in low or "video" in low:
            continue
        if low.startswith("imagen") and "predict" in methods:
            out.append(mid)
        elif low.startswith("gemini") and "image" in low and "generateContent" in methods:
            out.append(mid)
    # fast / cheap first, then the rest; Imagen before Gemini image
    return sorted(set(out), key=lambda i: (not i.lower().startswith("imagen"), "fast" not in i.lower(), i))


def _image_models_cloudflare(cfg: dict, timeout: int) -> list[str]:
    account, key = str(cfg.get("account_id") or "").strip(), str(cfg.get("api_key") or "").strip()
    if not account or not key:
        raise ImageError("config", "برای Cloudflare هم API Token و هم Account ID لازم است.")
    out, page = [], 1
    while page <= 5:
        data = discovery._get(f"{discovery.CLOUDFLARE_API}/accounts/{account}/ai/models/search", {"Authorization": f"Bearer {key}"}, key, timeout,
                              params={"per_page": 100, "page": page})
        result = (data.get("result") or []) if isinstance(data, dict) else []
        for item in result:
            task = str(((item or {}).get("task") or {}).get("name") or "").lower().replace("-", " ")
            mid = str((item or {}).get("name") or "").strip()
            if mid and task == "text to image":
                out.append(mid)
        if page >= int(((data or {}).get("result_info") or {}).get("total_pages") or 1) or not result:
            break
        page += 1
    return sorted(set(out), key=lambda i: ("schnell" not in i.lower(), "flux" not in i.lower(), i))


def _image_models_openai(pid: str, cfg: dict, timeout: int) -> list[str]:
    base = str(cfg.get("base_url") or "").strip().rstrip("/")
    key = str(cfg.get("api_key") or "").strip()
    if not base or not key:
        raise ImageError("config", "آدرس پایه و API Key لازم است.")
    data = discovery._get(base + "/models", {"Authorization": f"Bearer {key}"}, key, timeout, unsupported_on_404=True)
    items = data.get("data") if isinstance(data, dict) else None
    ids = [str(m.get("id") or "") for m in (items or []) if isinstance(m, dict)]
    return [i for i in ids if i and any(h in i.lower() for h in _OPENAI_HINTS)]


def list_candidates(settings: dict, only: str = "", timeout: int = 15, per_api: int = 2) -> tuple[list[Candidate], list[str]]:
    """-> (candidates in API-priority order, notes explaining every registered API that is NOT usable for images). `only` = a provider id / label to restrict to."""
    cands, notes = [], []
    providers = settings.get("providers", {}) if isinstance(settings, dict) else {}
    for pid in api_manager.api_ids(settings):
        cfg = providers.get(pid) or {}
        service = api_manager.service_of(pid, cfg)
        label = str(cfg.get("label") or cfg.get("name") or pid)
        if only and only.strip().lower() not in (pid.lower(), label.lower()):
            continue
        if not cfg.get("enabled", True) or not str(cfg.get("api_key") or "").strip():
            notes.append(f"{label}: غیرفعال است یا کلید ندارد.")
            continue
        if service in _UNSUPPORTED:
            notes.append(f"{label}: {_UNSUPPORTED[service]}")
            continue
        klass = provider_class(pid, cfg)
        fam = "google" if service == "google" else "cloudflare" if service == "cloudflare" or getattr(klass, "__name__", "") == "CloudflareProvider" else "openai_compat"
        ck = (pid, str(cfg.get("api_key"))[-6:], str(cfg.get("base_url") or ""), str(cfg.get("account_id") or ""))
        hit = _cache.get(ck)
        try:
            if hit and time.time() - hit[0] < CACHE_SECONDS:
                models = hit[1]
            else:
                models = (_image_models_google(cfg, timeout) if fam == "google" else _image_models_cloudflare(cfg, timeout) if fam == "cloudflare"
                          else _image_models_openai(pid, cfg, timeout))
                _cache[ck] = (time.time(), models)
        except DiscoveryError as exc:
            notes.append(f"{label}: فهرست مدل‌های تصویر خوانده نشد ({exc}).")
            continue
        except ImageError as exc:
            notes.append(f"{label}: {exc}")
            continue
        if not models:
            notes.append(f"{label}: هیچ مدل تصویری برای این کلید گزارش نشد.")
            continue
        for m in models[:per_api]:
            cands.append(Candidate(pid, label, fam, m, dict(cfg)))
    return cands, notes


# ---------------------------------------------------------------------------------------------------------------- one request
def _post(url: str, headers: dict, payload: dict, secret: str) -> requests.Response:
    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=REQUEST_TIMEOUT)
    except requests.Timeout as exc:
        raise ImageError("timeout", f"مهلت پاسخ‌گویی ({REQUEST_TIMEOUT} ثانیه) تمام شد.") from exc
    except requests.RequestException as exc:
        raise ImageError("network", redact(f"خطای شبکه: {exc}", secret)[:200]) from exc
    code = resp.status_code
    if code < 400:
        return resp
    try:
        detail = _short(resp.text, 220)
    except Exception:                                                  # noqa: BLE001
        detail = ""
    detail = redact(detail, secret)
    low = detail.lower()
    if code in (401, 403):
        raise ImageError("auth", f"کلید معتبر نیست یا به تولید تصویر دسترسی ندارد ({code}). {detail}")
    if code == 429 or "quota" in low or "billing" in low or "exceeded" in low or "paid" in low:
        raise ImageError("quota", f"سهمیه/پلن این کلید برای تصویر کافی نیست ({code}). {detail}")
    if code == 404:
        raise ImageError("model", f"مدل یا آدرس پیدا نشد ({code}). {detail}")
    if code >= 500:
        raise ImageError("server", f"خطای سرور سرویس ({code}).")
    if any(w in low for w in ("safety", "blocked", "policy", "prohibited", "moderation", "content")):
        raise ImageError("content", f"سرویس این درخواست را به‌دلیل سیاست محتوا نپذیرفت ({code}). {detail}")
    raise ImageError("response", f"درخواست رد شد ({code}). {detail}")


def _image_bytes(raw: bytes) -> tuple[bytes, str]:
    if len(raw) > MAX_IMAGE_BYTES:
        raise ImageError("response", "تصویر برگشتی از سقف ۲۰ مگابایت بزرگ‌تر است.")
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return raw, "png"
    if raw.startswith(b"\xff\xd8\xff"):
        return raw, "jpg"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return raw, "webp"
    raise ImageError("response", "داده‌ی برگشتی تصویر معتبر (PNG / JPEG / WebP) نبود.")


def _b64(value) -> bytes:
    text = str(value or "")
    if text.startswith("data:") and "," in text:
        text = text.split(",", 1)[1]
    try:
        return base64.b64decode(text, validate=False)
    except (ValueError, TypeError) as exc:
        raise ImageError("response", "تصویر برگشتی base64 معتبر نبود.") from exc


def _google(c: Candidate, prompt: str, aspect: str) -> bytes:
    key = str(c.cfg.get("api_key")).strip()
    headers = {"x-goog-api-key": key, "Content-Type": "application/json"}
    base = f"https://{GEMINI_HOST}/v1beta/models/{c.model}"
    if c.model.lower().startswith("imagen"):
        data = _post(base + ":predict", headers, {"instances": [{"prompt": prompt}], "parameters": {"sampleCount": 1, "aspectRatio": _IMAGEN_RATIO[aspect]}}, key).json()
        preds = data.get("predictions") if isinstance(data, dict) else None
        if not preds or not isinstance(preds[0], dict) or not preds[0].get("bytesBase64Encoded"):
            reason = (preds[0] or {}).get("raiFilteredReason") if preds and isinstance(preds[0], dict) else ""
            raise ImageError("content" if reason else "response", f"Imagen تصویری برنگرداند. {_short(reason)}")
        return _b64(preds[0]["bytesBase64Encoded"])
    data = _post(base + ":generateContent", headers, {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}}, key).json()
    texts = []
    for cand in (data.get("candidates") or []) if isinstance(data, dict) else []:
        for part in ((cand or {}).get("content") or {}).get("parts") or []:
            inline = part.get("inlineData") or part.get("inline_data") if isinstance(part, dict) else None
            if inline and inline.get("data"):
                return _b64(inline["data"])
            if isinstance(part, dict) and part.get("text"):
                texts.append(part["text"])
    raise ImageError("content" if texts else "response", "مدل Gemini تصویری برنگرداند. " + _short(" ".join(texts)))


def _cloudflare(c: Candidate, prompt: str, aspect: str) -> bytes:
    key, account = str(c.cfg.get("api_key")).strip(), str(c.cfg.get("account_id")).strip()
    payload = {"prompt": prompt}
    if "schnell" in c.model.lower():
        payload["steps"] = 4
    resp = _post(f"{discovery.CLOUDFLARE_API}/accounts/{account}/ai/run/{c.model}", {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, payload, key)
    if str(resp.headers.get("content-type", "")).lower().startswith("image/"):
        return resp.content
    try:
        data = resp.json()
    except ValueError as exc:
        raise ImageError("response", "پاسخ Cloudflare نه تصویر بود نه JSON.") from exc
    if isinstance(data, dict) and data.get("success") is False:
        raise ImageError("response", redact("Cloudflare رد کرد: " + _short(data.get("errors"), 200), key))
    result = (data.get("result") if isinstance(data, dict) else None) or {}
    img = result.get("image") if isinstance(result, dict) else None
    if not img:
        raise ImageError("response", "Cloudflare تصویری برنگرداند.")
    return _b64(img)


def _openai(c: Candidate, prompt: str, aspect: str) -> bytes:
    key = str(c.cfg.get("api_key")).strip()
    base = str(c.cfg.get("base_url") or "").strip().rstrip("/")
    payload = {"model": c.model, "prompt": prompt, "n": 1, "size": _OPENAI_SIZE[aspect]}
    if "gpt-image" not in c.model.lower():                       # gpt-image models always answer b64_json and reject response_format
        payload["response_format"] = "b64_json"
    data = _post(base + "/images/generations", {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, payload, key).json()
    items = data.get("data") if isinstance(data, dict) else None
    first = items[0] if items and isinstance(items[0], dict) else {}
    if first.get("b64_json"):
        return _b64(first["b64_json"])
    if first.get("url"):
        from .webintel import netguard                           # the provider chose this address: fetch it only through the SSRF-safe fetcher
        try:
            got = netguard.fetch(str(first["url"]), max_bytes=MAX_IMAGE_BYTES)
            if got.truncated:
                raise ImageError("response", "تصویر دانلودشده ناقص بود (از سقف اندازه بزرگ‌تر).")
            return got.body
        except ImageError:
            raise
        except Exception as exc:                                 # noqa: BLE001
            raise ImageError("network", redact(f"دانلود تصویر ناموفق بود: {exc}", key)[:200]) from exc
    raise ImageError("response", "سرویس تصویری برنگرداند.")


_RUNNERS = {"google": _google, "cloudflare": _cloudflare, "openai_compat": _openai}


def generate(settings: dict, prompt: str, aspect: str = "square", only: str = "") -> tuple[bytes, str, Candidate, list[str]]:
    """-> (image bytes, extension, the candidate that produced it, failure notes of the ones tried before). Raises ImageError with all the real reasons."""
    aspect = aspect if aspect in ASPECTS else "square"
    cands, notes = list_candidates(settings, only=only)
    if not cands:
        raise ImageError("unsupported", "هیچ API ثبت‌شده‌ای مدل تولید تصویر ندارد. " + (" | ".join(notes) if notes else "اول در صفحه‌ی Route یک API (مثلاً Google AI Studio یا Cloudflare) اضافه کن."))
    started, failures = time.monotonic(), []
    for c in cands[:MAX_ATTEMPTS]:
        if time.monotonic() - started > TOTAL_BUDGET:
            failures.append("مهلت کل تمام شد.")
            break
        try:
            raw, ext = _image_bytes(_RUNNERS[c.service](c, prompt, aspect))
            return raw, ext, c, failures
        except ImageError as exc:
            failures.append(f"{c.label}/{c.model}: {exc}")
            if exc.kind == "content":                              # a content-policy refusal will not change on another provider: stop, do not shop around for a bypass
                break
    raise ImageError(("content" if failures and "سیاست محتوا" in failures[-1] else "response"), "تولید تصویر ناموفق بود: " + " | ".join(failures))

# ---------------------------------------------------------------------------------------------------------------- animated GIF (several frames -> one GIF)
# Frames are ordinary stills made by generate() above; this part only validates them, makes them the same size, reduces the colours and writes ONE looping GIF
# with Pillow (optional package; install.bat installs it). 2..GIF_MAX_FRAMES frames; the longest side is limited so the file stays small (SIDE_STEPS, then an
# error if it still exceeds GIF_MAX_BYTES); the result is re-opened and checked (GIF signature + real frame count) before it is returned.
GIF_MIN_FRAMES = 2
GIF_MAX_FRAMES = 8
GIF_MAX_BYTES = 8 * 1024 * 1024
SIDE_STEPS = (512, 384, 256)
COLORS = 128
GIF_MIN_MS, GIF_MAX_MS = 60, 2000


def gif_available() -> bool:
    try:
        import PIL  # noqa: F401
        return True
    except ImportError:
        return False


def _pillow():
    try:
        from PIL import Image
        return Image
    except ImportError as exc:
        raise ImageError("config", "برای ساخت GIF بسته‌ی Pillow لازم است و نصب نیست. «python -m pip install Pillow» را اجرا کن (یا install.bat را دوباره بزن).") from exc


def _fit(size: tuple, max_side: int) -> tuple:
    w, h = size
    scale = min(1.0, max_side / float(max(w, h)))
    return max(16, int(round(w * scale))), max(16, int(round(h * scale)))


def _encode(Image, rgb_frames: list, size: tuple, duration_ms: int) -> bytes:
    small = []
    for im in rgb_frames:
        im = im.resize(size, Image.LANCZOS) if im.size != size else im
        small.append(im.quantize(colors=COLORS, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.FLOYDSTEINBERG))
    buf = io.BytesIO()
    small[0].save(buf, format="GIF", save_all=True, append_images=small[1:], duration=duration_ms, loop=0, disposal=2, optimize=False)
    return buf.getvalue()


def build_gif(frames: list, duration_ms: int = 250, ping_pong: bool = True) -> tuple:
    """frames = [image bytes]. -> (gif bytes, info dict {frames, size, duration_ms, bytes}). Raises ImageError (kind config | response)."""
    Image = _pillow()
    if not (GIF_MIN_FRAMES <= len(frames) <= GIF_MAX_FRAMES):
        raise ImageError("response", f"تعداد فریم باید بین {GIF_MIN_FRAMES} و {GIF_MAX_FRAMES} باشد (الان {len(frames)}).")
    duration_ms = max(GIF_MIN_MS, min(GIF_MAX_MS, int(duration_ms)))
    rgb = []
    for i, raw in enumerate(frames, 1):
        try:
            with Image.open(io.BytesIO(raw)) as im:
                rgb.append(im.convert("RGB"))
        except Exception as exc:                                    # noqa: BLE001 - a damaged frame is reported with its number
            raise ImageError("response", f"فریم {i} تصویر معتبر نبود ({type(exc).__name__}).") from exc
    first_size = rgb[0].size
    seq = list(rgb)
    if ping_pong and len(seq) > 2:
        seq += rgb[-2:0:-1]                                         # 1 2 3 4 3 2 -> a smooth loop without repeating the end frames
    expected = len(seq)
    for side in SIDE_STEPS:
        size = _fit(first_size, side)
        data = _encode(Image, seq, size, duration_ms)
        if len(data) <= GIF_MAX_BYTES:
            break
    else:
        raise ImageError("response", f"GIF حتی در کوچک‌ترین اندازه از {GIF_MAX_BYTES // (1024 * 1024)} مگابایت بزرگ‌تر شد؛ فریم‌های کمتر بخواه.")
    if data[:6] not in (b"GIF87a", b"GIF89a"):
        raise ImageError("response", "خروجی ساخته‌شده GIF معتبر نبود.")
    try:
        with Image.open(io.BytesIO(data)) as check:
            got = int(getattr(check, "n_frames", 1))
    except Exception as exc:                                        # noqa: BLE001
        raise ImageError("response", f"GIF ساخته شد ولی دوباره خوانده نشد ({type(exc).__name__}).") from exc
    if got != expected:
        raise ImageError("response", f"GIF ساخته شد ولی تعداد فریم‌ها درست نبود ({got} به‌جای {expected}).")
    return data, {"frames": expected, "source_frames": len(frames), "size": size, "duration_ms": duration_ms, "bytes": len(data)}
