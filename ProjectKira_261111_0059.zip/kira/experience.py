"""Experience memory, cautious learning from tool failures and a data-only Skill Library (Learning step 1 + 2 + 3). Local, rule-based: no model call, no network, no code is ever changed.

What it does
  * EPISODES: after every turn that ran tools, one row: the user's request (clipped, secrets masked), each tool call (name, status, failure kind, whether the tool re-checks
    the real result) and a small self-evaluation (execution / verification / efficiency, 0-100). Tool RESULT TEXT is never stored (it may hold web / file content or
    private data); arguments are stored only for non-private parameters, clipped and masked.
  * LESSONS: when a tool failed for a real reason and a DIFFERENT tool then succeeded in the same turn for the same kind of request, that is a *candidate* lesson.
    It is not trusted yet. It becomes `verified` only after it was confirmed in at least CONFIRM_TO_VERIFY separate turns and was never contradicted (the failed tool
    working later for a similar request counts against it; contradictions >= confirmations demote it again). Lessons from turns that read external content
    (web / MCP / agent output = tainted) are never learned. Unverified lessons expire.
  * HINTS: only verified lessons relevant to the CURRENT request, plus "this tool keeps failing here for a permanent reason" notes, are added to the tool prompt as
    short, code-written lines (no free text from results, so nothing a web page says can end up here). A hint only advises the model: permissions, confirmations and
    the explicit-request gate (kira/tools/sysaccess.py) are never touched by it.

  * SKILLS (step 3): a turn that ran 2+ different tools, all succeeded and read no external content leaves a *candidate* skill: just the ORDERED LIST OF TOOL NAMES
    plus the request's key words. It is data, not code: no arguments, no results, nothing executable. It becomes `verified` after CONFIRM_TO_VERIFY separate turns and is
    demoted when a similar request later fails on one of its tools. A verified skill reaches the model only as a one-line hint ("this order worked n times"); every step
    the model then takes still goes through the normal registry, permission levels, confirmations and the explicit-request gate - a skill cannot bypass any of them.

Limits: bounded (MAX_EPISODES / MAX_LESSONS), everything stays on this PC in kira_experience.sqlite3 (delete the file to forget it all), setting `experience_memory` = off
turns the module into a no-op, and every public function swallows its own errors: a failure here means "no experience this turn", never a broken chat.
Static checks only - nothing here was run on a real PC.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import re
import sqlite3
import threading
import time
from pathlib import Path

from .evidence_memory import norm

DB_NAME = "kira_experience.sqlite3"
MAX_EPISODES = 1500
MAX_LESSONS = 150
CONFIRM_TO_VERIFY = 2
CONFIRM_GAP = 60.0                      # seconds: two confirmations must be separate turns, not one burst
CANDIDATE_TTL = 30 * 86400
PERSISTENT_KINDS = ("missing_component", "unsupported_hardware", "app_not_installed")      # a retry will not change these
PERSISTENT_MIN = 3
PERSISTENT_WINDOW = 14 * 86400
MAX_HINTS = 3
MAX_SKILLS = 60
SKILL_TTL = 60 * 86400                  # a skill nobody confirmed for this long is forgotten
SKILL_MIN_STEPS, SKILL_MAX_STEPS = 2, 6
MAX_SKILL_HINTS = 2
SIMILARITY = 0.34
MAX_EXAMPLES = 80
MAX_EXAMPLE_HINTS = 2
SAFE_EXAMPLE_ARGS = {"name", "url", "browser", "app", "aspect", "frames", "provider", "level", "percent", "volume", "state", "mode", "device", "target"}
_SECRET_RX = re.compile(r"AIza|AQ\.|gsk_|sk-[A-Za-z0-9]|password|passwd|secret|token|رمز|[?&](?:key|token|sig|auth)=", re.I)
IGNORED_TOOLS = {"windows_control_info", "mcp_info"}
PRIVATE_PARAMS = {"text", "content", "body", "password", "secret", "token", "key", "quote", "message"}
_FAIL_FA = {"permission_denied": "دسترسی رد شد", "admin_required": "نیازمند Administrator", "powershell_failure": "خطای PowerShell", "missing_component": "مؤلفه‌ی ویندوز موجود نیست",
            "unsupported_hardware": "سخت‌افزار پشتیبانی نمی‌کند", "device_unavailable": "دستگاه در دسترس نیست", "api_failure": "خطای API ویندوز", "app_not_installed": "برنامه نصب نیست",
            "timeout": "مهلت تمام شد", "": "خطا"}
_WORD = re.compile(r"\w+", re.U)

_lock = threading.RLock()
_dir: Path | None = None
_enabled = True
_ready: str | None = None
_buffer: list[dict] = []
_buffer_taint = False


# ------------------------------------------------------------------------------------------------ setup
def configure(data_dir, settings=None) -> None:
    """Called by the tool agent at start-up and after settings change. Never raises, never touches the disk."""
    global _dir, _enabled
    try:
        _dir = Path(data_dir) if data_dir else None
        _enabled = str((settings or {}).get("experience_memory", "auto")).lower() != "off" and _dir is not None
    except Exception:                                                    # noqa: BLE001
        _enabled = False


def enabled() -> bool:
    return bool(_enabled and _dir)


def _path() -> Path:
    return Path(_dir) / DB_NAME


@contextlib.contextmanager
def _db():
    con = sqlite3.connect(str(_path()), timeout=5)
    try:
        con.row_factory = sqlite3.Row
        with con:
            yield con
    finally:
        con.close()


def _ensure() -> None:
    global _ready
    p = str(_path())
    if _ready == p:
        return
    Path(_dir).mkdir(parents=True, exist_ok=True)
    with _db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS episodes (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, request TEXT, tainted INTEGER,
                       execution INTEGER, verification INTEGER, efficiency INTEGER, score INTEGER)""")
        con.execute("""CREATE TABLE IF NOT EXISTS calls (id INTEGER PRIMARY KEY AUTOINCREMENT, episode_id INTEGER, tool TEXT, status TEXT, kind TEXT,
                       verifies INTEGER, args TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS lessons (id TEXT PRIMARY KEY, created REAL, updated REAL, last_confirm REAL, request_tokens TEXT, fail_tool TEXT,
                       fail_kind TEXT, ok_tool TEXT, confirmations INTEGER, contradictions INTEGER, status TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS skills (id TEXT PRIMARY KEY, created REAL, updated REAL, last_confirm REAL, request_tokens TEXT, steps TEXT,
                       confirmations INTEGER, contradictions INTEGER, status TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS examples (id TEXT PRIMARY KEY, created REAL, updated REAL, last_confirm REAL, request_tokens TEXT, request TEXT,
                       tool TEXT, args TEXT, tool_verifies INTEGER, confirmations INTEGER, contradictions INTEGER, status TEXT)""")
        con.execute("CREATE INDEX IF NOT EXISTS calls_tool ON calls(tool)")
    _ready = p


# ------------------------------------------------------------------------------------------------ text helpers
def _clip(text, n) -> str:
    from .tools.registry import redact_secrets           # lazy: the registry itself calls this module
    return redact_secrets(" ".join(str(text or "").split()))[:n]


def _words(text) -> list[str]:
    """Plain words only (no trigrams): the key of a request. Order-independent, deduplicated, at most 8."""
    seen, out = set(), []
    for w in _WORD.findall(norm(text)):
        if len(w) >= 3 and w not in seen and not w.isdigit():
            seen.add(w)
            out.append(w)
    return out[:8]


def _similar(a: list[str], b: list[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / float(len(sa | sb))


def _args_brief(args) -> str:
    parts = []
    for k, v in (args or {}).items():
        if k in PRIVATE_PARAMS:
            continue
        parts.append(f"{k}={_clip(v, 40)}")
    return ", ".join(parts)[:160]


# ------------------------------------------------------------------------------------------------ observing (called by the registry for every tool run)
def _safe_args(args) -> dict:
    """Only whitelisted, short, non-secret scalar arguments: the few-shot examples never hold free text, paths or keys."""
    out = {}
    for k, v in (args or {}).items():
        if k not in SAFE_EXAMPLE_ARGS or not isinstance(v, (str, int, float, bool)):
            continue
        if isinstance(v, str):
            v = " ".join(v.split())[:80]
            if not v or _SECRET_RX.search(v) or "\\" in v or ("://" in v and "?" in v):
                continue
        out[k] = v
    return out


def observe(tool, res, verifies: bool = False, tainted: bool = False) -> None:
    """One finished tool call of the current turn. Cheap (memory only); the turn is written by flush()."""
    global _buffer_taint
    try:
        if not enabled() or tool.name in IGNORED_TOOLS:
            return
        with _lock:
            _buffer.append({"tool": tool.name, "status": res.status, "kind": getattr(res, "kind", "") or "", "verifies": bool(verifies),
                            "args": _args_brief(getattr(res, "args", {}) or {}),
                            "argd": _safe_args(getattr(res, "args", {}) or {}), "categories": tuple(tool.categories)})
            _buffer_taint = _buffer_taint or bool(tainted)
    except Exception:                                                    # noqa: BLE001
        pass


def flush(request: str = "", tainted: bool = False) -> dict | None:
    """The turn is over: write the episode, learn from it. Idempotent (an empty buffer does nothing). Returns the evaluation or None."""
    global _buffer_taint
    try:
        with _lock:
            calls, taint = list(_buffer), _buffer_taint or bool(tainted)
            _buffer.clear()
            _buffer_taint = False
        if not enabled() or not calls:
            return None
        return _record_turn(_clip(request, 160), calls, taint)
    except Exception:                                                    # noqa: BLE001
        return None


# ------------------------------------------------------------------------------------------------ self-evaluation (honest: only what code can know)
def evaluate(calls: list[dict]) -> dict:
    """execution: share of real runs that succeeded. verification: an action that changed something was re-checked by the tool itself (or there was no action).
    efficiency: failed attempts and repeated calls cost points. Accuracy / tool-selection need a judge and are NOT guessed here."""
    real = [c for c in calls if c["status"] not in ("needs_confirmation",)]
    if not real:
        return {"execution": 100, "verification": 100, "efficiency": 100, "score": 100}
    ok = [c for c in real if c["status"] == "ok"]
    execution = round(100 * len(ok) / len(real))
    acting = [c for c in ok if c["verifies"]]
    changed = [c for c in real if c["verifies"]]
    verification = 100 if not changed else round(100 * len(acting) / len(changed))
    repeats = len(real) - len({(c["tool"], c["args"]) for c in real})
    failed = len(real) - len(ok)
    efficiency = max(0, 100 - 20 * failed - 15 * repeats)
    return {"execution": execution, "verification": verification, "efficiency": efficiency, "score": round((execution * 2 + verification + efficiency) / 4)}


# ------------------------------------------------------------------------------------------------ learning
def _record_turn(request: str, calls: list[dict], tainted: bool) -> dict:
    ev = evaluate(calls)
    now = time.time()
    rtok = _words(request)
    with _lock:
        _ensure()
        with _db() as con:
            cur = con.execute("INSERT INTO episodes(ts, request, tainted, execution, verification, efficiency, score) VALUES (?,?,?,?,?,?,?)",
                              (now, request, int(tainted), ev["execution"], ev["verification"], ev["efficiency"], ev["score"]))
            eid = cur.lastrowid
            con.executemany("INSERT INTO calls(episode_id, tool, status, kind, verifies, args) VALUES (?,?,?,?,?,?)",
                            [(eid, c["tool"], c["status"], c["kind"], int(c["verifies"]), c["args"]) for c in calls])
            if not tainted and rtok:
                _learn(con, rtok, calls, now)
                _learn_skill(con, rtok, calls, now)
                _learn_examples(con, request, rtok, calls, now)
            _prune(con, now)
    return ev


def _lesson_id(rtok, fail_tool, ok_tool) -> str:
    return hashlib.sha1(("|".join(sorted(rtok[:6])) + "#" + fail_tool + ">" + ok_tool).encode("utf-8")).hexdigest()[:16]


def _learn(con, rtok, calls, now) -> None:
    ran_ok = {c["tool"] for c in calls if c["status"] == "ok"}
    # 1) new candidates: a tool failed for a real reason, a different tool of the same area worked afterwards in this turn
    for i, f in enumerate(calls):
        if f["status"] != "error" or f["kind"] in ("user_cancelled",):
            continue
        for ok in calls[i + 1:]:
            if ok["status"] != "ok" or ok["tool"] == f["tool"] or f["tool"] in ran_ok:
                continue
            if not (set(ok["categories"]) & set(f["categories"])):
                continue
            lid = _lesson_id(rtok, f["tool"], ok["tool"])
            row = con.execute("SELECT * FROM lessons WHERE id=?", (lid,)).fetchone()
            if row is None:
                con.execute("INSERT INTO lessons VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (lid, now, now, now, json.dumps(rtok, ensure_ascii=False), f["tool"], f["kind"], ok["tool"], 1, 0, "candidate"))
            else:
                _confirm(con, row, now)
            break
    # 2) existing lessons that match this request: confirmed again, or contradicted
    for row in con.execute("SELECT * FROM lessons").fetchall():
        if _similar(json.loads(row["request_tokens"]), rtok) < SIMILARITY:
            continue
        failed_tool_ok = row["fail_tool"] in ran_ok
        ok_tool_ok = row["ok_tool"] in ran_ok
        failed_tool_failed = any(c["tool"] == row["fail_tool"] and c["status"] == "error" for c in calls)
        if failed_tool_ok:
            c = row["contradictions"] + 1
            status = "candidate" if (row["status"] == "verified" and c >= row["confirmations"]) else row["status"]
            con.execute("UPDATE lessons SET contradictions=?, status=?, updated=? WHERE id=?", (c, status, now, row["id"]))
        elif ok_tool_ok and failed_tool_failed:
            _confirm(con, row, now)


def _skill_steps(calls) -> list[str]:
    """The ordered tool names of a clean turn (consecutive repeats collapsed), or [] when the turn is not a skill candidate."""
    real = [c for c in calls if c["status"] != "needs_confirmation"]
    if not real or any(c["status"] != "ok" for c in real) or len(real) != len(calls):
        return []                                                         # any failure or any pending confirmation: not a clean success
    steps: list[str] = []
    for c in real:
        if not steps or steps[-1] != c["tool"]:
            steps.append(c["tool"])
    if len(set(steps)) != len(steps):                                    # a loop (A,B,A) is not a routine
        return []
    return steps if SKILL_MIN_STEPS <= len(steps) <= SKILL_MAX_STEPS else []


def _skill_id(rtok, steps) -> str:
    return hashlib.sha1(("|".join(sorted(rtok[:6])) + "#" + ">".join(steps)).encode("utf-8")).hexdigest()[:16]


def _learn_skill(con, rtok, calls, now) -> None:
    steps = _skill_steps(calls)
    if steps:
        sid = _skill_id(rtok, steps)
        row = con.execute("SELECT * FROM skills WHERE id=?", (sid,)).fetchone()
        if row is None:
            con.execute("INSERT INTO skills VALUES (?,?,?,?,?,?,?,?,?)",
                        (sid, now, now, now, json.dumps(rtok, ensure_ascii=False), json.dumps(steps), 1, 0, "candidate"))
        elif now - float(row["last_confirm"] or 0) >= CONFIRM_GAP:
            conf = row["confirmations"] + 1
            status = "verified" if (conf >= CONFIRM_TO_VERIFY and row["contradictions"] == 0) else row["status"]
            con.execute("UPDATE skills SET confirmations=?, status=?, last_confirm=?, updated=? WHERE id=?", (conf, status, now, now, sid))
    # a similar request that FAILED on a tool of a skill counts against it
    failed = {c["tool"] for c in calls if c["status"] == "error" and c["kind"] != "user_cancelled"}
    if not failed:
        return
    for row in con.execute("SELECT * FROM skills").fetchall():
        if steps and row["id"] == _skill_id(rtok, steps):
            continue
        if _similar(json.loads(row["request_tokens"]), rtok) < SIMILARITY or not (failed & set(json.loads(row["steps"]))):
            continue
        c = row["contradictions"] + 1
        status = "candidate" if (row["status"] == "verified" and c >= row["confirmations"]) else row["status"]
        con.execute("UPDATE skills SET contradictions=?, status=?, updated=? WHERE id=?", (c, status, now, row["id"]))


def _example_id(rtok, tool, argd) -> str:
    return hashlib.sha1(("|".join(sorted(rtok[:6])) + "#" + tool + json.dumps(argd, sort_keys=True, ensure_ascii=False)).encode("utf-8")).hexdigest()[:16]


def _learn_examples(con, request, rtok, calls, now) -> None:
    """A clean successful turn (every call ok, nothing pending) keeps each call as a few-shot example: the request + the tool + its SAFE arguments.
    It is shown to the model only when verified: the tool re-read the real state, or the same call worked in 2 separate turns. A later failure of that tool
    for a similar request counts against it (like skills / lessons)."""
    real = [c for c in calls if c["status"] != "needs_confirmation"]
    if not real or len(real) != len(calls) or any(c["status"] != "ok" for c in real) or len(real) > 3:
        return
    if _SECRET_RX.search(request or "") or len(request or "") < 4:
        return
    for c in real:
        if c["tool"] in IGNORED_TOOLS or not c.get("argd"):
            continue
        eid = _example_id(rtok, c["tool"], c["argd"])
        row = con.execute("SELECT * FROM examples WHERE id=?", (eid,)).fetchone()
        if row is None:
            status = "verified" if c["verifies"] else "candidate"
            con.execute("INSERT INTO examples VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (eid, now, now, now, json.dumps(rtok, ensure_ascii=False), _clip(request, 100), c["tool"], json.dumps(c["argd"], ensure_ascii=False),
                         int(c["verifies"]), 1, 0, status))
        elif now - float(row["last_confirm"] or 0) >= CONFIRM_GAP:
            conf = row["confirmations"] + 1
            status = "verified" if (row["tool_verifies"] or conf >= CONFIRM_TO_VERIFY) and row["contradictions"] == 0 else row["status"]
            con.execute("UPDATE examples SET confirmations=?, status=?, last_confirm=?, updated=? WHERE id=?", (conf, status, now, now, eid))
    failed = {c["tool"] for c in calls if c["status"] == "error" and c["kind"] != "user_cancelled"}
    for row in (con.execute("SELECT * FROM examples").fetchall() if failed else []):
        if row["tool"] in failed and _similar(json.loads(row["request_tokens"]), rtok) >= SIMILARITY:
            n = row["contradictions"] + 1
            con.execute("UPDATE examples SET contradictions=?, status=? WHERE id=?",
                        (n, "candidate" if n >= row["confirmations"] else row["status"], row["id"]))


def example_lines(request: str, has_tool=None) -> list:
    """Up to MAX_EXAMPLE_HINTS verified few-shot lines for a similar request: the real tool block that worked before."""
    try:
        rtok = _words(request)
        if not rtok:
            return []
        exists = has_tool or (lambda n: True)
        best = []
        with _lock, _db() as con:
            for row in con.execute("SELECT * FROM examples WHERE status='verified' AND contradictions=0").fetchall():
                sim = _similar(json.loads(row["request_tokens"]), rtok)
                if sim >= SIMILARITY and exists(row["tool"]):
                    best.append((sim, row))
        out = []
        for _s, row in sorted(best, key=lambda x: -x[0])[:MAX_EXAMPLE_HINTS]:
            block = json.dumps({"tool": row["tool"], "args": json.loads(row["args"])}, ensure_ascii=False)
            out.append(f"- Worked before (verified, {row['confirmations']}x) for «{row['request']}»: <kira_tool>{block}</kira_tool> - copy the shape, adapt the values to the CURRENT request.")
        return out
    except Exception:                                                    # noqa: BLE001
        return []


def _confirm(con, row, now) -> None:
    if now - float(row["last_confirm"] or 0) < CONFIRM_GAP:
        return                                                            # the same burst, not an independent turn
    conf = row["confirmations"] + 1
    status = "verified" if (conf >= CONFIRM_TO_VERIFY and row["contradictions"] == 0) else row["status"]
    con.execute("UPDATE lessons SET confirmations=?, status=?, last_confirm=?, updated=? WHERE id=?", (conf, status, now, now, row["id"]))


def _prune(con, now) -> None:
    con.execute("DELETE FROM lessons WHERE status='candidate' AND updated < ?", (now - CANDIDATE_TTL,))
    n = con.execute("SELECT COUNT(*) FROM lessons").fetchone()[0]
    if n > MAX_LESSONS:
        con.execute("DELETE FROM lessons WHERE id IN (SELECT id FROM lessons ORDER BY (status='verified') ASC, updated ASC LIMIT ?)", (n - MAX_LESSONS,))
    con.execute("DELETE FROM examples WHERE status='candidate' AND updated < ?", (now - CANDIDATE_TTL,))
    con.execute("DELETE FROM examples WHERE updated < ?", (now - SKILL_TTL,))
    n = con.execute("SELECT COUNT(*) FROM examples").fetchone()[0]
    if n > MAX_EXAMPLES:
        con.execute("DELETE FROM examples WHERE id IN (SELECT id FROM examples ORDER BY (status='verified') ASC, updated ASC LIMIT ?)", (n - MAX_EXAMPLES,))
    con.execute("DELETE FROM skills WHERE status='candidate' AND updated < ?", (now - CANDIDATE_TTL,))
    con.execute("DELETE FROM skills WHERE updated < ?", (now - SKILL_TTL,))
    n = con.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
    if n > MAX_SKILLS:
        con.execute("DELETE FROM skills WHERE id IN (SELECT id FROM skills ORDER BY (status='verified') ASC, updated ASC LIMIT ?)", (n - MAX_SKILLS,))
    n = con.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]
    if n > MAX_EPISODES:
        con.execute("DELETE FROM calls WHERE episode_id IN (SELECT id FROM episodes ORDER BY id ASC LIMIT ?)", (n - MAX_EPISODES,))
        con.execute("DELETE FROM episodes WHERE id IN (SELECT id FROM episodes ORDER BY id ASC LIMIT ?)", (n - MAX_EPISODES,))


# ------------------------------------------------------------------------------------------------ hints for the tool prompt
def hints(request: str, has_tool=None) -> str:
    """Short code-written lines for the current request, or ''. `has_tool(name)` = is that tool in the live registry (a lesson about a removed tool is skipped)."""
    try:
        if not enabled() or not _path().is_file():
            return ""
        rtok = _words(request)
        exists = has_tool or (lambda n: True)
        lines = []
        with _lock, _db() as con:
            if rtok:
                scored = []
                for row in con.execute("SELECT * FROM lessons WHERE status='verified' AND contradictions=0").fetchall():
                    sim = _similar(json.loads(row["request_tokens"]), rtok)
                    if sim >= SIMILARITY and exists(row["ok_tool"]):
                        scored.append((sim, row))
                for _sim, row in sorted(scored, key=lambda x: -x[0])[:MAX_HINTS]:
                    lines.append(f"- For a request like this «{row['fail_tool']}» failed ({_FAIL_FA.get(row['fail_kind'], 'خطا')}) in earlier runs and «{row['ok_tool']}» worked "
                                 f"({row['confirmations']} confirmed runs). Prefer «{row['ok_tool']}».")
            if rtok:
                best = []
                for row in con.execute("SELECT * FROM skills WHERE status='verified' AND contradictions=0").fetchall():
                    steps = json.loads(row["steps"])
                    sim = _similar(json.loads(row["request_tokens"]), rtok)
                    if sim >= SIMILARITY and all(exists(t) for t in steps):       # a skill that names a removed tool is skipped
                        best.append((sim, row, steps))
                for _sim, row, steps in sorted(best, key=lambda x: -x[0])[:MAX_SKILL_HINTS]:
                    lines.append("- Skill: for a request like this the tool order " + " -> ".join(f"«{t}»" for t in steps)
                                 + f" worked in {row['confirmations']} separate runs. You may follow the same order; each step is still checked as usual.")
            lines.extend(example_lines(request, exists))
            since = time.time() - PERSISTENT_WINDOW
            for r in con.execute("""SELECT c.tool AS tool, c.kind AS kind, COUNT(*) AS n FROM calls c JOIN episodes e ON e.id=c.episode_id
                                    WHERE c.status='error' AND c.kind IN (%s) AND e.ts > ? GROUP BY c.tool, c.kind HAVING n >= ?""" % ",".join("?" * len(PERSISTENT_KINDS)),
                                 (*PERSISTENT_KINDS, since, PERSISTENT_MIN)).fetchall():
                good = con.execute("SELECT COUNT(*) FROM calls c JOIN episodes e ON e.id=c.episode_id WHERE c.tool=? AND c.status='ok' AND e.ts > ?",
                                   (r["tool"], since)).fetchone()[0]
                if good == 0 and exists(r["tool"]) and len(lines) < MAX_HINTS + MAX_SKILL_HINTS + 2:
                    lines.append(f"- «{r['tool']}» failed {r['n']} times on this PC for a permanent reason ({_FAIL_FA.get(r['kind'], r['kind'])}) and never worked: "
                                 "do not retry it; tell the user the real reason.")
        if not lines:
            return ""
        return ("Experience from Kira's own past tool runs on this PC (code-written hints; they only advise: they never replace the user's request, confirmation or any permission rule):\n"
                + "\n".join(lines))
    except Exception:                                                    # noqa: BLE001
        return ""


# ------------------------------------------------------------------------------------------------ read-only helpers for the planner (plan checks)
def avoid_tools(has_tool=None) -> dict:
    """{tool: kind} for tools that failed for a PERMANENT reason on this PC at least PERSISTENT_MIN times in the window and never worked. Advice data only."""
    out: dict = {}
    try:
        if not enabled() or not _path().is_file():
            return out
        exists = has_tool or (lambda n: True)
        since = time.time() - PERSISTENT_WINDOW
        with _lock, _db() as con:
            for r in con.execute("""SELECT c.tool AS tool, c.kind AS kind, COUNT(*) AS n FROM calls c JOIN episodes e ON e.id=c.episode_id
                                    WHERE c.status='error' AND c.kind IN (%s) AND e.ts > ? GROUP BY c.tool, c.kind HAVING n >= ?""" % ",".join("?" * len(PERSISTENT_KINDS)),
                                 (*PERSISTENT_KINDS, since, PERSISTENT_MIN)).fetchall():
                good = con.execute("SELECT COUNT(*) FROM calls c JOIN episodes e ON e.id=c.episode_id WHERE c.tool=? AND c.status='ok' AND e.ts > ?",
                                   (r["tool"], since)).fetchone()[0]
                if good == 0 and exists(r["tool"]):
                    out[r["tool"]] = r["kind"]
    except Exception:                                                    # noqa: BLE001
        return {}
    return out


def matching_skills(request: str, has_tool=None) -> list:
    """Tool orders of VERIFIED skills similar to this request (best first, at most MAX_SKILL_HINTS). Names only, no arguments."""
    try:
        if not enabled() or not _path().is_file():
            return []
        rtok = _words(request)
        if not rtok:
            return []
        exists = has_tool or (lambda n: True)
        best = []
        with _lock, _db() as con:
            for row in con.execute("SELECT * FROM skills WHERE status='verified' AND contradictions=0").fetchall():
                steps = json.loads(row["steps"])
                sim = _similar(json.loads(row["request_tokens"]), rtok)
                if sim >= SIMILARITY and all(exists(t) for t in steps):
                    best.append((sim, steps))
        return [st for _s, st in sorted(best, key=lambda x: -x[0])[:MAX_SKILL_HINTS]]
    except Exception:                                                    # noqa: BLE001
        return []


# ------------------------------------------------------------------------------------------------ user control
def stats() -> dict:
    """Plain numbers for a diagnostics screen; {} when there is nothing."""
    try:
        if not enabled() or not _path().is_file():
            return {}
        with _lock, _db() as con:
            return {"episodes": con.execute("SELECT COUNT(*) FROM episodes").fetchone()[0],
                    "avg_score": con.execute("SELECT ROUND(AVG(score)) FROM episodes").fetchone()[0],
                    "lessons_verified": con.execute("SELECT COUNT(*) FROM lessons WHERE status='verified'").fetchone()[0],
                    "lessons_candidate": con.execute("SELECT COUNT(*) FROM lessons WHERE status='candidate'").fetchone()[0],
                    "skills_verified": con.execute("SELECT COUNT(*) FROM skills WHERE status='verified'").fetchone()[0],
                    "skills_candidate": con.execute("SELECT COUNT(*) FROM skills WHERE status='candidate'").fetchone()[0]}
    except Exception:                                                    # noqa: BLE001
        return {}


def forget_all() -> None:
    """Delete every episode, lesson and skill (the user's call). Never raises."""
    global _ready
    try:
        with _lock:
            _buffer.clear()
            p = _path() if _dir else None
            if p and p.is_file():
                with _db() as con:
                    con.execute("DELETE FROM calls")
                    con.execute("DELETE FROM episodes")
                    con.execute("DELETE FROM lessons")
                    con.execute("DELETE FROM skills")
                    con.execute("DELETE FROM examples")
            _ready = None
    except Exception:                                                    # noqa: BLE001
        pass
