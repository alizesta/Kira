"""Real capability benchmark of the usable routes (kira/smart.py then prefers the measured best model).

Five tiny requests per route, scored by CODE (no judge model): tool-call format, "do it yourself" follow-up, plain chat, Persian, a small reasoning task.
Speed comes from the same runs. Cloud routes use about 5 short requests of API quota each, so the caller asks the person first.
Only advice: it changes which route is tried FIRST for tool / deep turns; permissions, confirmations and failover are untouched."""
from __future__ import annotations

import re
import time

from . import smart

TESTS = ("tool_format", "followup", "chat", "persian", "reasoning")
MAX_TOKENS = 260
CATALOG = ("- open_app(name: string, url: string=) — open an installed program; with `url` it opens that link inside that browser program (name=msedge, url=claude.ai)\n"
           "- open_url(url: string, browser: string=) — open a link, in the browser named in `browser` (edge | chrome | firefox | brave | opera) or in the default one\n"
           "- get_datetime() — current date and time")
SYSTEM_BASE = "You are Kira, a Persian-speaking assistant living on the user's Windows PC. Answer in Persian unless asked otherwise."
_THINK_RX = re.compile(r"<think>.*?</think>", re.S | re.I)
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def tools_prompt() -> str:
    from .tools import protocol
    return SYSTEM_BASE + "\n\n" + protocol.build_block(CATALOG)


def cases() -> dict:
    """name -> (system prompt, messages)."""
    sysp = tools_prompt()
    return {
        "tool_format": (sysp, [{"role": "user", "content": "کیرا اج رو باز کن و سایت claude.ai رو توش بیار بالا"}]),
        "followup": (sysp, [{"role": "user", "content": "اج رو باز کن و claude.ai رو توش بیار"},
                            {"role": "assistant", "content": "نمی‌تونم مستقیم این کار رو بکنم؛ خودت باز کن."},
                            {"role": "user", "content": "کد نده، خودت انجامش بده"}]),
        "chat": (sysp, [{"role": "user", "content": "سلام، حالت چطوره؟"}]),
        "persian": (SYSTEM_BASE, [{"role": "user", "content": "یک جمله‌ی کوتاه فارسی بنویس که کلمه‌ی «کتاب» توش باشه."}]),
        "reasoning": (SYSTEM_BASE, [{"role": "user", "content": "۱۲ تا سیب داری. نصفش رو به علی می‌دی و ۲ تا هم خودت می‌خوری. چندتا می‌مونه؟ فقط عدد بنویس."}]),
    }


def clean(text: str) -> str:
    return _THINK_RX.sub("", str(text or "")).strip()


# ------------------------------------------------------------------ scoring (pure functions, unit-tested)
def score_tool_call(text: str) -> int:
    from .tools import protocol
    from .tools.apps import browser_key
    t = clean(text)
    real = protocol.OPEN in t.lower()
    calls, _errs = protocol.parse_calls(t)
    if not calls:
        return 0
    c = calls[0]
    args = c.get("args") or {}
    link = "claude.ai" in str(args.get("url", "")).lower()
    edge = (c["tool"] == "open_app" and browser_key(args.get("name")) == "edge") or (c["tool"] == "open_url" and browser_key(args.get("browser")) == "edge")
    if c["tool"] in ("open_app", "open_url") and link and edge:
        return 100 if real else 50                          # right call, but in the invalid [tool: ...] form
    if c["tool"] in ("open_app", "open_url") and (link or edge):
        return 70 if real else 30
    return 30 if real else 10


def score_chat(text: str) -> int:
    from .tools import protocol
    t = clean(text)
    if not t or protocol.OPEN in t.lower() or protocol.parse_calls(t)[0]:
        return 0                                            # a greeting must never become a tool call
    return 100 if re.search(r"[\u0600-\u06ff]", t) else 50


def score_persian(text: str) -> int:
    t = clean(text)
    letters = re.findall(r"[A-Za-z\u0600-\u06ff]", t)
    if not letters:
        return 0
    ratio = len(re.findall(r"[\u0600-\u06ff]", t)) / len(letters)
    if ratio >= 0.8:
        return 100 if "کتاب" in t else 70
    return 40 if ratio >= 0.4 else 0


def score_reasoning(text: str) -> int:
    nums = re.findall(r"\d+", clean(text).translate(_DIGITS))
    if not nums:
        return 0
    return 100 if nums[-1] == "4" else (55 if "4" in nums else 0)


def score_speed(avg_ms: float | None) -> int:
    if avg_ms is None:
        return 0
    return 100 if avg_ms < 2500 else 80 if avg_ms < 5000 else 55 if avg_ms < 10000 else 30


SCORERS = {"tool_format": score_tool_call, "followup": score_tool_call, "chat": score_chat, "persian": score_persian, "reasoning": score_reasoning}


def build_profile(outputs: dict, times: list, now: float | None = None) -> dict | None:
    """outputs: test name -> text (missing = the request failed). None when fewer than 3 requests were answered (quota / outage: do not judge)."""
    if len(outputs) < 3:
        return None
    scores = {name: SCORERS[name](text) for name, text in outputs.items()}
    scores["speed"] = score_speed(sum(times) / len(times) if times else None)
    weights = {"tool_format": .30, "followup": .20, "persian": .15, "reasoning": .15, "chat": .10, "speed": .10}
    have = {k: w for k, w in weights.items() if k in scores}
    overall = round(sum(scores[k] * w for k, w in have.items()) / sum(have.values()))
    return {"ts": now or time.time(), "scores": scores, "overall": overall, "answered": len(outputs), "avg_ms": int(sum(times) / len(times)) if times else None}


# ------------------------------------------------------------------ running
def _ask(provider, system, messages, sleep):
    """One short request; one retry after a rate limit. -> (text, ms)."""
    for attempt in (0, 1):
        t0 = time.monotonic()
        try:
            text = "".join(provider.stream(messages, system, 0.2, max_tokens=MAX_TOKENS))
            return clean(text), int((time.monotonic() - t0) * 1000)
        except Exception as exc:                            # noqa: BLE001
            wait = getattr(exc, "retry_after", None)
            if attempt == 0 and (getattr(exc, "kind", "") == "rate" or getattr(exc, "status_code", None) == 429):
                sleep(min(float(wait or 12), 25))
                continue
            raise


def run(router, route_ids, on_progress=None, sleep=time.sleep, gap=2.0) -> list:
    """Benchmark the routes ONE AT A TIME (shares the router's lock with chat). Returns one row per route and stores each good profile."""
    if not router._lock.acquire(blocking=False):
        raise RuntimeError("یک درخواست دیگر در حال انجام است؛ بعد از پایان آن تست توانایی را اجرا کن.")
    rows = []
    try:
        by_id = {r["id"]: r for r in router.routes()}
        router._cancel.clear()
        suite = cases()
        for rid in route_ids:
            route = by_id.get(rid)
            if route is None or router._cancel.is_set():
                continue
            info = router.route_info(route)
            if on_progress:
                on_progress({"phase": "running", **info})
            row = {**info, "ok": False, "profile": None, "error": None}
            outputs, times, last_error = {}, [], None
            try:
                provider = router._make_provider(route)
                for name in TESTS:
                    if router._cancel.is_set():
                        break
                    system, msgs = suite[name]
                    try:
                        text, ms = _ask(provider, system, msgs, sleep)
                        if text:
                            outputs[name] = text
                            times.append(ms)
                    except Exception as exc:                # noqa: BLE001
                        last_error = str(exc)[:160]
                    sleep(gap)
            except Exception as exc:                        # noqa: BLE001
                last_error = str(exc)[:160]
            profile = build_profile(outputs, times)
            if profile:
                smart.save_profile(route["provider"], route["model"], profile)
                row.update(ok=True, profile=profile)
            else:
                row["error"] = last_error or "پاسخ کافی نیامد (سهمیه یا قطعی)؛ چیزی ذخیره نشد."
            rows.append(row)
            if on_progress:
                on_progress({"phase": "done", **row})
        return rows
    finally:
        router._lock.release()


def format_row(r: dict) -> str:
    if not r.get("ok"):
        return f"✕ {r['label']} / {r['model']}: {r.get('error') or 'ناموفق'}"
    p, s = r["profile"], r["profile"]["scores"]
    return (f"✓ {r['label']} / {r['model']}: امتیاز کل {p['overall']} · ابزار {s.get('tool_format', '-')} · ادامه‌ی دستور {s.get('followup', '-')} · فارسی {s.get('persian', '-')} · "
            f"استدلال {s.get('reasoning', '-')} · گپ {s.get('chat', '-')} · سرعت {s.get('speed', '-')} ({p.get('avg_ms')} ms) · {p['answered']}/5 پاسخ")
