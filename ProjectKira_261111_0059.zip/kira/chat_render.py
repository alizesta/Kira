"""Chat message rendering with Persian-aware direction and safe, compact Markdown.

The renderer is deliberately kept independent from Qt.  It produces a conservative
HTML subset supported by QTextDocument, so chat presentation can evolve without
changing message storage, routing, or streaming logic.
"""
from __future__ import annotations

import base64
import html
import re
import unicodedata
from urllib.parse import unquote, urlparse

RTL, LTR = "rtl", "ltr"

# kind -> (bubble colour, name colour, text colour, physical side of the bubble)
STYLES = {
    "user":      ("#302d58", "#cfc4ff", "#f4f2ff", "right"),
    "assistant": ("#1b293b", "#82eee3", "#edf5ff", "left"),
    "system":    ("#171f30", "#91a4c5", "#b3bfd4", "left"),
    "error":     ("#402331", "#ff9eaf", "#ffe8ec", "left"),
}
ACCENTS = {"user": "#8d7cff", "assistant": "#27cfc5", "system": "#536987", "error": "#e85b91"}


def detect_direction(text: str, default: str = RTL) -> str:
    """'rtl' when right-to-left letters are at least as many as left-to-right ones."""
    rtl = ltr = 0
    for ch in str(text or ""):
        kind = unicodedata.bidirectional(ch)
        if kind in ("R", "AL"):
            rtl += 1
        elif kind == "L":
            ltr += 1
    if rtl == 0 and ltr == 0:
        return default
    return RTL if rtl >= ltr else LTR


def _lines(text: str):
    lines = str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return lines or [""]


_URL = re.compile(r"https?://[^\s<>\"')\]،؛]+")
_LINK_COLOUR = "#8fb8ff"


def short_url(url: str, limit: int = 56) -> str:
    """Readable label for a link: host + decoded path, shortened."""
    parts = urlparse(url)
    label = (parts.netloc.removeprefix("www.") + unquote(parts.path or "") + (("?" + parts.query) if parts.query else "")).rstrip("/")
    return label if len(label) <= limit else label[:limit - 1] + "…"


def _linkify(escaped: str) -> str:
    """Turn bare URLs in already escaped text into short clickable links."""
    def repl(match):
        url = match.group(0)
        trail = ""
        while url and url[-1] in ".,;:!?":
            trail, url = url[-1] + trail, url[:-1]
        safe_url = html.escape(html.unescape(url), quote=True)
        label = html.escape(short_url(html.unescape(url)), quote=False)
        return f'<a href="{safe_url}" style="color:{_LINK_COLOUR};">{label}</a>{trail}'
    return _URL.sub(repl, escaped)


def _inline_markup(line: str) -> str:
    """Render a small safe Markdown subset without interpreting raw HTML."""
    code_fragments = {}

    def hold_code(match):
        key = f"KIRACODETOKEN{len(code_fragments)}X"
        code_fragments[key] = (
            '<span style="background-color:#0b1422;color:#a9e9df;'
            'border:1px solid #2c475f;">'
            + html.escape(match.group(1), quote=False)
            + '</span>'
        )
        return key

    protected = re.sub(r"`([^`\n]+)`", hold_code, str(line or ""))
    rendered = _linkify(html.escape(protected, quote=False))
    rendered = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", rendered)
    rendered = re.sub(r"~~(.+?)~~", r"<s>\1</s>", rendered)
    rendered = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<i>\1</i>", rendered)
    for key, fragment in code_fragments.items():
        rendered = rendered.replace(key, fragment)
    return rendered or "&nbsp;"


def _paragraph(line: str, colour: str, ui_dir: str, size: str = "", italic: bool = False,
               force_dir: str = "", extra_style: str = "") -> str:
    direction = force_dir or detect_direction(line, ui_dir)
    align = "right" if direction == RTL else "left"
    style = f"color:{colour};margin:2px 0;{size}{extra_style}" + ("font-style:italic;" if italic else "")
    return f'<p dir="{direction}" align="{align}" style="{style}">{_inline_markup(line)}</p>'


def _code_block(code: str, language: str = "") -> str:
    label = html.escape((language or "CODE")[:24].upper(), quote=False)
    escaped = html.escape(code.rstrip("\n"), quote=False) or " "
    return (
        '<table align="left" width="100%" cellspacing="0" cellpadding="8" '
        'style="margin:6px 0;border:1px solid #34516c;">'
        '<tr><td bgcolor="#0b1422">'
        f'<p dir="ltr" align="left" style="color:#82b9c8;font-size:8pt;font-weight:600;margin:0 0 5px 0;">{label}</p>'
        f'<pre style="white-space:pre-wrap;color:#d9e8f5;font-family:Consolas,monospace;font-size:9pt;">{escaped}</pre>'
        '</td></tr></table>'
    )


def _render_body(text: str, kind: str, text_colour: str, ui_dir: str, side: str) -> str:
    lines = _lines(text)
    output = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("```"):
            language = stripped[3:].strip()
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            output.append(_code_block("\n".join(code), language))
            continue
        if not stripped:
            output.append('<p style="margin:3px 0;font-size:4pt;">&nbsp;</p>')
            i += 1
            continue
        if stripped.startswith(">"):
            quoted = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quoted.append(re.sub(r"^\s*>\s?", "", lines[i]))
                i += 1
            quote_dir = detect_direction("\n".join(quoted), ui_dir)
            quote_align = "right" if quote_dir == RTL else "left"
            quote_body = "".join(_paragraph(part, text_colour, ui_dir, force_dir=quote_dir,
                                               extra_style="margin:2px 0;") for part in quoted)
            output.append(
                f'<table align="{side}" width="96%" cellspacing="0" cellpadding="7" '
                'style="margin:4px 0;border-left:3px solid #36bfc0;">'
                f'<tr><td bgcolor="#17263a" dir="{quote_dir}" align="{quote_align}">{quote_body}</td></tr></table>'
            )
            continue
        heading = re.match(r"^\s*(#{1,3})\s+(.+?)\s*#*\s*$", line)
        if heading:
            level = len(heading.group(1))
            px = {1: "13pt", 2: "11.5pt", 3: "10.5pt"}[level]
            output.append(_paragraph(heading.group(2), text_colour, ui_dir,
                                     size=f"font-size:{px};font-weight:700;", extra_style="margin-top:5px;"))
            i += 1
            continue
        bullet = re.match(r"^\s*[-*+]\s+(.+)$", line)
        numbered = re.match(r"^\s*(\d+)[.)]\s+(.+)$", line)
        if bullet:
            content = "• " + bullet.group(1)
            output.append(_paragraph(content, text_colour, ui_dir, extra_style="margin-left:9px;"))
        elif numbered:
            content = numbered.group(1) + ". " + numbered.group(2)
            output.append(_paragraph(content, text_colour, ui_dir, extra_style="margin-left:9px;"))
        else:
            output.append(_paragraph(line, text_colour, ui_dir, italic=(kind == "system")))
        i += 1
    return "".join(output)


def copy_token(text: str) -> str:
    """URL-safe payload used by the chat's local copy action."""
    return base64.urlsafe_b64encode(str(text or "").encode("utf-8")).decode("ascii").rstrip("=")


def decode_copy_token(token: str) -> str:
    """Decode a copy action payload; invalid tokens return an empty string."""
    try:
        value = str(token or "").strip()
        value += "=" * (-len(value) % 4)
        return base64.urlsafe_b64decode(value.encode("ascii")).decode("utf-8")
    except (ValueError, UnicodeError):
        return ""


def sources_html(results, title: str = "منابع") -> str:
    """Compact list of sources: the page title is the link, the site name follows it."""
    rows = []
    for i, result in enumerate(results or [], 1):
        url = str(result.get("url") or "")
        if not url.startswith(("http://", "https://")):
            continue
        name = html.escape(str(result.get("title") or short_url(url)), quote=False)
        site = html.escape(urlparse(url).netloc.removeprefix("www."), quote=False)
        href = html.escape(url, quote=True)
        rows.append(
            f'<p dir="ltr" align="left" style="margin:2px 0;color:#a2a8c0;">{i}. '
            f'<a href="{href}" style="color:{_LINK_COLOUR};">{name}</a> '
            f'<span style="color:#6f7590;">· {site}</span></p>'
        )
    if not rows:
        return ""
    return f'<p dir="rtl" align="right" style="margin:1px 0 3px 0;color:#8d93ab;font-weight:600;">🌐 {html.escape(title)}</p>' + "".join(rows)


def message_html(kind: str, name: str, text: str, ui_dir: str = RTL, extra_html: str = "", copyable: bool = True) -> str:
    bubble, name_colour, text_colour, side = STYLES.get(kind, STYLES["assistant"])
    accent = ACCENTS.get(kind, ACCENTS["assistant"])
    lines = _lines(text)
    body = "" if (extra_html and not str(text or "").strip()) else _render_body(text, kind, text_colour, ui_dir, side)
    header_dir = detect_direction(lines[0], ui_dir)
    header_align = "right" if header_dir == RTL else "left"
    name_html = html.escape(str(name or ""), quote=False)
    copy_html = ""
    if copyable and str(text or "").strip():
        token = copy_token(text)
        copy_html = f'<a href="kira-copy:{token}" style="color:#91b8d0;font-size:8pt;text-decoration:none;">⧉ کپی</a>'
    separator = '<span style="color:#526987;"> · </span>' if name_html and copy_html else ""
    head = ""
    if name_html or copy_html:
        head = (
            f'<p dir="{header_dir}" align="{header_align}" '
            f'style="color:{name_colour};font-size:9pt;font-weight:650;margin:0 0 6px 0;">'
            f'<b>{name_html}</b>{separator}{copy_html}</p>'
        )
    # Tables render consistently in Qt's rich-text engine and maintain a clear role accent.
    return (
        f'<table align="{side}" width="88%" cellspacing="0" cellpadding="12" '
        f'style="margin:8px 4px;border:1px solid {accent};">'
        f'<tr><td bgcolor="{bubble}">{head}{extra_html}{body}</td></tr></table>'
        '<p style="margin:0;font-size:5pt;">&nbsp;</p>'
    )
