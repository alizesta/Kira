"""T6 Phase 3 - devices: USB, Bluetooth, camera, microphone, printers. No PowerShell.

  * device_list      pnputil.exe /enum-devices (Windows 10 2004+) with a FIXED device-class GUID per kind. Output is read by position around the class GUID line, so it
                     does not depend on the Windows language. Device instance ids (serial numbers) are never shown.
  * printer_list / printer_set_default   registry list of installed printers + winspool Get/SetDefaultPrinterW (ctypes, one call each). Re-read afterwards; if the new default
                     did not stick, the old one is restored (journaled).
  * device_privacy_get   READ ONLY: whether Windows lets apps use the camera / microphone. Changing it is a PROTECTED privacy decision: Kira only reports it and explains the
                     manual path (Settings -> Privacy & security).

NOT implemented (reported as UNSUPPORTED, not hidden): pairing / connecting / disconnecting a Bluetooth device, ejecting or disabling a USB device, enabling / disabling a camera
or microphone, print-queue control. They need WinRT or Administrator and have not been designed with a safe, verified path yet.
"""
from __future__ import annotations

import re
import sys

from .registry import ToolError, Param, READ, ACTION
from .sysexe import run_exe, IS_WIN
from .wincontrol import Capability, WinModule

try:
    import winreg
except Exception:                                             # noqa: BLE001
    winreg = None

_GUID_RX = re.compile(r"\{[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\}")
# kind -> ((class GUID, ...), Persian label). The GUIDs are fixed here; the model only picks the kind.
_KINDS = {
    "usb": (("{36fc9e60-c465-11cf-8056-444553540000}",), "USB"),
    "bluetooth": (("{e0cbf06c-cd8b-4647-bb8a-263b43f0f974}",), "بلوتوث"),
    "camera": (("{ca3e7ab9-b4c3-4ae6-8251-579ef933890f}", "{6bdd1fc6-810f-11d0-bec7-08002be2092f}"), "دوربین"),
    "microphone": (("{c166523c-fe0c-4a94-a586-f1a80cfbbf3e}",), "میکروفون"),
    "printer": (("{4d36e979-e325-11ce-bfc1-08002be10318}",), "چاپگر"),
}
_MIC_RX = re.compile(r"micro|mic\b|mic\)|میکروفون|headset|line in|array", re.I)
_PRINTERS = r"SYSTEM\CurrentControlSet\Control\Print\Printers"
_CONSENT = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore"


def _need_win(what: str) -> None:
    if not IS_WIN:
        raise ToolError(f"{what} فقط روی ویندوز ممکن است.", kind="missing_component")


def _val(line: str) -> str:
    return line.split(":", 1)[1].strip() if ":" in line else line.strip()


def _parse_pnputil(text: str) -> list:
    """-> [{'desc','class','maker','status'}]. A block is the group of lines between blank lines; the class GUID line anchors the fields:
    ... Device Description, Class Name, Class GUID, Manufacturer Name, Status ... (same order in every Windows language)."""
    out = []
    for block in re.split(r"\r?\n\s*\r?\n", text):
        lines = [ln for ln in block.splitlines() if ln.strip()]
        idx = next((i for i, ln in enumerate(lines) if _GUID_RX.search(ln) and ":" in ln), -1)
        if idx < 2:
            continue
        out.append({"desc": _val(lines[idx - 2]), "class": _val(lines[idx - 1]), "maker": _val(lines[idx + 1]) if idx + 1 < len(lines) else "",
                    "status": _val(lines[idx + 2]) if idx + 2 < len(lines) else ""})
    return out


class DeviceTools:
    def __init__(self, access=None):
        self.access = access

    # ------------------------------------------------------------ device list
    def device_list(self, a: dict) -> str:
        _need_win("فهرست دستگاه‌ها")
        kind = str(a["kind"]).strip().lower()
        if kind not in _KINDS:
            raise ToolError("kind باید یکی از usb, bluetooth, camera, microphone, printer باشد.", kind="bad_args")
        guids, label = _KINDS[kind]
        every = str(a.get("include_disconnected", "")).strip().lower() in ("1", "true", "yes")
        items, unsupported = [], False
        for g in guids:
            args = ["/enum-devices"] + ([] if every else ["/connected"]) + ["/class", g]
            rc, out = run_exe("pnputil", args, timeout=25)
            found = _parse_pnputil(out)
            if rc != 0 and not found:
                unsupported = unsupported or bool(re.search(r"invalid|unknown|not recogni|\?", out, re.I)) or rc == 1
                continue
            items += found
        if kind == "microphone":
            items = [i for i in items if _MIC_RX.search(i["desc"])]
        seen, uniq = set(), []
        for i in items:
            key = (i["desc"], i["status"])
            if key not in seen:
                seen.add(key)
                uniq.append(i)
        if not uniq:
            if unsupported and not items:
                raise ToolError("فهرست دستگاه‌ها خوانده نشد: pnputil در این ویندوز /enum-devices را پشتیبانی نمی‌کند (نیاز به Windows 10 نسخه‌ی 2004 یا جدیدتر) "
                                "یا اجازه‌ی خواندن نداد.", kind="missing_component")
            return f"دستگاه {label}ی " + ("ثبت‌شده" if every else "متصل") + " پیدا نشد."
        lines = [f"{i['desc']}" + (f" ({i['maker']})" if i["maker"] and i["maker"].lower() not in i["desc"].lower() else "") + (f" — {i['status']}" if i["status"] else "") for i in uniq[:40]]
        note = " (فهرست میکروفون‌ها از نام نقطه‌های صدا حدس زده می‌شود و کامل بودنش تضمین نیست.)" if kind == "microphone" else ""
        return f"{label} — " + ("دستگاه‌های ثبت‌شده" if every else "دستگاه‌های متصل") + f" ({len(uniq)}):\n" + "\n".join(lines) + note

    # ------------------------------------------------------------ printers
    @staticmethod
    def _printer_names() -> list:
        names = []
        if winreg is None:
            return names
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, _PRINTERS, 0, winreg.KEY_READ) as k:
                i = 0
                while True:
                    try:
                        key = winreg.EnumKey(k, i)
                    except OSError:
                        break
                    names.append(key.replace(",", "\\") if key.startswith(",,") else key)
                    i += 1
        except OSError:
            pass
        return names

    @staticmethod
    def _default_printer() -> str:
        import ctypes
        size = ctypes.c_ulong(0)
        ctypes.windll.winspool.GetDefaultPrinterW(None, ctypes.byref(size))
        if size.value == 0:
            return ""
        buf = ctypes.create_unicode_buffer(size.value)
        return buf.value if ctypes.windll.winspool.GetDefaultPrinterW(buf, ctypes.byref(size)) else ""

    def printer_list(self, a: dict) -> str:
        _need_win("فهرست چاپگرها")
        names = self._printer_names()
        if not names:
            return "چاپگری نصب‌شده پیدا نشد (یا فهرست از رجیستری خوانده نشد)."
        default = self._default_printer()
        rows = [n + (" ← پیش‌فرض" if default and n.lower() == default.lower() else "") for n in names[:40]]
        return f"چاپگرهای نصب‌شده ({len(names)}):\n" + "\n".join(rows)

    def _event(self, tool: str, ok: bool, text: str) -> None:
        if self.access is not None:
            try:
                self.access.record_event(tool, "devices", "CONTROL", "ok" if ok else "error", "win32", text, "verified" if ok else "unknown", "" if ok else "api_failure")
            except Exception:                                      # noqa: BLE001
                pass

    def printer_set_default(self, a: dict) -> str:
        import ctypes
        _need_win("تغییر چاپگر پیش‌فرض")
        want = str(a["name"]).strip()
        name = next((n for n in self._printer_names() if n.lower() == want.lower()), "")
        if not name:
            raise ToolError(f"چاپگر «{want}» بین چاپگرهای نصب‌شده نیست. با printer_list نام دقیق را ببین.", kind="bad_args")
        before = self._default_printer()
        if before.lower() == name.lower():
            return f"«{name}» همین حالا چاپگر پیش‌فرض است؛ چیزی تغییر نکرد."
        ok = bool(ctypes.windll.winspool.SetDefaultPrinterW(name))
        now = self._default_printer()
        if ok and now.lower() == name.lower():
            auto = False
            if winreg is not None:
                try:
                    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows NT\CurrentVersion\Windows", 0, winreg.KEY_READ) as k:
                        auto = winreg.QueryValueEx(k, "LegacyDefaultPrinterMode")[0] == 0
                except OSError:
                    pass
            return (f"چاپگر پیش‌فرض «{name}» شد و دوباره خوانده شد (قبلی: «{before or 'نداشت'}»)." +
                    (" توجه: «Let Windows manage my default printer» روشن است و ویندوز ممکن است بعداً آن را خودش عوض کند." if auto else ""))
        tail = ""
        if before:
            ctypes.windll.winspool.SetDefaultPrinterW(before)
            back = self._default_printer().lower() == before.lower()
            self._event("printer.rollback", back, f"بازگشت به «{before}» " + ("تأیید شد" if back else "تأیید نشد (UNKNOWN)"))
            tail = " چاپگر قبلی بازگردانده و تأیید شد." if back else " بازگرداندن چاپگر قبلی هم تأیید نشد؛ وضعیت نامشخص است (UNKNOWN)."
        raise ToolError(f"ویندوز چاپگر پیش‌فرض را «{name}» نکرد (الان: «{now or 'نامعلوم'}»).{tail}", kind="api_failure")

    # ------------------------------------------------------------ privacy (READ ONLY)
    def device_privacy_get(self, a: dict) -> str:
        _need_win("خواندن حریم خصوصی")
        parts = []
        for key, fa in (("webcam", "دوربین"), ("microphone", "میکروفون")):
            vals = []
            for hive, tag in ((winreg.HKEY_LOCAL_MACHINE, "کل سیستم"), (winreg.HKEY_CURRENT_USER, "کاربر فعلی")) if winreg else ():
                try:
                    with winreg.OpenKey(hive, _CONSENT + "\\" + key, 0, winreg.KEY_READ) as k:
                        vals.append(f"{tag}: {winreg.QueryValueEx(k, 'Value')[0]}")
                except OSError:
                    continue
            parts.append(f"دسترسی برنامه‌ها به {fa}: " + ("، ".join(vals) if vals else "خوانده نشد"))
        return ("؛ ".join(parts) + ". Allow = مجاز، Deny = مسدود. تغییر این‌ها تصمیم حریم خصوصی است و Kira آن را انجام نمی‌دهد؛ مسیر دستی: "
                "Settings ← Privacy & security ← Camera / Microphone.")


_RX = lambda *w: re.compile("|".join(w), re.I)
PRINTER_RX = _RX(r"پرینتر", r"چاپگر", r"printer", r"پیش\s*فرض", r"default")


class DevicesModule(WinModule):
    domain = "devices"

    def __init__(self, access=None):
        self.t = DeviceTools(access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("devices",)
        return [
            Capability("device_list", "devices", "list connected USB / Bluetooth / camera / microphone / printer devices (kind). Names only - no serial numbers. include_disconnected=true "
                       "also shows registered but absent devices. Changes nothing. Pairing / connecting / ejecting / enabling devices is NOT supported",
                       t.device_list, risk=READ, params=(Param("kind", "string", "usb | bluetooth | camera | microphone | printer", True, None, tuple(_KINDS)),
                                                         Param("include_disconnected", "string", "true to include absent devices", False, None, ("true", "false"))),
                       categories=cat, backend="system-exe"),
            Capability("printer_list", "devices", "list installed printers and which one is the default (changes nothing)", t.printer_list, risk=READ, categories=cat, backend="win32"),
            Capability("printer_set_default", "devices", "make ONE installed printer the Windows default (name from printer_list); re-reads the real default and restores the old one if it did not stick. "
                       "ONLY on explicit request", t.printer_set_default, risk=ACTION, params=(Param("name", "string", "printer name exactly as printer_list shows it", True),), categories=cat,
                       backend="win32", intent_rx=PRINTER_RX, memo=lambda a, x: f"printer_set_default → {a.get('name')}", verifies_result=True, changes_system=True),
            Capability("device_privacy_get", "devices", "read whether Windows lets apps use the camera and microphone (changes nothing; Kira cannot change it)", t.device_privacy_get,
                       risk=READ, categories=cat, backend="win32"),
        ]
