"""Shared, controlled Windows PowerShell runner for Windows Control modules (Bluetooth, Audio, later wallpaper / tray / system).

What it is: ONE place that starts Windows PowerShell 5.1 with a FIXED script and returns the parsed JSON the script printed.

What it is not: a shell. Rules that are enforced here (not just promised):
  * Only a `FixedScript` object can be run. Its text is created once, at import time, by the module that owns it. A plain `str` is refused (TypeError),
    so nobody can pass user / model text as a script by accident.
  * Variable data never becomes part of the script. A module passes it as environment variables named `KIRA_*` (the script reads `$env:KIRA_...`
    as DATA and parses it itself). Names and sizes are checked here; the module validates the values.
  * The script is sent with -EncodedCommand (base64 UTF-16LE): no quoting problem, no command line to inject into. `shell=False` always.
  * Windows PowerShell 5.1 is found by its real FILE, never by PATH: Sysnative (only for a 32-bit Python on 64-bit Windows, where System32 is redirected)
    -> System32 -> SysWOW64. When no such file exists the result is a fatal `missing_component` that lists every path that was checked.

Return value of run_fixed(): the JSON object the script printed, or {'ok': False, 'error': <real reason>, 'fatal': True} when PowerShell itself failed
(not found, timed out, no / invalid output); such a dict also carries `kind` (missing_component | timeout | powershell_failure, see registry.FAILURE_KINDS).
"""
from __future__ import annotations

import base64
import json
import os
import re
import subprocess
import sys

IS_WIN = sys.platform == "win32"
NO_WINDOW = 0x08000000 if IS_WIN else 0
_ENV_NAME_RX = re.compile(r"^KIRA_[A-Z0-9_]{1,40}$")
MAX_ENV_CHARS = 8000
_FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


class FixedScript:
    """A PowerShell script written by us, in source code. Create it once at module level; never build one from user or model text."""
    __slots__ = ("name", "text")

    def __init__(self, name: str, text: str):
        self.name = str(name)
        self.text = str(text)


def windows_dir() -> str:
    """The Windows folder: environment first, then the Windows API (works when the environment was stripped), then C:\\Windows."""
    for name in ("SystemRoot", "SYSTEMROOT", "windir", "WINDIR"):
        value = os.environ.get(name)
        if value and os.path.isdir(value):
            return value
    if IS_WIN:
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(520)
            if ctypes.windll.kernel32.GetWindowsDirectoryW(buf, 520) and os.path.isdir(buf.value):
                return buf.value
        except Exception:                                          # noqa: BLE001
            pass
    return r"C:\Windows"


def _is_wow64() -> bool:
    """True for a 32-bit Python on 64-bit Windows (System32 is then redirected to SysWOW64 and the virtual folder Sysnative exists)."""
    if not IS_WIN:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        flag = wintypes.BOOL(False)
        k32.GetCurrentProcess.restype = wintypes.HANDLE
        return bool(k32.IsWow64Process(k32.GetCurrentProcess(), ctypes.byref(flag))) and bool(flag.value)
    except Exception:                                              # noqa: BLE001
        return False


_PS_REL = os.path.join("WindowsPowerShell", "v1.0", "powershell.exe")


def powershell_candidates() -> list[str]:
    root = windows_dir()
    folders = ([os.path.join(root, "Sysnative")] if _is_wow64() else []) + [os.path.join(root, "System32"), os.path.join(root, "SysWOW64")]
    return [os.path.join(f, _PS_REL) for f in folders]


def powershell_path() -> str:
    """Full path of Windows PowerShell 5.1, or '' when no such FILE exists. There is no fallback to the bare name 'powershell.exe':
    that made start-up depend on PATH, and a missing file is reported as a missing file (with what was checked)."""
    for path in powershell_candidates():
        if os.path.isfile(path):
            return path
    return ""


def diagnose() -> str:
    """Plain-text state of the runner (nothing is run): bitness and which paths exist."""
    bits = 64 if sys.maxsize > 2 ** 32 else 32
    lines = [f"Python {bits}-bit" + (" روی ویندوز 64-bit (WOW64)" if _is_wow64() else ""), f"پوشه‌ی ویندوز: {windows_dir()}"]
    lines += [f"{'وجود دارد' if os.path.isfile(p) else 'وجود ندارد'}: {p}" for p in powershell_candidates()]
    return "\n".join(lines)


def _decode(raw: bytes) -> str:
    if not raw:
        return ""
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        pass
    encodings = []
    if IS_WIN:
        try:
            import ctypes
            encodings += [f"cp{ctypes.windll.kernel32.GetOEMCP()}", f"cp{ctypes.windll.kernel32.GetACP()}"]
        except Exception:                                          # noqa: BLE001
            pass
    for enc in encodings + ["cp1256"]:
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


def _clean_stderr(text: str) -> str:
    """PowerShell reports errors on stderr as CLIXML when redirected ('#< CLIXML <Objs ...><S S="Error">..</S>'): keep only the message."""
    text = (text or "").strip()
    if "CLIXML" in text or "<Objs" in text:
        parts = re.findall(r'<S S="[Ee]rror">(.*?)</S>', text, re.S)
        text = " ".join(parts) if parts else re.sub(r"<[^>]+>", " ", text.replace("#< CLIXML", " "))
        text = text.replace("_x000D__x000A_", " ").replace("_x000D_", " ").replace("_x000A_", " ")
    return re.sub(r"\s+", " ", text).strip()[:300]


def _find_json(text: str) -> dict:
    """The JSON object the script printed; warnings printed before or after it are tolerated. {} when there is none."""
    decoder, pos = json.JSONDecoder(), text.find("{")
    while pos != -1:
        try:
            obj, _end = decoder.raw_decode(text[pos:])
            if isinstance(obj, dict) and obj:
                return obj
        except ValueError:
            pass
        pos = text.find("{", pos + 1)
    return {}


def run_fixed(script: FixedScript, env: dict | None = None, timeout: int = 45, api_name: str = "ویندوز") -> dict:
    """Run a FixedScript. `env` = {'KIRA_NAME': 'value'} data for the script. -> parsed JSON dict, or a fatal error dict (see module doc)."""
    if not isinstance(script, FixedScript):
        raise TypeError("فقط FixedScript اجرا می‌شود؛ متن آزاد به‌عنوان اسکریپت پذیرفته نمی‌شود.")
    child_env = dict(os.environ)
    root = windows_dir()
    for name in ("SystemRoot", "windir"):                          # PowerShell / .NET need them even if the launcher stripped the environment
        if not child_env.get(name):
            child_env[name] = root
    for key, value in (env or {}).items():
        if not _ENV_NAME_RX.match(str(key)):
            raise ValueError(f"نام متغیر محیطی «{key}» مجاز نیست (باید با KIRA_ شروع شود).")
        value = str(value)
        if len(value) > MAX_ENV_CHARS:
            raise ValueError(f"مقدار «{key}» بیش از حد بزرگ است.")
        child_env[str(key)] = value
    exe = powershell_path()
    if not exe:
        return {"ok": False, "fatal": True, "kind": "missing_component",
                "error": "Windows PowerShell 5.1 به‌صورت فایل پیدا نشد. مسیرهای بررسی‌شده: " + " ؛ ".join(powershell_candidates()) + f" ({diagnose().splitlines()[0]})"}
    encoded = base64.b64encode(script.text.encode("utf-16-le")).decode("ascii")
    cwd = root if os.path.isdir(root) else None                    # a fixed, existing folder: a bad working directory must never look like "PowerShell not found"
    try:
        r = subprocess.run([exe, "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded], capture_output=True, timeout=timeout,
                           creationflags=NO_WINDOW, env=child_env, cwd=cwd, stdin=subprocess.DEVNULL)
    except FileNotFoundError as e:
        return {"ok": False, "fatal": True, "kind": "missing_component", "error": f"فایل Windows PowerShell هنگام اجرا پیدا نشد ({exe}): {e}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "fatal": True, "kind": "timeout", "error": f"پاسخ API {api_name} بیش از {str(timeout).translate(_FA_DIGITS)} ثانیه طول کشید"}
    except PermissionError as e:
        return {"ok": False, "fatal": True, "kind": "permission_denied", "error": f"ویندوز اجازه‌ی اجرای PowerShell را نداد ({exe}): {e}؛ آنتی‌ویروس یا AppLocker ممکن است مانع باشد"}
    except OSError as e:
        code = getattr(e, "winerror", None)
        if code == 193:
            return {"ok": False, "fatal": True, "kind": "powershell_failure", "error": f"فایل PowerShell با این Python سازگار نیست (WinError 193): {diagnose()}"}
        if code in (5, 1260):
            return {"ok": False, "fatal": True, "kind": "permission_denied", "error": f"دسترسی به اجرای PowerShell رد شد (WinError {code}) ({exe})"}
        return {"ok": False, "fatal": True, "kind": "powershell_failure", "error": f"اجرای PowerShell ممکن نشد ({exe}): {e}"}
    data = _find_json(_decode(r.stdout).strip())
    if not data:
        err = _clean_stderr(_decode(r.stderr)) or f"خروجی نامعتبر (کد {r.returncode})"
        return {"ok": False, "error": err, "fatal": True, "kind": "powershell_failure"}
    return data
