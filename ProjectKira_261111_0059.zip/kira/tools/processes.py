"""Process management (T6 Phase 1): list, inspect, close politely, end by force - with the normal user's rights only.

Rules enforced here (not left to the model):
  * identification is `pid` + `name` (the name must still match when the user confirms, so a reused PID can never be hit);
  * critical Windows processes, Kira itself (and its parent chain) and processes of other users / SYSTEM are never touched;
  * "Access denied" is reported as permission_denied. It is NEVER retried with elevation: ending a protected process is not something Kira does;
  * close (WM_CLOSE, like the X button) and end (TerminateProcess) are PROTECTED: the user confirms the exact pid + name first;
  * success = the process is really gone (re-checked). If it is still running the answer says UNVERIFIED / still running - never "done".
psutil is required for these tools (it is optional for the rest of Kira); without it the tools say so (missing_component).
"""
from __future__ import annotations

import os
import sys
import time

from .registry import ToolError, Param, READ, SENSITIVE, DENIED, ERROR
from .sysaccess import PROTECTED
import re

KILL_RX = re.compile(r"kill|force|terminate|end\s*task|(?<![\u0600-\u06ff])(?:اند|اِند)\s*تسک|(?<![\u0600-\u06ff])کیل(?![\u0600-\u06ff])|اجبار|بکش|بُکش|نابود|ببند.*(?:اجبار|زور)|فریز|هنگ|قفل\s*کرده|پاسخ\s*نمی", re.I)
from .winrunner import IS_WIN
from .wincontrol import Capability, WinModule

try:
    import psutil
except Exception:                                           # noqa: BLE001
    psutil = None

# Never closed / ended by Kira, whatever the user says (name without .exe, lower case).
CRITICAL = {"system", "system idle process", "registry", "memcompression", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "lsaiso", "svchost",
            "dwm", "fontdrvhost", "explorer", "sihost", "taskhostw", "runtimebroker", "ctfmon", "searchhost", "searchindexer", "startmenuexperiencehost",
            "shellexperiencehost", "textinputhost", "audiodg", "spoolsv", "wudfhost", "lsm", "msmpeng", "nissrv", "mpdefendercoreservice",
            "securityhealthservice", "securityhealthsystray", "smartscreen", "wmiprvse", "dllhost", "conhost", "csrss", "ntoskrnl", "vmmem", "applicationframehost",
            "systemsettings", "logonui", "userinit", "taskmgr"}
MAX_LIST = 30


def _stem(name: str) -> str:
    n = str(name or "").strip().lower()
    return n[:-4] if n.endswith(".exe") else n


def _need_psutil():
    if not IS_WIN:
        raise ToolError("مدیریت پردازش‌ها فقط روی ویندوز ممکن است.", ERROR, "missing_component")
    if psutil is None:
        raise ToolError("برای مدیریت پردازش‌ها بسته‌ی psutil لازم است (pip install psutil)؛ نصب نیست.", ERROR, "missing_component")


def _mb(n) -> str:
    return f"{(n or 0) / 1048576:.0f} MB"


def _own_chain() -> set[int]:
    pids = {os.getpid()}
    try:
        p = psutil.Process(os.getpid())
        for parent in p.parents():
            pids.add(parent.pid)
    except Exception:                                       # noqa: BLE001
        pass
    return pids


def _current_user() -> str:
    try:
        return psutil.Process(os.getpid()).username()
    except Exception:                                       # noqa: BLE001
        return ""


class ProcessTools:
    def __init__(self, access=None):
        self.access = access

    # ------------------------------------------------------------ helpers
    def _get(self, pid: int):
        try:
            return psutil.Process(int(pid))
        except psutil.NoSuchProcess as exc:
            raise ToolError(f"پردازه‌ای با شناسه‌ی {pid} در حال اجرا نیست.", ERROR, "device_unavailable") from exc
        except psutil.AccessDenied as exc:
            raise ToolError(f"ویندوز اجازه‌ی خواندن پردازه‌ی {pid} را نداد (پردازه‌ی سیستمی یا کاربر دیگر).", DENIED, "permission_denied") from exc

    def _guard(self, a: dict):
        """-> the psutil.Process that Kira may close / end, or ToolError. Used before asking the user and again before acting."""
        _need_psutil()
        pid = int(a["pid"])
        proc = self._get(pid)
        try:
            name = proc.name()
        except psutil.Error as exc:
            raise ToolError("نام پردازه خوانده نشد؛ دست نمی‌زنم.", DENIED, "permission_denied") from exc
        if pid <= 4 or _stem(name) in CRITICAL:
            raise ToolError(f"«{name}» پردازه‌ی حیاتی ویندوز است و Kira آن را نمی‌بندد.", DENIED, "permission_denied")
        if pid in _own_chain():
            raise ToolError("این پردازه خود Kira (یا برنامه‌ی میزبان آن) است و بسته نمی‌شود.", DENIED, "permission_denied")
        want = _stem(a.get("name"))
        if want != _stem(name):
            raise ToolError(f"نام پردازه با شناسه‌ی {pid} الان «{name}» است نه «{a.get('name')}» (شناسه عوض شده یا اشتباه است). چیزی بسته نشد.", ERROR, "device_unavailable")
        try:
            owner = proc.username()
        except psutil.Error:
            owner = ""
        if not owner or owner != _current_user():
            raise ToolError(f"«{name}» متعلق به کاربر/سرویس دیگری است و با دسترسی عادی بسته نمی‌شود. (دور زدن این محدودیت و درخواست Administrator انجام نمی‌شود.)",
                            DENIED, "permission_denied")
        return proc

    def _verify_gone(self, proc, timeout: float) -> bool:
        try:
            proc.wait(timeout=timeout)
            return True
        except psutil.TimeoutExpired:
            return False
        except psutil.NoSuchProcess:
            return True

    # ------------------------------------------------------------ READ
    def process_list(self, a: dict) -> str:
        _need_psutil()
        sort = a.get("sort", "memory")
        limit = max(1, min(int(a.get("limit", 15)), MAX_LIST))
        query = _stem(a.get("name", "")) if a.get("name") else ""
        procs = []
        for p in psutil.process_iter(["pid", "name"]):
            try:
                if query and query not in _stem(p.info["name"] or ""):
                    continue
                p.cpu_percent(None)
                procs.append(p)
            except psutil.Error:
                continue
        time.sleep(0.4)                                                  # CPU % needs two samples
        rows = []
        for p in procs:
            try:
                rows.append((p.info["pid"], p.info["name"] or "؟", p.cpu_percent(None), p.memory_info().rss))
            except psutil.Error:
                continue
        if not rows:
            return "پردازه‌ای با این مشخصات پیدا نشد." if query else "فهرست پردازه‌ها خوانده نشد."
        key = {"memory": lambda r: r[3], "cpu": lambda r: r[2], "name": lambda r: r[1].lower()}[sort]
        rows.sort(key=key, reverse=sort != "name")
        ncpu = psutil.cpu_count() or 1
        lines = [f"پردازه‌ها ({len(rows)} مورد، مرتب‌شده بر اساس {sort}؛ CPU نسبت به کل پردازنده):"]
        for pid, name, cpu, rss in rows[:limit]:
            lines.append(f"- {name} (pid {pid}) — CPU {cpu / ncpu:.1f}% · RAM {_mb(rss)}" + (" · حیاتی (بسته نمی‌شود)" if _stem(name) in CRITICAL else ""))
        return "\n".join(lines)

    def process_info(self, a: dict) -> str:
        _need_psutil()
        proc = self._get(a["pid"])
        try:
            with proc.oneshot():
                name, status = proc.name(), proc.status()
                started = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(proc.create_time()))
                rss, threads = proc.memory_info().rss, proc.num_threads()
                try:
                    exe = proc.exe()
                except psutil.Error:
                    exe = "(برای کاربر عادی قابل خواندن نیست)"
                try:
                    parent = proc.parent().name() if proc.parent() else "—"
                except psutil.Error:
                    parent = "؟"
                try:
                    mine = proc.username() == _current_user()
                except psutil.Error:
                    mine = False
        except psutil.NoSuchProcess as exc:
            raise ToolError(f"پردازه‌ی {a['pid']} همین حالا تمام شد.", ERROR, "device_unavailable") from exc
        except psutil.AccessDenied as exc:
            raise ToolError("ویندوز اجازه‌ی خواندن جزئیات این پردازه را نداد.", DENIED, "permission_denied") from exc
        can = "بله" if mine and _stem(name) not in CRITICAL and proc.pid not in _own_chain() else "خیر"
        return (f"پردازه {name} (pid {proc.pid}): وضعیت {status} · شروع {started} · RAM {_mb(rss)} · نخ‌ها {threads} · والد {parent} · مسیر {exe} · "
                f"مال همین کاربر: {'بله' if mine else 'خیر'} · Kira می‌تواند ببندد: {can}")

    # ------------------------------------------------------------ PROTECTED: close / end
    def precheck(self, a: dict) -> dict:
        proc = self._guard(a)
        return {"pid": int(a["pid"]), "name": proc.name()}

    def confirm_close(self, a: dict) -> str:
        return (f"بستن مؤدبانه‌ی «{a['name']}» (pid {a['pid']}) مثل دکمه‌ی ×. اگر کار ذخیره‌نشده داشته باشد خودش می‌پرسد؛ "
                f"ممکن است برنامه نبندد. خلاصه‌ی اثر: پنجره‌های این برنامه بسته می‌شوند. برگشت‌پذیر نیست مگر دوباره بازش کنی.")

    def confirm_kill(self, a: dict) -> str:
        return (f"اجبار به پایان «{a['name']}» (pid {a['pid']}) با TerminateProcess. هر کار ذخیره‌نشده‌ی این برنامه از دست می‌رود. "
                f"فقط برای برنامه‌ی قفل‌شده/پاسخ‌نده مناسب است. خلاصه‌ی اثر: پردازه فوراً تمام می‌شود و برگشت‌پذیر نیست.")

    def process_close(self, a: dict) -> str:
        proc = self._guard(a)
        name, pid = proc.name(), proc.pid
        sent = self._post_close(pid)
        if not sent:
            raise ToolError(f"«{name}» پنجره‌ی قابل‌بستن ندارد (احتمالاً پس‌زمینه است). چیزی بسته نشد؛ اگر واقعاً باید پایان یابد، process_kill را با تأیید جداگانه بزن.", ERROR, "api_failure")
        if self._verify_gone(proc, 6.0):
            return f"«{name}» (pid {pid}) بسته شد و پایان آن دوباره تأیید شد (VERIFIED)."
        if self.access:
            self.access.set_verification("unverified")
        return (f"درخواست بستن برای «{name}» (pid {pid}) فرستاده شد ولی بعد از ۶ ثانیه هنوز در حال اجراست (UNVERIFIED). "
                f"احتمالاً می‌پرسد کار ذخیره شود؛ نبسته شده را «بسته شد» حساب نکن.")

    def process_kill(self, a: dict) -> str:
        proc = self._guard(a)
        name, pid = proc.name(), proc.pid
        try:
            proc.kill()
        except psutil.NoSuchProcess:
            pass
        except psutil.AccessDenied as exc:
            raise ToolError(f"ویندوز اجازه‌ی پایان دادن «{name}» را به کاربر عادی نداد. با Administrator تلاش نشد و نمی‌شود: Kira پردازه‌ی محافظت‌شده را دور نمی‌زند.",
                            DENIED, "permission_denied") from exc
        if self._verify_gone(proc, 5.0):
            return f"«{name}» (pid {pid}) به‌زور پایان یافت و پایانش دوباره تأیید شد (VERIFIED)."
        if self.access:
            self.access.set_verification("unverified")
        return f"دستور پایان برای «{name}» (pid {pid}) پذیرفته شد ولی هنوز در فهرست پردازه‌هاست (UNVERIFIED)."

    @staticmethod
    def _post_close(pid: int) -> int:
        """Send WM_CLOSE to every visible top-level window of the process. -> number of windows asked to close."""
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        WM_CLOSE = 0x0010
        count = [0]
        enum_proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _):
            owner = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid and user32.IsWindowVisible(hwnd) and not user32.GetWindow(hwnd, 4):     # GW_OWNER = 4: top-level only
                user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                count[0] += 1
            return True

        user32.EnumWindows(enum_proto(cb), 0)
        return count[0]


class ProcessModule(WinModule):
    domain = "processes"

    def __init__(self, access=None):
        self.t = ProcessTools(access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("apps", "system")
        pid = Param("pid", "integer", "process id from process_list", True)
        name = Param("name", "string", "process name exactly as process_list shows it (checked again before acting)", True)
        return [
            Capability("process_list", "processes", "list running processes with CPU % and RAM (sort = memory | cpu | name; optional name filter). Changes nothing",
                       t.process_list, READ, (Param("sort", "string", "memory | cpu | name", False, "memory", ("memory", "cpu", "name")), Param("limit", "integer", "default 15, max 30", False, 15),
                                              Param("name", "string", "optional part of the process name")), cat),
            Capability("process_info", "processes", "details of ONE process (state, start time, RAM, parent, path, whether Kira may close it). Changes nothing", t.process_info, READ, (pid,), cat),
            Capability("process_close", "processes", "close an app politely (like the X button) by pid + name. The user confirms first; the app may ask to save and stay open",
                       t.process_close, SENSITIVE, (pid, name), cat, confirm_summary=t.confirm_close, precheck=t.precheck,
                       memo=lambda a, x: f"process_close → {a.get('name')}", verifies_result=True, changes_system=True),
            Capability("process_kill", "processes", "force-end a frozen app by pid + name (unsaved work is lost). The user confirms first. Never for critical Windows processes or other users' processes",
                       t.process_kill, SENSITIVE, (pid, name), cat, permission=PROTECTED, intent_rx=KILL_RX, confirm_summary=t.confirm_kill, precheck=t.precheck,
                       memo=lambda a, x: f"process_kill → {a.get('name')}", verifies_result=True, changes_system=True),
        ]
