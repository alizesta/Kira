"""Installed software (T6 Phase 1): inventory, per-user uninstall, per-user install - inside the normal user's rights.

What is supported and what is deliberately not:
  * app_list_installed  READ. Reads the Windows Uninstall registry keys (HKCU, HKLM, WOW6432Node). Changes nothing.
  * app_uninstall       PROTECTED (confirmed per app). ONLY entries installed for the CURRENT USER (HKCU). The app's own uninstaller is started
                        exactly as registered (its own window, not silent) after strict checks (a real .exe inside the user's profile, no shell).
                        Machine-wide programs (HKLM) are refused with kind=admin_required: running a vendor's command line as Administrator would be an
                        arbitrary-command path, which Kira never offers. The answer tells the user to uninstall it from Windows Settings.
                        If a per-user uninstaller itself demands elevation (Windows error 740) nothing is retried and admin_required is reported.
  * app_search_online / app_install  winget (Microsoft's package manager), `--scope user`, exact package id, NO shell. Never retried machine-wide.
                        Installing accepts the package license on the user's behalf, which the confirmation text says.
  * Result: VERIFIED only when the registry / winget shows the new state; otherwise the text says UNVERIFIED.
Nothing here is tested on a real Windows PC (static checks only).
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import time

from .registry import ToolError, Param, READ, SENSITIVE, DENIED, ERROR
from .sysaccess import PROTECTED

UNINSTALL_RX = re.compile(r"uninstall|remove|delete|آنینستال|حذف|پاک|از\s*بین\s*ببر|پاکش", re.I)
from .winrunner import IS_WIN
from .wincontrol import Capability, WinModule
from .elevation import needs_admin_error

NO_WINDOW = 0x08000000 if IS_WIN else 0
_UNINSTALL = r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
_PKG_RX = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+\-]{1,100}$")
_QUERY_RX = re.compile(r"^[\w .+\-#]{1,60}$")
WAIT_UNINSTALL = 25            # seconds Kira watches the registry after starting an uninstaller (it has its own window)
INSTALL_TIMEOUT = 420


def _norm(text) -> str:
    return re.sub(r"\s+", " ", str(text or "").lower().replace("ي", "ی").replace("ك", "ک").replace("‌", " ")).strip()


def read_installed() -> list[dict]:
    """[{name, version, publisher, scope: user|machine, location, uninstall, key}] from the registry (read only)."""
    if not IS_WIN:
        raise ToolError("فهرست نرم‌افزارهای نصب‌شده فقط روی ویندوز ممکن است.", ERROR, "missing_component")
    import winreg
    out, seen = [], set()
    views = ((winreg.HKEY_CURRENT_USER, 0, "user"), (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY, "machine"), (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY, "machine"))
    for hive, view, scope in views:
        try:
            root = winreg.OpenKey(hive, _UNINSTALL, 0, winreg.KEY_READ | view)
        except OSError:
            continue
        with root:
            i = 0
            while True:
                try:
                    sub = winreg.EnumKey(root, i)
                except OSError:
                    break
                i += 1
                try:
                    with winreg.OpenKey(root, sub) as k:
                        def val(n):
                            try:
                                return winreg.QueryValueEx(k, n)[0]
                            except OSError:
                                return None
                        name = val("DisplayName")
                        if not name or val("SystemComponent") == 1 or val("ParentKeyName"):
                            continue
                        ident = (scope, str(name), str(val("DisplayVersion")))
                        if ident in seen:
                            continue
                        seen.add(ident)
                        out.append({"name": str(name), "version": str(val("DisplayVersion") or ""), "publisher": str(val("Publisher") or ""), "scope": scope,
                                    "location": str(val("InstallLocation") or ""), "uninstall": str(val("UninstallString") or ""), "key": sub})
                except OSError:
                    continue
    return out


def _user_roots() -> list[str]:
    roots = [os.environ.get("LOCALAPPDATA"), os.environ.get("APPDATA"), os.environ.get("USERPROFILE")]
    return [os.path.normcase(os.path.realpath(r)) for r in roots if r]


def parse_uninstall_command(text: str) -> list[str]:
    """'"C:\\x\\unins000.exe" /SILENT' -> ['C:\\x\\unins000.exe', '/SILENT']. Only an existing .exe inside the user's profile is accepted."""
    t = str(text or "").strip()
    if not t:
        raise ToolError("این برنامه رشته‌ی حذف (UninstallString) ثبت نکرده است؛ از تنظیمات ویندوز حذفش کن.", ERROR, "missing_component")
    if t.startswith('"'):
        end = t.find('"', 1)
        if end < 0:
            raise ToolError("رشته‌ی حذف این برنامه قابل‌خواندن نیست.", ERROR, "api_failure")
        exe, rest = t[1:end], t[end + 1:].strip()
    else:
        m = re.match(r"^(.+?\.exe)(?:\s+(.*))?$", t, re.I)
        if not m:
            raise ToolError("رشته‌ی حذف این برنامه یک فایل exe روشن نیست؛ از تنظیمات ویندوز حذفش کن.", DENIED, "api_failure")
        exe, rest = m.group(1), (m.group(2) or "")
    exe = os.path.expandvars(exe)
    real = os.path.normcase(os.path.realpath(exe))
    if not real.endswith(".exe") or not os.path.isfile(real):
        raise ToolError("نصب‌کننده‌ی حذف این برنامه exe موجود نیست؛ از تنظیمات ویندوز حذفش کن.", ERROR, "missing_component")
    if not any(real == r or real.startswith(r + os.sep) for r in _user_roots()):
        raise ToolError("حذف‌کننده‌ی این برنامه بیرون از پوشه‌ی کاربر است؛ Kira فقط برنامه‌های نصب‌شده برای همین کاربر را حذف می‌کند. از تنظیمات ویندوز حذفش کن.", DENIED, "admin_required")
    args = [a.strip('"') for a in re.findall(r'"[^"]*"|\S+', rest)]
    return [exe] + args


class AppManageTools:
    def __init__(self, access=None):
        self.access = access

    # ------------------------------------------------------------ READ
    def list_installed(self, a: dict) -> str:
        items = read_installed()
        q = _norm(a.get("query", ""))
        if q:
            items = [i for i in items if q in _norm(i["name"]) or q in _norm(i["publisher"])]
        if not items:
            return "نرم‌افزاری با این مشخصات در فهرست نصب‌شده‌های ویندوز پیدا نشد (برنامه‌های Store و Portable ممکن است در این فهرست نباشند)."
        items.sort(key=lambda i: i["name"].lower())
        limit = max(1, min(int(a.get("limit", 30)), 60))
        lines = [f"نرم‌افزارهای نصب‌شده ({len(items)} مورد" + (f"، نمایش {limit}" if len(items) > limit else "") + "):"]
        for i in items[:limit]:
            where = "برای همین کاربر (Kira می‌تواند حذف کند)" if i["scope"] == "user" else "برای کل سیستم (حذف از Windows Settings)"
            lines.append(f"- {i['name']}" + (f" {i['version']}" if i["version"] else "") + (f" — {i['publisher']}" if i["publisher"] else "") + f" · {where}")
        return "\n".join(lines)

    def search_online(self, a: dict) -> str:
        q = str(a.get("query", "")).strip()
        if not _QUERY_RX.match(q):
            raise ToolError("عبارت جست‌وجو معتبر نیست (حروف، عدد، فاصله و . + - #).", "bad_args")
        out = _winget(["search", q, "--source", "winget", "--accept-source-agreements", "--disable-interactivity"], 40)
        return "نتیجه‌ی جست‌وجوی winget (id را برای نصب استفاده کن):\n" + out[:2500]

    # ------------------------------------------------------------ uninstall
    def _resolve(self, name: str) -> dict:
        wanted = _norm(name)
        exact = [i for i in read_installed() if _norm(i["name"]) == wanted]
        if not exact:
            part = [i for i in read_installed() if wanted in _norm(i["name"])]
            if not part:
                raise ToolError(f"«{name}» در فهرست نصب‌شده‌ها نیست.", ERROR, "app_not_installed")
            names = "؛ ".join(sorted({i["name"] for i in part})[:6])
            raise ToolError(f"نام دقیق مشخص نیست. نام کامل را از این‌ها انتخاب کن: {names}", "bad_args")
        if len({(i["scope"], i["key"]) for i in exact}) > 1:
            raise ToolError(f"چند ورودی هم‌نام «{name}» هست؛ برای جلوگیری از اشتباه حذف نمی‌کنم. از تنظیمات ویندوز حذفش کن.", "bad_args")
        return exact[0]

    def precheck_uninstall(self, a: dict) -> dict:
        item = self._resolve(a["name"])
        if item["scope"] != "user":
            raise needs_admin_error(f"«{item['name']}» برای کل سیستم نصب شده و حذفش با دسترسی عادی ممکن نیست؛ Kira فرمان حذف دلخواه را با Administrator اجرا نمی‌کند. از Windows Settings ← Apps حذفش کن.")
        parse_uninstall_command(item["uninstall"])                     # a broken / unsafe uninstaller is reported now, not after the question
        return {"name": item["name"]}

    def confirm_uninstall(self, a: dict) -> str:
        return (f"حذف نرم‌افزار «{a['name']}» (نصب‌شده برای همین کاربر). حذف‌کننده‌ی خود برنامه با پنجره‌ی خودش اجرا می‌شود و ممکن است از تو سؤال بپرسد. "
                f"خلاصه‌ی اثر: برنامه و تنظیمات احتمالاً پاک می‌شوند؛ برگشت‌پذیر نیست مگر دوباره نصب کنی. Administrator لازم نیست.")

    def uninstall(self, a: dict) -> str:
        item = self._resolve(a["name"])
        if item["scope"] != "user":
            raise needs_admin_error(f"«{item['name']}» برای کل سیستم نصب شده است.")
        cmd = parse_uninstall_command(item["uninstall"])
        try:
            subprocess.Popen(cmd, shell=False)
        except OSError as exc:
            if getattr(exc, "winerror", 0) == 740:
                raise needs_admin_error(f"حذف‌کننده‌ی «{item['name']}» خودش Administrator می‌خواهد.") from exc
            raise ToolError(f"حذف‌کننده‌ی «{item['name']}» شروع نشد: {exc}", ERROR, "api_failure") from exc
        deadline = time.time() + WAIT_UNINSTALL
        while time.time() < deadline:
            time.sleep(1.5)
            if not any(i["scope"] == "user" and i["key"] == item["key"] for i in read_installed()):
                return f"«{item['name']}» از فهرست نصب‌شده‌ها حذف شد (VERIFIED)."
        if self.access:
            self.access.set_verification("unverified")
        return (f"حذف‌کننده‌ی «{item['name']}» اجرا شد ولی تا {WAIT_UNINSTALL} ثانیه هنوز در فهرست نصب‌شده‌هاست (UNVERIFIED). "
                f"احتمالاً پنجره‌ی حذف‌کننده منتظر خود کاربر است؛ بعد از پایانش دوباره فهرست را بخوان.")

    # ------------------------------------------------------------ install (winget, per user)
    def precheck_install(self, a: dict) -> dict:
        pid = str(a.get("package_id", "")).strip()
        if not _PKG_RX.match(pid):
            raise ToolError("شناسه‌ی بسته معتبر نیست (مثل Microsoft.VisualStudioCode؛ اول app_search_online را بزن).", "bad_args")
        if not _winget_path():
            raise ToolError("winget روی این سیستم پیدا نشد (App Installer نصب/فعال نیست).", ERROR, "missing_component")
        return {"package_id": pid}

    def confirm_install(self, a: dict) -> str:
        return (f"نصب بسته‌ی winget «{a['package_id']}» فقط برای همین کاربر (--scope user، بدون Administrator). با تأیید تو، توافق‌نامه‌ی مجوز بسته و منبع winget هم "
                f"به نام تو پذیرفته می‌شود. اگر بسته نصب بدون Administrator نداشته باشد، نصب نمی‌شود و خودکار با Administrator تلاش نمی‌کنم. خلاصه‌ی اثر: یک برنامه دانلود و نصب می‌شود.")

    def install(self, a: dict) -> str:
        pid = self.precheck_install(a)["package_id"]
        if self._is_installed(pid):
            return f"بسته‌ی «{pid}» همین حالا نصب است (VERIFIED)؛ چیزی تغییر نکرد."
        code, text = _winget_run(["install", "--id", pid, "--exact", "--scope", "user", "--silent", "--disable-interactivity",
                                  "--accept-package-agreements", "--accept-source-agreements"], INSTALL_TIMEOUT)
        low = text.lower()
        if self._is_installed(pid):
            return f"بسته‌ی «{pid}» نصب شد و در فهرست winget هم دیده می‌شود (VERIFIED)."
        if "administrator" in low or "elevat" in low:
            raise needs_admin_error(f"نصب «{pid}» بدون Administrator ممکن نیست.")
        if "no applicable installer" in low or "no package found" in low:
            raise ToolError(f"برای «{pid}» نصب‌کننده‌ی مناسب (برای کاربر عادی/این سیستم) پیدا نشد. winget: {text[-200:]}", ERROR, "missing_component")
        if self.access:
            self.access.set_verification("unverified")
        raise ToolError(f"نصب «{pid}» تأیید نشد (کد winget {code}): {text[-250:]}", ERROR, "api_failure")

    @staticmethod
    def _is_installed(pid: str) -> bool:
        code, text = _winget_run(["list", "--id", pid, "--exact", "--accept-source-agreements", "--disable-interactivity"], 40)
        return code == 0 and pid.lower() in text.lower()


def _winget_path() -> str:
    return shutil.which("winget") or ""


def _winget_run(args: list, timeout: int) -> tuple[int, str]:
    exe = _winget_path()
    if not IS_WIN:
        raise ToolError("winget فقط روی ویندوز ممکن است.", ERROR, "missing_component")
    if not exe:
        raise ToolError("winget روی این سیستم پیدا نشد (App Installer نصب/فعال نیست).", ERROR, "missing_component")
    try:
        r = subprocess.run([exe] + args, capture_output=True, timeout=timeout, creationflags=NO_WINDOW, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise ToolError(f"winget بیش از {timeout} ثانیه طول کشید؛ وضعیت نصب نامعلوم است (UNKNOWN).", ERROR, "timeout") from exc
    except OSError as exc:
        raise ToolError(f"اجرای winget ممکن نشد: {exc}", ERROR, "api_failure") from exc
    return r.returncode, (r.stdout.decode("utf-8", "ignore") + "\n" + r.stderr.decode("utf-8", "ignore")).strip()


def _winget(args: list, timeout: int) -> str:
    code, text = _winget_run(args, timeout)
    if code != 0 and not text:
        raise ToolError(f"winget با کد {code} تمام شد.", ERROR, "api_failure")
    return text


class AppManageModule(WinModule):
    domain = "apps"

    def __init__(self, access=None):
        self.t = AppManageTools(access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("apps",)
        caps = [
            Capability("app_list_installed", "apps", "list installed software from the Windows registry (optional query on name / publisher); says which ones Kira may uninstall. Changes nothing",
                       t.list_installed, READ, (Param("query", "string", "part of the app or publisher name"), Param("limit", "integer", "default 30, max 60", False, 30)), cat),
            Capability("app_search_online", "apps", "search the winget catalogue for a package id to install (needs internet; names only). Changes nothing",
                       t.search_online, READ, (Param("query", "string", "app name to look for", True),), cat, external=True),
            Capability("app_uninstall", "apps", "uninstall ONE program installed for the current user (its own uninstaller window opens). Machine-wide programs are refused. The user confirms first",
                       t.uninstall, SENSITIVE, (Param("name", "string", "exact name from app_list_installed", True),), cat, permission=PROTECTED, intent_rx=UNINSTALL_RX,
                       confirm_summary=t.confirm_uninstall, precheck=t.precheck_uninstall, memo=lambda a, x: f"app_uninstall → {a.get('name')}", verifies_result=True, changes_system=True),
            Capability("app_install", "apps", "install ONE winget package for the current user only (no Administrator). package_id from app_search_online. The user confirms first",
                       t.install, SENSITIVE, (Param("package_id", "string", "winget package id, e.g. Microsoft.VisualStudioCode", True),), cat,
                       confirm_summary=t.confirm_install, precheck=t.precheck_install, memo=lambda a, x: f"app_install → {a.get('package_id')}", verifies_result=True, changes_system=True),
        ]
        caps[0].backend = "registry"
        caps[1].backend = caps[3].backend = "winget"
        caps[2].backend = "registry"
        return caps
