"""T6 Phase 4 - Power & session: lock, sleep, hibernate, restart, shutdown, log off, cancel a pending restart / shutdown.

Pure Win32 through ctypes (user32 / advapi32 / powrprof). No PowerShell, no shutdown.exe, no shell, no UAC: an ordinary interactive Windows user already HOLDS the
shutdown right (SeShutdownPrivilege, disabled by default); Kira only ENABLES that existing privilege for its own process, exactly like the Start menu does. If the
account does not hold it (company policy) Windows says so and Kira reports permission_denied - it never tries to get around it or to elevate.

Safety model (enforced by the central ToolRegistry / SystemAccessManager, not by this file):
  * restart / shutdown / log off  -> PROTECTED: the user's CURRENT message must ask for it (intent_rx) AND the user must confirm the exact operation;
                                     never on the model's own initiative, never in a turn that read external content.
  * sleep / hibernate             -> PROTECTED as well (they suspend all running work, and a mis-heard "sleep" must never happen on the model's own initiative).
  * lock / cancel / status        -> lock and cancel need an explicit request (intent_rx), no confirmation (harmless, reversible); status is READ.
Nothing here forces applications to close (no EWX_FORCE / bForceAppsClosed): an app with unsaved work may stop the restart / shutdown / log off and Windows shows
its own dialog. Restart and shutdown always run with a countdown (default 30 s, min 10 s) so they can be cancelled with power_cancel.

Honest verification: a restart / shutdown / sleep / log off ends Kira itself, so the final state can NEVER be re-read. These return "UNVERIFIED: the request was
accepted by Windows" and the journal records verification=unverified. Lock is checked with a heuristic (the input desktop becomes inaccessible); cancel reports the
real Windows answer ("nothing was pending" is not an error). Nothing was tested on a real Windows PC (static checks only).
"""
from __future__ import annotations

import re
import sys
import threading
import time

from .registry import ToolError, Param, READ, ACTION, SENSITIVE, DENIED, ERROR
from .sysaccess import PROTECTED
from .wincontrol import Capability, WinModule

IS_WIN = sys.platform == "win32"
MIN_DELAY, MAX_DELAY, DEFAULT_DELAY = 10, 600, 30
DEFER_SECONDS = 3.0                   # sleep / hibernate / log off start this long AFTER the answer, so Kira can still say what is happening (and cancel can stop it)
REASON_PLANNED = 0x80000000           # SHTDN_REASON_FLAG_PLANNED
ERR_SHUTDOWN_IN_PROGRESS, ERR_NO_SHUTDOWN_IN_PROGRESS, ERR_NOT_ALL_ASSIGNED, ERR_ACCESS_DENIED = 1115, 1116, 1300, 5

_RX = lambda *w: re.compile("|".join(w), re.I)
SHUTDOWN_RX = _RX(r"خاموش", r"شات\s*داون", r"shut\s*-?\s*down", r"power\s*off", r"turn\s*off\s+(?:the\s+|my\s+)?(?:pc|computer|laptop|system)")
RESTART_RX = _RX(r"ری\s*استارت", r"ریستارت", r"راه\s*اندازی\s*مجدد", r"دوباره\s*روشن", r"\brestart", r"\breboot")
LOGOFF_RX = _RX(r"خروج\s*از\s*(?:حساب|اکانت|ویندوز|کاربر|سیستم)", r"سا?ین\s*اوت", r"سایین\s*اوت", r"لاگ\s*اوت", r"لاگ\s*آف", r"log\s*-?\s*off", r"log\s*-?\s*out", r"sign\s*-?\s*out")
SLEEP_RX = _RX(r"بخواب", r"خواب", r"\bsleep\b", r"stand\s*-?\s*by", r"استندبای")
HIBERNATE_RX = _RX(r"هایبرنیت", r"هیبرنیت", r"خواب\s*زمستانی", r"hibernat")
LOCK_RX = _RX(r"قفل", r"\block\b", r"win\s*\+\s*l\b")
CANCEL_RX = _RX(r"لغو", r"کنسل", r"cancel", r"abort", r"منصرف", r"نکن", r"\bstop\b", r"صبر\s*کن")


def _need_win(what: str):
    if not IS_WIN:
        raise ToolError(f"{what} فقط روی ویندوز ممکن است.", ERROR, "missing_component")


def _last_error() -> int:
    import ctypes
    return ctypes.get_last_error()


def _enable_shutdown_privilege() -> None:
    """Enable the SeShutdownPrivilege the user ALREADY holds (Windows lists it in the token but disabled). Not an elevation; refused -> permission_denied."""
    _need_win("مدیریت Power")
    import ctypes
    from ctypes import wintypes

    class LUID(ctypes.Structure):
        _fields_ = [("LowPart", wintypes.DWORD), ("HighPart", wintypes.LONG)]

    class LUID_AND_ATTRIBUTES(ctypes.Structure):
        _fields_ = [("Luid", LUID), ("Attributes", wintypes.DWORD)]

    class TOKEN_PRIVILEGES(ctypes.Structure):
        _fields_ = [("PrivilegeCount", wintypes.DWORD), ("Privileges", LUID_AND_ATTRIBUTES * 1)]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.LookupPrivilegeValueW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.POINTER(LUID)]
    advapi32.LookupPrivilegeValueW.restype = wintypes.BOOL
    advapi32.AdjustTokenPrivileges.argtypes = [wintypes.HANDLE, wintypes.BOOL, ctypes.POINTER(TOKEN_PRIVILEGES), wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p]
    advapi32.AdjustTokenPrivileges.restype = wintypes.BOOL

    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(), 0x0020 | 0x0008, ctypes.byref(token)):        # TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY
        raise ToolError(f"ویندوز توکن این برنامه را باز نکرد (کد {_last_error()}).", ERROR, "api_failure")
    try:
        tp = TOKEN_PRIVILEGES()
        tp.PrivilegeCount = 1
        if not advapi32.LookupPrivilegeValueW(None, "SeShutdownPrivilege", ctypes.byref(tp.Privileges[0].Luid)):
            raise ToolError(f"ویندوز حق خاموش‌کردن را پیدا نکرد (کد {_last_error()}).", ERROR, "api_failure")
        tp.Privileges[0].Attributes = 0x00000002                                                                    # SE_PRIVILEGE_ENABLED
        ok = advapi32.AdjustTokenPrivileges(token, False, ctypes.byref(tp), 0, None, None)
        err = _last_error()
        if not ok or err == ERR_NOT_ALL_ASSIGNED:
            raise ToolError("این حساب کاربری حق خاموش/ریستارت/Sleep کردن سیستم را ندارد (سیاست سیستم یا سازمان). Kira آن را دور نمی‌زند و Administrator هم درخواست نمی‌کند.",
                            DENIED, "permission_denied")
    finally:
        kernel32.CloseHandle(token)


def hibernate_state() -> str:
    """'yes' | 'no' | 'unknown' - is hibernation really available (S4 supported AND the hibernation file exists)? Without this check SetSuspendState(TRUE) silently SLEEPS."""
    if not IS_WIN:
        return "unknown"
    import ctypes
    try:
        powrprof = ctypes.WinDLL("powrprof")
        powrprof.CallNtPowerInformation.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong]
        powrprof.CallNtPowerInformation.restype = ctypes.c_long
        buf = (ctypes.c_ubyte * 76)()                                    # SYSTEM_POWER_CAPABILITIES; byte 6 = SystemS4, byte 8 = HiberFilePresent
        if powrprof.CallNtPowerInformation(4, None, 0, buf, 76) != 0:    # 4 = SystemPowerCapabilities
            return "unknown"
        return "yes" if buf[6] and buf[8] else "no"
    except Exception:                                                    # noqa: BLE001
        return "unknown"


def _input_desktop_blocked() -> bool:
    """Heuristic for 'the workstation is locked': OpenInputDesktop fails while the lock screen (secure desktop) is active."""
    import ctypes
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.OpenInputDesktop.restype = ctypes.c_void_p
    user32.OpenInputDesktop.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    user32.CloseDesktop.argtypes = [ctypes.c_void_p]
    h = user32.OpenInputDesktop(0, False, 0x0100)                        # DESKTOP_SWITCHDESKTOP
    if h:
        user32.CloseDesktop(h)
        return False
    return True


class PowerTools:
    def __init__(self, access=None):
        self.access = access
        self._lock = threading.Lock()
        self._pending = None            # {"kind": "restart"|"shutdown", "at": epoch deadline} scheduled BY KIRA in this run
        self._timer = None              # {"kind": ..., "timer": threading.Timer} for a deferred sleep / hibernate / log off
        self._last_error = ""           # a deferred action that failed after the answer was already given

    def _unverified(self):
        if self.access:
            self.access.set_verification("unverified")

    # ------------------------------------------------------------ READ
    def power_status(self, a: dict) -> str:
        _need_win("خواندن وضعیت Power")
        hib = {"yes": "فعال و در دسترس", "no": "غیرفعال (فایل hibernation یا S4 نیست)", "unknown": "نامشخص (UNKNOWN)"}[hibernate_state()]
        lines = [f"Hibernate: {hib}. Sleep: Kira نمی‌تواند حالت‌های Modern Standby / S3 را قبل از اجرا بخواند؛ خود ویندوز تصمیم می‌گیرد.",
                 f"قفل بودن فعلی صفحه (تقریبی): {'بله' if _input_desktop_blocked() else 'خیر'}."]
        with self._lock:
            pend, tm, err = self._pending, self._timer, self._last_error
        if pend:
            left = int(pend["at"] - time.time())
            lines.append(f"عملیات زمان‌بندی‌شده توسط Kira در این اجرا: {pend['kind']} " + (f"(حدود {left} ثانیه‌ی دیگر)" if left > 0 else "(زمانش گذشته؛ اگر سیستم هنوز روشن است، لغو شده یا Windows آن را متوقف کرده)")
                         + ". Kira نمی‌تواند عملیاتی را که برنامه‌ی دیگری زمان‌بندی کرده بخواند؛ power_cancel هر خاموشی/ریستارت زمان‌بندی‌شده‌ی ویندوز را لغو می‌کند.")
        if tm:
            lines.append(f"عملیات در آستانه‌ی اجرا: {tm['kind']} (چند ثانیه‌ی دیگر؛ با power_cancel قابل‌لغو است).")
        if err:
            lines.append(f"آخرین عملیات تأخیری شکست خورد: {err}")
        return "\n".join(lines)

    # ------------------------------------------------------------ lock
    def lock(self, a: dict) -> str:
        _need_win("قفل کردن ویندوز")
        import ctypes
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.LockWorkStation.restype = ctypes.c_int
        if not user32.LockWorkStation():
            err = _last_error()
            raise ToolError(f"ویندوز قفل‌کردن را نپذیرفت (کد {err}); ممکن است سیاست سیستم آن را بسته باشد.", DENIED if err == ERR_ACCESS_DENIED else ERROR,
                            "permission_denied" if err == ERR_ACCESS_DENIED else "api_failure")
        for _ in range(6):
            time.sleep(0.4)
            if _input_desktop_blocked():
                return "ویندوز قفل شد (تشخیص تقریبی: دسکتاپ ورودی دیگر در دسترس نیست؛ VERIFIED-heuristic)."
        self._unverified()
        return "درخواست قفل پذیرفته شد ولی قفل‌شدن را نتوانستم تأیید کنم (UNVERIFIED)."

    # ------------------------------------------------------------ restart / shutdown (countdown, cancellable)
    def precheck_timed(self, a: dict) -> dict:
        try:
            d = int(a.get("delay_seconds", DEFAULT_DELAY))
        except (TypeError, ValueError):
            raise ToolError("delay_seconds باید عدد باشد.", "bad_args") from None
        if not MIN_DELAY <= d <= MAX_DELAY:
            raise ToolError(f"delay_seconds باید بین {MIN_DELAY} و {MAX_DELAY} ثانیه باشد (برای اینکه بشود لغو کرد).", "bad_args")
        return {**a, "delay_seconds": d}

    def confirm_restart(self, a: dict) -> str:
        return (f"راه‌اندازی مجدد ویندوز {a['delay_seconds']} ثانیه‌ی دیگر. خلاصه‌ی اثر: همه‌ی برنامه‌ها بسته می‌شوند، Kira هم قطع می‌شود و کار ذخیره‌نشده ممکن است از بین برود "
                f"(Kira اجبار به بستن نمی‌کند؛ برنامه‌های دارای کار ذخیره‌نشده ممکن است جلوی ریستارت را بگیرند). تا قبل از پایان شمارش می‌توان با «لغو کن» (power_cancel) متوقفش کرد.")

    def confirm_shutdown(self, a: dict) -> str:
        return (f"خاموش کردن کامل ویندوز {a['delay_seconds']} ثانیه‌ی دیگر. خلاصه‌ی اثر: همه‌ی برنامه‌ها بسته می‌شوند، Kira قطع می‌شود و تا روشن‌کردن دستی سیستم در دسترس نیست؛ "
                f"کار ذخیره‌نشده ممکن است از بین برود (اجبار به بستن نمی‌شود). تا قبل از پایان شمارش با «لغو کن» (power_cancel) قابل توقف است.")

    def _timed(self, kind: str, reboot: bool, delay: int) -> str:
        _enable_shutdown_privilege()
        import ctypes
        from ctypes import wintypes
        advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
        advapi32.InitiateSystemShutdownExW.argtypes = [wintypes.LPWSTR, wintypes.LPWSTR, wintypes.DWORD, wintypes.BOOL, wintypes.BOOL, wintypes.DWORD]
        advapi32.InitiateSystemShutdownExW.restype = wintypes.BOOL
        msg = "Kira: " + ("ریستارت" if reboot else "خاموش‌شدن") + " به درخواست کاربر. برای لغو به Kira بگو «لغو کن» یا در خط فرمان shutdown /a بزن."
        if not advapi32.InitiateSystemShutdownExW(None, msg, int(delay), False, bool(reboot), REASON_PLANNED):         # bForceAppsClosed = FALSE
            err = _last_error()
            if err == ERR_SHUTDOWN_IN_PROGRESS:
                raise ToolError("یک خاموشی/ریستارت از قبل زمان‌بندی شده است. چیزی عوض نشد؛ اگر می‌خواهی، اول با power_cancel لغوش کن.", ERROR, "api_failure")
            if err == ERR_ACCESS_DENIED:
                raise ToolError("ویندوز اجازه‌ی خاموش/ریستارت را به این حساب نداد. Administrator درخواست نشد و نمی‌شود.", DENIED, "permission_denied")
            raise ToolError(f"ویندوز {kind} را نپذیرفت (کد {err}). چیزی تغییر نکرد.", ERROR, "api_failure")
        with self._lock:
            self._pending = {"kind": kind, "at": time.time() + delay}
        self._unverified()
        return (f"{'ریستارت' if reboot else 'خاموش شدن'} زمان‌بندی شد: حدود {delay} ثانیه‌ی دیگر (UNVERIFIED: ویندوز درخواست را پذیرفت؛ چون Kira با خود سیستم تمام می‌شود، نتیجه‌ی نهایی "
                f"قابل‌خواندن نیست). برای متوقف کردن همین حالا بگو «لغو کن».")

    def restart(self, a: dict) -> str:
        return self._timed("restart", True, self.precheck_timed(a)["delay_seconds"])

    def shutdown(self, a: dict) -> str:
        return self._timed("shutdown", False, self.precheck_timed(a)["delay_seconds"])

    # ------------------------------------------------------------ deferred: sleep / hibernate / log off
    def _defer(self, kind: str, action) -> None:
        def run():
            try:
                action()
            except Exception as exc:                                    # noqa: BLE001 - nobody is waiting for this thread; keep the reason for power_status
                with self._lock:
                    self._last_error = f"{kind}: {exc}"
            finally:
                with self._lock:
                    self._timer = None
        with self._lock:
            if self._timer:
                raise ToolError(f"یک عملیات «{self._timer['kind']}» همین حالا در آستانه‌ی اجراست؛ چیزی عوض نشد (می‌توانی با power_cancel لغوش کنی).", ERROR, "api_failure")
            t = threading.Timer(DEFER_SECONDS, run)
            t.daemon = True
            self._timer = {"kind": kind, "timer": t}
            self._last_error = ""
        t.start()

    def confirm_sleep(self, a: dict) -> str:
        return ("بردن ویندوز به حالت Sleep چند ثانیه‌ی دیگر. خلاصه‌ی اثر: صفحه و کارهای در حال اجرا (دانلود، پخش، Kira) متوقف می‌شوند تا سیستم را دوباره بیدار کنی؛ "
                "کار ذخیره‌نشده می‌ماند ولی اگر برق قطع شود از بین می‌رود.")

    def sleep(self, a: dict) -> str:
        _enable_shutdown_privilege()

        def go():
            import ctypes
            powrprof = ctypes.WinDLL("powrprof")
            powrprof.SetSuspendState.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, ctypes.c_ubyte]
            powrprof.SetSuspendState.restype = ctypes.c_ubyte
            if not powrprof.SetSuspendState(0, 0, 0):                      # hibernate=FALSE, force=FALSE, disable wake events=FALSE
                raise RuntimeError("SetSuspendState شکست خورد")
        self._defer("sleep", go)
        self._unverified()
        return f"Sleep در {int(DEFER_SECONDS)} ثانیه‌ی دیگر شروع می‌شود (UNVERIFIED: بعد از خواب، نتیجه قابل‌خواندن نیست). برای توقف همین حالا بگو «لغو کن»."

    def precheck_hibernate(self, a: dict) -> dict:
        state = hibernate_state()
        if state == "no":
            raise ToolError("Hibernate روی این سیستم فعال نیست (فایل hibernation نیست یا سخت‌افزار پشتیبانی نمی‌کند)؛ اگر Kira ادامه می‌داد ویندوز فقط Sleep می‌کرد. "
                            "فعال‌کردنش (powercfg /hibernate on) Administrator می‌خواهد و در این نسخه ساخته نشده؛ دستی از Terminal ادمین انجام بده.", ERROR, "missing_component")
        if state == "unknown":
            raise ToolError("نتوانستم تأیید کنم Hibernate فعال است (UNKNOWN)؛ برای اینکه به‌جای آن Sleep نشود، اجرا نکردم.", ERROR, "api_failure")
        return a

    def confirm_hibernate(self, a: dict) -> str:
        return ("Hibernate (خواب زمستانی) چند ثانیه‌ی دیگر. خلاصه‌ی اثر: وضعیت برنامه‌ها روی دیسک ذخیره و سیستم کاملاً خاموش می‌شود؛ با روشن کردن دستی ادامه می‌دهد. "
                "همه‌ی کارهای در حال اجرا متوقف می‌شوند.")

    def hibernate(self, a: dict) -> str:
        self.precheck_hibernate(a)
        _enable_shutdown_privilege()

        def go():
            import ctypes
            powrprof = ctypes.WinDLL("powrprof")
            powrprof.SetSuspendState.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, ctypes.c_ubyte]
            powrprof.SetSuspendState.restype = ctypes.c_ubyte
            if not powrprof.SetSuspendState(1, 0, 0):                      # hibernate=TRUE
                raise RuntimeError("SetSuspendState (hibernate) شکست خورد")
        self._defer("hibernate", go)
        self._unverified()
        return f"Hibernate در {int(DEFER_SECONDS)} ثانیه‌ی دیگر شروع می‌شود (UNVERIFIED). برای توقف همین حالا بگو «لغو کن»."

    def confirm_logoff(self, a: dict) -> str:
        return ("خروج از حساب کاربری ویندوز (Sign out) چند ثانیه‌ی دیگر. خلاصه‌ی اثر: نشست فعلی بسته می‌شود، برنامه‌ها و Kira بسته می‌شوند و کار ذخیره‌نشده ممکن است از بین برود "
                "(اجبار به بستن نمی‌شود؛ برنامه‌ی دارای کار ذخیره‌نشده ممکن است جلوی خروج را بگیرد).")

    def logoff(self, a: dict) -> str:
        _need_win("خروج از حساب")

        def go():
            import ctypes
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.ExitWindowsEx.argtypes = [ctypes.c_uint, ctypes.c_ulong]
            user32.ExitWindowsEx.restype = ctypes.c_int
            if not user32.ExitWindowsEx(0, REASON_PLANNED):                # EWX_LOGOFF, no EWX_FORCE
                raise RuntimeError(f"ExitWindowsEx کد {_last_error()}")
        self._defer("logoff", go)
        self._unverified()
        return f"خروج از حساب در {int(DEFER_SECONDS)} ثانیه‌ی دیگر شروع می‌شود (UNVERIFIED: Kira با نشست بسته می‌شود). برای توقف همین حالا بگو «لغو کن»."

    # ------------------------------------------------------------ cancel
    def cancel(self, a: dict) -> str:
        _need_win("لغو عملیات Power")
        cancelled = []
        with self._lock:
            tm = self._timer
            self._timer = None
        if tm:
            tm["timer"].cancel()
            cancelled.append(f"عملیات در آستانه‌ی اجرا ({tm['kind']})")
        _enable_shutdown_privilege()
        import ctypes
        from ctypes import wintypes
        advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
        advapi32.AbortSystemShutdownW.argtypes = [wintypes.LPWSTR]
        advapi32.AbortSystemShutdownW.restype = wintypes.BOOL
        if advapi32.AbortSystemShutdownW(None):
            with self._lock:
                self._pending = None
            cancelled.append("خاموشی/ریستارت زمان‌بندی‌شده‌ی ویندوز")
        else:
            err = _last_error()
            if err != ERR_NO_SHUTDOWN_IN_PROGRESS:
                if cancelled:
                    return "لغو شد: " + "، ".join(cancelled) + f". ولی لغو خاموشی ویندوز با کد {err} شکست خورد؛ وضعیت آن نامعلوم است (UNKNOWN)."
                raise ToolError(f"ویندوز لغو را نپذیرفت (کد {err}).", DENIED if err == ERR_ACCESS_DENIED else ERROR, "permission_denied" if err == ERR_ACCESS_DENIED else "api_failure")
        if cancelled:
            return "لغو شد: " + "، ".join(cancelled) + ". (پاسخ ویندوز: لغو پذیرفته شد.)"
        return "عملیات زمان‌بندی‌شده‌ای برای لغو نبود (ویندوز می‌گوید خاموشی/ریستارتی در جریان نیست). چیزی تغییر نکرد."


class PowerModule(WinModule):
    domain = "power"

    def __init__(self, access=None):
        self.t = PowerTools(access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("system",)
        delay = Param("delay_seconds", "integer", f"countdown in seconds ({MIN_DELAY}-{MAX_DELAY}, default {DEFAULT_DELAY}); lets the user cancel", False, DEFAULT_DELAY)
        return [
            Capability("power_status", "power", "read the power / session state: is hibernation available, is the screen locked, did Kira schedule a restart / shutdown. Changes nothing",
                       t.power_status, risk=READ, categories=cat, backend="win32"),
            Capability("power_lock", "power", "lock the Windows session (like Win+L). ONLY when the user's message explicitly asks to lock", t.lock, risk=ACTION, categories=cat, backend="win32",
                       intent_rx=LOCK_RX, memo=lambda a, x: "power_lock", changes_system=True),
            Capability("power_sleep", "power", "put the PC to Sleep a few seconds after the answer. The user confirms first. ONLY on an explicit request", t.sleep, risk=SENSITIVE, categories=cat,
                       backend="win32", permission=PROTECTED, intent_rx=SLEEP_RX, confirm_summary=t.confirm_sleep, memo=lambda a, x: "power_sleep", changes_system=True),
            Capability("power_hibernate", "power", "Hibernate the PC a few seconds after the answer (refused when hibernation is not available). The user confirms first. ONLY on an explicit request",
                       t.hibernate, risk=SENSITIVE, categories=cat, backend="win32", permission=PROTECTED, intent_rx=HIBERNATE_RX, confirm_summary=t.confirm_hibernate, precheck=t.precheck_hibernate,
                       memo=lambda a, x: "power_hibernate", changes_system=True),
            Capability("power_restart", "power", "restart Windows after a cancellable countdown (apps are NOT force-closed). PROTECTED: only when the user's current message asks for it AND the user confirms",
                       t.restart, risk=SENSITIVE, params=(delay,), categories=cat, backend="win32", permission=PROTECTED, intent_rx=RESTART_RX, confirm_summary=t.confirm_restart,
                       precheck=t.precheck_timed, memo=lambda a, x: "power_restart", changes_system=True),
            Capability("power_shutdown", "power", "shut Windows down after a cancellable countdown (apps are NOT force-closed). PROTECTED: only when the user's current message asks for it AND the user confirms",
                       t.shutdown, risk=SENSITIVE, params=(delay,), categories=cat, backend="win32", permission=PROTECTED, intent_rx=SHUTDOWN_RX, confirm_summary=t.confirm_shutdown,
                       precheck=t.precheck_timed, memo=lambda a, x: "power_shutdown", changes_system=True),
            Capability("power_logoff", "power", "sign the Windows user out a few seconds after the answer (apps are NOT force-closed). PROTECTED: only when the user's current message asks for it AND the user confirms",
                       t.logoff, risk=SENSITIVE, categories=cat, backend="win32", permission=PROTECTED, intent_rx=LOGOFF_RX, confirm_summary=t.confirm_logoff, memo=lambda a, x: "power_logoff",
                       changes_system=True),
            Capability("power_cancel", "power", "cancel a pending restart / shutdown (any scheduled by Windows) and a sleep / hibernate / log off that has not started yet. ONLY on an explicit request",
                       t.cancel, risk=ACTION, categories=cat, backend="win32", intent_rx=CANCEL_RX, memo=lambda a, x: "power_cancel", changes_system=True),
        ]
