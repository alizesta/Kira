"""Ordinary actions (level 2): open an installed app, open a file / folder with its default program, open a web link.

No shell is ever involved and nothing is built from model text as a command line. An app is found BY NAME among: Start Menu / Desktop
shortcuts, Steam library games (steam://rungameid/<id>), Windows' installed-apps list (install folder / icon), App Paths and Store apps
(see appcatalog.py) - or a short fixed list of Windows tools. Before starting anything the real state is checked (processes by image path,
visible and tray-hidden windows): a running instance is brought forward instead of starting a second one. Files / folders are opened with
their default program; programs / scripts / shortcuts can never be started through open_path.
"""
from __future__ import annotations

import difflib
import os
import re
import subprocess
import sys
import time
import webbrowser

from .access import PathPolicy, EXECUTABLE_EXT
from .registry import ToolError, DENIED
from . import sysinfo, appcatalog, appindex
from .appclose import open_guard

IS_WIN = sys.platform == "win32"
# Fixed Windows tools: name -> (label, how). "exe" = program in System32, "uri" = a Windows protocol link.
BUILTIN_APPS = {
    "notepad": ("Notepad", "exe", "notepad.exe", ("نوت پد", "نوتپد", "notepad", "ویرایشگر متن")),
    "calculator": ("Calculator", "exe", "calc.exe", ("ماشین حساب", "ماشینحساب", "calculator", "calc")),
    "paint": ("Paint", "exe", "mspaint.exe", ("پینت", "paint")),
    "explorer": ("File Explorer", "exe", "explorer.exe", ("فایل اکسپلورر", "اکسپلورر", "فایل منیجر", "explorer", "file explorer")),
    "clock": ("Clock", "uri", "ms-clock:", ("برنامه ساعت", "برنامه‌ی ساعت", "clock app", "alarms", "آلارم", "زنگ ساعت")),
    "settings": ("Settings", "uri", "ms-settings:", ("تنظیمات ویندوز", "windows settings", "settings")),
}
SKIP_WORDS = appcatalog.SKIP_WORDS
_norm = appcatalog.norm
# Spoken / Persian names -> the name used by the app itself (compared after normalisation)
_NAME_ALIASES = {"هاتاسپاتشیلد": "hotspotshield", "هاتاسپات": "hotspotshield", "هات‌اسپات‌شیلد": "hotspotshield",
                 "والپیپرانجین": "wallpaperengine", "وال‌پیپرانجین": "wallpaperengine", "والپیپر": "wallpaperengine", "wallpaper": "wallpaperengine"}
NOT_FOUND_TEXT_SHORT = ("جست‌وجو در Start Menu، Steam، برنامه‌های نصب‌شده‌ی ویندوز، برنامه‌های Store و اسکن پوشه‌های رایج (برنامه‌های پورتابل) انجام شد. "
                        "اگر کاربر نام دیگری برای همین برنامه می‌گوید، بپرس کدام برنامه است و بعد با remember_app_alias نامش را ذخیره کن.")
NOT_FOUND_TEXT = "برنامه‌ای با این نام پیدا نشد؛ " + NOT_FOUND_TEXT_SHORT
_NO_PLAN_WAIT = 8.0
_STEAM_WAIT = 20.0


def installed_apps(max_age: float = 120.0) -> list[tuple[str, str]]:
    """[(display name, shortcut path)] from the Start Menu (kept for older callers)."""
    return [(e.name, e.lnk_path()) for e in appcatalog.menu_apps(max_age) if e.lnk_path()]


def _pick(q: str, apps: list):
    """('hit', entry) | ('ambiguous', [names]) | ('none', None) - exact, then prefix, then substring; a clearly shortest name wins."""
    exact = [a for a in apps if a.key == q]
    if len(exact) == 1:
        return "hit", exact[0]
    starts = [a for a in apps if a.key.startswith(q)]
    if len(starts) == 1:
        return "hit", starts[0]
    contains = [a for a in apps if q in a.key]
    pool = exact or starts or contains
    if len(pool) == 1:
        return "hit", pool[0]
    if len(pool) > 1:
        pool = sorted(pool, key=lambda a: len(a.name))
        if len(pool[0].key) * 1.6 < len(pool[1].key):
            return "hit", pool[0]
        return "ambiguous", [a.name for a in pool[:8]]
    return "none", None


_LAST_FORCED = {"t": 0.0}
_FORCE_GAP = 120.0                                            # seconds between two full re-scans (the portable scan can take a few seconds)


def _all_entries() -> list:
    merged, seen = [], set()
    for src in (appcatalog.deep_apps, appcatalog.uwp_apps, appcatalog.portable_apps):
        try:
            for e in src():
                if e.key not in seen:
                    seen.add(e.key)
                    merged.append(e)
        except Exception:                                      # noqa: BLE001
            continue
    return merged


def resolve_app(name: str, _retry: bool = True):
    """-> ('builtin', key) | ('app', AppEntry) | ('ambiguous', [display names]) | ('none', [close names]).
    Order: learned alias -> Windows tools -> Start Menu / Desktop / Steam -> installed-apps registry + App Paths -> Store apps (registry)
    -> portable programs (folder scan) -> Store apps (PowerShell, last resort) -> sound-alike match (Persian names such as «پات پلیر»).
    If nothing matched, the catalog is rebuilt once (the app may have been installed a minute ago) and the search repeats.
    The first source with a unique match wins; a vague match is reported, never guessed."""
    q = _norm(name)
    if not q:
        return "none", []
    learned = appindex.STORE.get(name)
    if learned:
        q = _norm(learned)
    q = _norm(_NAME_ALIASES.get(q, q))
    for key, (label, _, _, aliases) in BUILTIN_APPS.items():
        if q == _norm(key) or q in {_norm(a) for a in aliases}:
            return "builtin", key
    for source in (appcatalog.menu_apps, appcatalog.deep_apps, appcatalog.uwp_apps, appcatalog.portable_apps, appcatalog.uwp_ps_apps):
        state, val = _pick(q, source())
        if state != "none":
            return ("app", val) if state == "hit" else ("ambiguous", val)
    pool = _all_entries()
    names = {e.key: e.name for e in pool}
    sounds = appindex.sound_match(name, names)
    if len(sounds) == 1 and appindex._PERSIAN_RX.search(str(name)):
        hit = next((e for e in pool if e.name == sounds[0]), None)
        if hit is not None:
            return "app", hit
    if _retry and time.monotonic() - _LAST_FORCED["t"] > _FORCE_GAP:
        _LAST_FORCED["t"] = time.monotonic()
        appcatalog.drop_cache()
        appcatalog.portable_apps(force=True)
        return resolve_app(name, _retry=False)
    close = difflib.get_close_matches(q, list(names), n=3, cutoff=0.72)
    out = [names[c] for c in close] + [s for s in sounds if s not in {names[c] for c in close}]
    return "none", out[:4]


# ------------------------------------------------------------------ how to recognise a running app
_GENERIC_STEMS = {"update", "launcher", "setup", "start", "run", "app", "bootstrapper", "squirrel", "installer", "cmd", "powershell", "explorer"}
_GENERIC_WORDS = {"engine", "windows", "microsoft", "google", "desktop", "client", "software", "system", "manager", "service", "services", "player"}
_STEM_ALIASES = {"googlechrome": ("chrome",), "microsoftedge": ("msedge",), "visualstudiocode": ("code",), "telegramdesktop": ("telegram",),
                 "vlcmediaplayer": ("vlc",), "mozillafirefox": ("firefox",), "calculator": ("calculatorapp", "calc", "win32calc"),
                 "paint": ("mspaint",), "notepad": ("notepad",), "fileexplorer": ("explorer",), "microsoftword": ("winword",),
                 "microsoftexcel": ("excel",), "microsoftpowerpoint": ("powerpnt",), "spotify": ("spotify",), "steam": ("steam",)}


def _stem_of(path_or_name: str) -> str:
    return os.path.splitext(os.path.basename(str(path_or_name)))[0].strip().lower().replace(" ", "")


def _process_stems(label: str, extra_exes=()) -> set:
    """Lower-case process names (without .exe) that belong to this app."""
    stems = set(_STEM_ALIASES.get(_norm(label), ()))
    for e in extra_exes:
        if e:
            stems.add(_stem_of(e))
    for word in re.findall(r"[A-Za-z0-9]{4,}", label):             # "Telegram Desktop" -> telegram
        if word.lower() not in _GENERIC_WORDS:
            stems.add(word.lower())
    stems.add(_norm(label))
    return {s for s in (x.replace(" ", "") for x in stems) if s and s not in _GENERIC_STEMS}


def _install_hint(entry) -> tuple:
    """(install folder, exe) of the Windows 'installed apps' record that belongs to the same app, ('', '') if none is clear."""
    key = entry.key
    for other in appcatalog.deep_apps():
        if other is entry or not (other.install_dir or other.exe):
            continue
        ok = other.key == key or (len(key) >= 5 and len(other.key) >= 5 and (other.key.startswith(key) or key.startswith(other.key)))
        if ok:
            return other.install_dir, other.exe
    return "", ""


def _identity(entry) -> appcatalog.AppIdentity:
    folders, exes, loose = [], [], []
    if entry.install_dir:
        folders.append(entry.install_dir)
    if entry.exe:
        exes.append(entry.exe)
        folders.append(os.path.dirname(entry.exe))
    if entry.lnk_path():
        for p in appcatalog.lnk_exes(entry.lnk_path()):
            if os.path.isabs(p):
                exes.append(p)
                folders.append(os.path.dirname(p))
            else:
                loose.append(p)
    if not any(appcatalog._usable_dir(f) for f in folders):       # the shortcut told us nothing: use the Windows installed-apps record
        d, e = _install_hint(entry)
        if d:
            folders.append(d)
        if e:
            exes.append(e)
    return appcatalog.AppIdentity(entry.name, folders, exes, _process_stems(entry.name, exes + loose))


def _builtin_identity(label: str, exe: str) -> appcatalog.AppIdentity:
    return appcatalog.AppIdentity(label, (), (), _process_stems(label, [exe] if exe else []))


class _State:
    """A snapshot of one app: its processes and windows right now."""

    def __init__(self, ident, with_hidden: bool):
        self.ident = ident
        self.procs = appcatalog.running_processes()
        strong, weak = appcatalog.match_processes(ident, self.procs)
        self.matched = strong + weak
        self.pids = {p["pid"] for p in self.matched}
        all_visible = sysinfo.visible_windows()
        self.visible = [w for w in all_visible if w["pid"] != os.getpid() and (w["pid"] in self.pids or _by_name(w, ident.stems))]
        seen = {w["hwnd"] for w in self.visible}
        self.hidden = []
        if with_hidden and self.pids:
            self.hidden = [w for w in appcatalog.windows_of_pids(self.pids) if not w["visible"] and w["hwnd"] not in seen]
        self.all_hwnds = {w["hwnd"] for w in all_visible}

    def main_exe_count(self) -> int:
        main = next((os.path.normcase(os.path.normpath(e)) for e in self.ident.exes if e), "")
        return sum(1 for p in self.procs if main and p.get("exe") and os.path.normcase(os.path.normpath(p["exe"])) == main)


def _by_name(w: dict, stems: set) -> bool:
    proc = os.path.splitext((w.get("process") or "").lower())[0].replace(" ", "")
    return bool(proc) and (proc in stems or any(len(s) >= 4 and s in proc for s in stems))


def find_running_windows(stems: set) -> list:
    """Visible top-level windows (minimized ones included) of the running app, topmost first."""
    return [w for w in sysinfo.visible_windows() if w["pid"] != os.getpid() and _by_name(w, stems)]


def _activate_best(label: str, wins: list, hidden: bool = False):
    """Restore (if minimized) and raise the best window. -> (report text, ok)."""
    import ctypes
    user32 = ctypes.windll.user32
    wins = sorted(wins, key=lambda w: bool(user32.IsIconic(w["hwnd"])))   # prefer a window that is not minimized (z-order is the tie-break)
    w = wins[0]
    ok, note = sysinfo.activate_window(w["hwnd"])
    if hidden:
        ok = ok or bool(user32.IsWindowVisible(w["hwnd"]) and not user32.IsIconic(w["hwnd"]))
        return (f"«{label}» در پس‌زمینه/System Tray اجرا بود و پنجره‌ی مخفی داشت؛ نمونه‌ی جدید باز نشد. {note} پنجره: «{w['title'][:50]}».", ok)
    more = f" (از {len(wins)} پنجره‌ی باز این برنامه، بالاترین انتخاب شد)" if len(wins) > 1 else ""
    text = f"«{label}» از قبل در حال اجرا بود؛ نمونه‌ی جدید باز نشد. {note}{more} پنجره: «{w['title'][:50]}»."
    if not ok:
        text += " (اگر برنامه با دسترسی Administrator اجرا شده باشد، ویندوز به Kira اجازه‌ی جلو آوردنش را نمی‌دهد.)"
    return text, ok


def activate_existing(label: str, lnk_path: str = "", exe: str = ""):
    """If the app already has a window: restore it (if minimized) and bring it to the front. -> (report text, ok), or None when it has no window."""
    if not IS_WIN:
        return None
    wins = find_running_windows(_process_stems(label, [exe] if exe else []))
    return _activate_best(label, wins) if wins else None


# ------------------------------------------------------------------ starting
_WINERR = {2: "فایل پیدا نشد", 3: "مسیر پیدا نشد", 5: "دسترسی رد شد", 87: "پارامتر نامعتبر", 193: "فایل اجرایی معتبر ویندوز نیست",
           740: "برنامه نیاز به دسترسی Administrator دارد", 1155: "هیچ برنامه‌ای برای این نوع لینک/فایل ثبت نشده است (مثلاً Steam نصب یا ثبت نشده)",
           1223: "کاربر پنجره‌ی UAC را لغو کرد", 1260: "سیاست امنیتی ویندوز اجرای این برنامه را مسدود کرده است"}


def _oserr(e: Exception) -> str:
    code = getattr(e, "winerror", None)
    base = _WINERR.get(code) or str(getattr(e, "strerror", "") or e)
    return f"{base} (WinError {code})" if code else base


def _method_text(kind: str, target: str) -> str:
    return {"lnk": "میان‌بر Start Menu", "steam": f"Steam (appid {target})", "exe": f"فایل اجرایی {target}", "uwp": "برنامه‌ی Store (shell:AppsFolder)"}.get(kind, kind)


def _launch_plan(entry) -> list:
    """[(kind, target, certain)] in the order they should be tried. Nothing here comes from model text."""
    plan = []
    learned = appindex.PATHS.get(entry.name)                      # 1) a path Kira confirmed from a real process / the user: beats every guess
    if learned:
        plan.append(("exe", learned, True))
    by_kind = {k: [t for kk, t in entry.launchers if kk == k] for k in ("lnk", "steam", "exe", "uwp")}
    dead_targets = []
    for t in by_kind["lnk"]:                                      # 2) a shortcut whose target is gone is NOT a launch method (it can only fail)
        dead = broken_shortcut_targets(t)
        if dead:
            dead_targets += dead
        else:
            plan.append(("lnk", t, True))
    plan += [("steam", t, True) for t in by_kind["steam"]]
    exes = list(by_kind["exe"])
    if entry.exe:
        exes.append(entry.exe)
    for dead in dead_targets:                                     # 3) ...but its tail is looked up under the usual install roots (user-profile part lost)
        fixed = appcatalog.repair_missing_exe(dead)
        if fixed:
            exes.append(fixed)
    certain_exes = [p for p in exes if appcatalog.is_safe_exe(p)]
    if not certain_exes and entry.lnk_path() and not dead_targets:
        certain_exes = [p for p in appcatalog.lnk_exes(entry.lnk_path()) if os.path.isabs(p) and appcatalog.is_safe_exe(p)]
    for p in dict.fromkeys(certain_exes):
        if not any(k == "exe" and os.path.normcase(t) == os.path.normcase(p) for k, t, _ in plan):
            plan.append(("exe", p, True))
    if not any(k in ("lnk", "steam", "exe") for k, _, _ in plan):                   # 4) install folder -> its main program (a folder is never started itself)
        folder, hint_exe = entry.install_dir, ""
        if not folder:
            folder, hint_exe = _install_hint(entry)
        if hint_exe and appcatalog.is_safe_exe(hint_exe):
            plan.append(("exe", hint_exe, True))
        else:
            guess = appcatalog.find_main_exe(entry.name, folder) if folder else ""
            if guess:
                plan.append(("exe", guess, False))                   # a guess from the folder contents: not "certain"
    plan += [("uwp", t, True) for t in by_kind["uwp"]]
    return plan


def broken_shortcut_targets(lnk_path: str) -> list:
    """Absolute .exe targets of a shortcut when NONE of them exists (the shortcut is dead); [] when it works or names no absolute program."""
    absolute = [p for p in appcatalog.lnk_exes(lnk_path) if os.path.isabs(p) and p.lower().endswith(".exe")]
    return absolute if absolute and not any(os.path.isfile(p) for p in absolute) else []


def _running_exe(st, ident) -> str:
    """The REAL program path of the app's running process (read from Windows now). Only an exact process-name match of the app, never a helper."""
    for proc in st.matched:
        exe = proc.get("exe") or ""
        if exe and appcatalog.is_safe_exe(exe) and _stem_of(exe) in ident.stems:
            return exe
    return ""


def _start(kind: str, target: str):
    """Start one thing through the Windows shell (never a command line). Raises OSError / ToolError with the real reason."""
    if kind == "lnk":
        bad = [p for p in appcatalog.lnk_exes(target) if os.path.basename(p).lower() in appcatalog.BLOCKED_EXES]
        if bad:
            raise ToolError("این میان‌بر به یک مفسر/ابزار فرمان اشاره می‌کند و اجرا نمی‌شود.", DENIED)
        absolute = [p for p in appcatalog.lnk_exes(target) if os.path.isabs(p) and p.lower().endswith(".exe")]
        if absolute and not any(os.path.isfile(p) for p in absolute):
            raise FileNotFoundError(2, "مقصد میان‌بر وجود ندارد (برنامه جابه‌جا یا حذف شده): " + absolute[0])
        os.startfile(target)
    elif kind == "steam":
        if not appcatalog._STEAM_ID_RX.match(str(target)):
            raise ToolError("شناسه‌ی Steam معتبر نیست.", DENIED)
        os.startfile(f"steam://rungameid/{target}")
    elif kind == "exe":
        if not appcatalog.is_safe_exe(target):
            raise ToolError("این فایل اجرایی مجاز یا موجود نیست: " + str(target), DENIED)
        try:
            os.startfile(target, cwd=os.path.dirname(target))
        except TypeError:
            os.startfile(target)
    elif kind == "uwp":
        if not appcatalog._AUMID_RX.match(str(target)):
            raise ToolError("شناسه‌ی برنامه‌ی Store معتبر نیست.", DENIED)
        os.startfile("shell:AppsFolder\\" + target)
    else:
        raise ToolError("روش اجرای ناشناخته.", DENIED)


_BROWSERS = {
    "edge": ("msedge.exe", ("msedge", "edge", "microsoft edge", "microsoftedge", "اج", "ایج", "مایکروسافت اج")),
    "chrome": ("chrome.exe", ("chrome", "google chrome", "کروم", "گوگل کروم")),
    "firefox": ("firefox.exe", ("firefox", "فایرفاکس", "فایرفوکس")),
    "brave": ("brave.exe", ("brave", "بریو", "برییو")),
    "opera": ("opera.exe", ("opera", "اپرا")),
}
_BROWSER_DIRS = {"edge": (r"Microsoft\Edge\Application",), "chrome": (r"Google\Chrome\Application",), "firefox": (r"Mozilla Firefox",),
                 "brave": (r"BraveSoftware\Brave-Browser\Application",), "opera": (r"Opera", r"Programs\Opera")}


def url_stem(url: str) -> tuple:
    """('claude.ai', 'claude'): the host and the site name a browser puts in the window title."""
    from urllib.parse import urlparse
    host = (urlparse(url).hostname or "").lower()
    host = host[4:] if host.startswith("www.") else host
    parts = host.split(".")
    return host, (parts[-2] if len(parts) >= 2 else host)


def browser_windows(wins, key=None) -> list:
    names = {_BROWSERS[key][0][:-4]} if key else {v[0][:-4] for v in _BROWSERS.values()}
    return [w for w in wins if str(w.get("process") or "").lower().removesuffix(".exe") in names]


def browser_check(key, url, before, windows_fn, sleep=time.sleep, seconds=8.0, clock=time.monotonic):
    """After a browser was told to open `url`: look at the REAL windows. -> (state, window)
    matched = a new window / changed title that names the site | already = the site was already the active title, nothing changed
    changed = a browser window is new or changed but its title does not name the site (not confirmed) | none = nothing changed."""
    host, stem = url_stem(url)
    old = {w["hwnd"]: w["title"] for w in before}
    named = lambda t: bool(stem) and len(stem) >= 3 and (stem in t.lower() or host in t.lower())          # noqa: E731
    already = next((w for w in before if named(w["title"])), None)
    deadline, changed, wins = clock() + seconds, None, []
    while True:
        wins = browser_windows(windows_fn(), key)
        for w in wins:
            fresh = w["hwnd"] not in old or old[w["hwnd"]] != w["title"]
            if fresh and named(w["title"]):
                return "matched", w
            if fresh and changed is None:
                changed = w
        if clock() >= deadline:
            break
        sleep(0.5)
    if changed:
        return "changed", changed
    if already:
        return "already", already
    return "none", (wins[0] if wins else None)


def browser_report(state, win, label, url, seconds=8) -> str:
    host, stem = url_stem(url)
    if state == "matched":
        return f"لینک در {label} باز شد و بازخوانی شد: پنجره‌ی «{win['title'][:60]}» نام سایت ({stem}) را دارد."
    if state == "already":
        return f"{label} همین الان هم عنوان «{win['title'][:60]}» را نشان می‌دهد (از قبل باز بود و عنوان تغییری نکرد)؛ فقط بگو از قبل باز بوده، نه اینکه تازه باز شد."
    if state == "changed":
        return (f"دستور به {label} داده شد و پنجره‌ی «{win['title'][:60]}» تازه یا تغییرکرده است، ولی تأیید نشد که صفحه‌ی {host} باز شده "
                "(عنوان با نام سایت نمی‌خواند؛ شاید هنوز بارگذاری می‌شود). باز شدن سایت را تأیید نکن.")
    return (f"دستور به {label} داده شد ولی تا {int(seconds)} ثانیه پنجره‌ی جدیدی دیده نشد و عنوان پنجره‌های آن تغییری نکرد؛ تأیید نشد که صفحه باز شده. "
            "باز شدنش را تأیید نکن.")


def browser_key(name) -> str | None:
    n = re.sub(r"\.exe$", "", str(name or "").strip().lower())
    for key, (_exe, aliases) in _BROWSERS.items():
        if n == key or n in aliases:
            return key
    return None


def browser_exe(key) -> str | None:
    """Full path of an installed browser: Windows 'App Paths' registry first, then the usual folders. None when not found."""
    exe = _BROWSERS[key][0]
    try:
        import winreg
        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(root, rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe}") as k:
                    path = winreg.QueryValueEx(k, None)[0]
                    if path and os.path.isfile(path):
                        return path
            except OSError:
                continue
    except ImportError:
        pass
    for env in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
        base = os.environ.get(env)
        for sub in _BROWSER_DIRS.get(key, ()):
            p = os.path.join(base or "", sub, exe)
            if base and os.path.isfile(p):
                return p
    return None


class AppTools:
    def __init__(self, policy: PathPolicy):
        self.policy = policy
        self.user_text = None                      # callable -> the user's CURRENT message (set by build_registry); None = no guard information

    @staticmethod
    def _describe(entry) -> str:
        sources = {"startmenu": "Start Menu", "steam": "کتابخانه‌ی Steam", "steam-shortcut": "میان‌بر Steam", "installed-apps": "برنامه‌های نصب‌شده‌ی ویندوز",
                   "app-paths": "App Paths", "store-app": "برنامه‌ی Store", "store-registry": "برنامه‌ی Store", "portable-scan": "اسکن پوشه‌ها (برنامه‌ی پورتابل)"}
        src = "، ".join(sources.get(s, s) for s in sorted(entry.sources))
        plan = _launch_plan(entry)
        how = _method_text(plan[0][0], plan[0][1]) + ("" if plan[0][2] else " (حدس از محتوای پوشه‌ی نصب)") if plan else "نامشخص (مسیر مطمئن اجرا پیدا نشد)"
        dead = [t for kk, lnk in entry.launchers if kk == "lnk" for t in broken_shortcut_targets(lnk)]
        if dead:
            how += f" (میان‌بر Start Menu خراب است و به «{dead[0]}» اشاره می‌کند که وجود ندارد؛ از روش جایگزین استفاده می‌شود)"
        return f"منبع: {src}. روش اجرا: {how}."

    def find_app(self, a: dict) -> str:
        kind, val = resolve_app(a["name"])
        if kind == "builtin":
            return f"ابزار ویندوز پیدا شد: {BUILTIN_APPS[val][0]} (با open_app باز می‌شود)."
        if kind == "app":
            status = ""
            if IS_WIN:
                st = _State(_identity(val), with_hidden=True)
                status = (" وضعیت: پنجره‌ی باز دارد." if st.visible else " وضعیت: در پس‌زمینه/Tray اجرا شده (پنجره‌ی مخفی دارد)." if st.hidden
                          else f" وضعیت: {len(st.pids)} پردازش در حال اجراست ولی پنجره‌ی قابل‌دیدن ندارد." if st.pids else " وضعیت: الان اجرا نیست.")
            return f"برنامه پیدا شد: {val.name} (با open_app باز می‌شود). {self._describe(val)}{status}"
        if kind == "ambiguous":
            return "چند برنامه‌ی نزدیک پیدا شد؛ از کاربر بپرس کدام: " + " ، ".join(val)
        if val:
            return "دقیقاً پیدا نشد؛ شاید منظور این‌هاست: " + " ، ".join(val)
        return NOT_FOUND_TEXT

    def remember_app_alias(self, a: dict) -> str:
        """Save «spoken name -> real app» after the user confirmed which app they mean. The app must really resolve; nothing is stored otherwise."""
        spoken, app = str(a["spoken"]).strip(), str(a["app"]).strip()
        kind, val = resolve_app(app, _retry=False)
        if kind == "builtin":
            target = BUILTIN_APPS[val][0]
        elif kind == "app":
            target = val.name
        else:
            raise ToolError(f"برنامه‌ای به نام «{app}» پیدا نشد، پس نام «{spoken}» ذخیره نشد. اول با find_app نام دقیق برنامه را پیدا کن.")
        if _norm(spoken) == _norm(target):
            return f"«{spoken}» همان نام خود برنامه است؛ نیازی به ذخیره نیست."
        try:
            appindex.STORE.add(spoken, target)
        except (ValueError, OSError) as e:
            raise ToolError(f"ذخیره نشد: {e}")
        return f"از این به بعد «{spoken}» یعنی «{target}»؛ نام در فایل app_aliases.json ذخیره شد."

    def remember_app_path(self, a: dict) -> str:
        """Save the REAL executable of an app so later open_app calls start it directly (instead of a broken shortcut). Sources: a path the user gave
        (an .exe, or an install FOLDER whose main program is looked up - the folder itself is never launched) or the app's running process."""
        app, path = str(a["app"]).strip(), str(a.get("path") or "").strip().strip('"')
        kind, val = resolve_app(app, _retry=False)
        if kind != "app":
            raise ToolError(f"برنامه‌ای به نام «{app}» پیدا نشد؛ اول با find_app نام دقیقش را پیدا کن. چیزی ذخیره نشد.")
        if path:
            exe = appcatalog.exe_from_path(val.name, path)
            if not exe:
                where = "پوشه است ولی فایل اجرایی اصلی روشنی داخلش پیدا نشد" if os.path.isdir(appcatalog._clean_path(path)) else "فایل اجرایی مجاز و موجودی نیست"
                raise ToolError(f"«{path}» {where}. چیزی ذخیره نشد؛ مسیر کامل فایل .exe را بگیر یا برنامه را باز کن و دوباره بخواه از پردازش در حال اجرا بخوانم.")
            known = [_stem_of(p) for p in (_process_stems(val.name))]
            plausible = _stem_of(exe) in set(known) or any(appcatalog._under(exe, r) for r in appcatalog.known_roots())
            if not plausible:
                raise ToolError(f"فایل «{exe}» با برنامه‌ی «{val.name}» نمی‌خواند و در پوشه‌های معمول نصب هم نیست؛ ذخیره نشد.", DENIED)
            source = "پوشه‌ی داده‌شده ← فایل اجرایی اصلی داخلش" if os.path.isdir(appcatalog._clean_path(path)) else "مسیر داده‌شده"
        else:
            st = _State(_identity(val), with_hidden=False) if IS_WIN else None
            exe = _running_exe(st, _identity(val)) if st else ""
            if not exe:
                raise ToolError(f"«{val.name}» الان اجرا نیست (یا Windows مسیر پردازشش را نمی‌دهد) و مسیری هم داده نشده؛ چیزی ذخیره نشد.")
            source = "پردازش در حال اجرا (مسیر از ویندوز خوانده شد)"
        try:
            appindex.PATHS.add(val.name, exe)
        except (ValueError, OSError) as e:
            raise ToolError(f"ذخیره نشد: {e}")
        if appindex.PATHS.get(val.name) != exe:                                           # read it back: never claim a save that did not happen
            raise ToolError("مسیر ذخیره شد ولی دوباره خوانده نشد؛ نامطمئن است و استفاده نمی‌شود.")
        return f"مسیر اجرایی «{val.name}» ذخیره و دوباره از روی دیسک تأیید شد: {exe} (منبع: {source}). شناسه‌ی پردازش (PID) ذخیره نمی‌شود."

    def open_app(self, a: dict) -> str:
        if not IS_WIN:
            raise ToolError("باز کردن برنامه فقط روی ویندوز ممکن است.")
        if str(a.get("url") or "").strip():                        # open_app(name="msedge", url="claude.ai") = open that link in that browser
            return self.open_url({"url": a["url"], "browser": a["name"]})
        why = open_guard(self.user_text() if callable(self.user_text) else "", str(a["name"]))
        if why:                                                    # a close request never becomes an open; a named program is never replaced by another one
            raise ToolError(why, DENIED)
        kind, val = resolve_app(a["name"])
        if kind == "ambiguous":
            return "برنامه‌ای باز نشد چون نام مبهم است. چند گزینه: " + " ، ".join(val) + ". از کاربر بپرس کدام را می‌خواهد."
        if kind == "none":
            hint = (" شاید منظور این‌ها باشد: " + " ، ".join(val)) if val else ""
            raise ToolError(f"برنامه‌ای به نام «{a['name']}» پیدا نشد؛ {NOT_FOUND_TEXT_SHORT}{hint}")
        if kind == "builtin":
            label, how, target, _ = BUILTIN_APPS[val]
            return self._open_builtin(label, how, target)
        return self._open_entry(val)

    # -- Windows tools (Notepad, Calculator ...): visible windows only, exactly as before
    def _open_builtin(self, label: str, how: str, target: str) -> str:
        found = activate_existing(label, exe=target if how == "exe" else "")
        if found:
            text, ok = found
            return text if ok else text + " (برنامه دوباره اجرا نشد.)"
        before = {w["hwnd"] for w in sysinfo.visible_windows()}
        if how == "exe":
            subprocess.Popen([target], shell=False)
        else:
            os.startfile(target)                                  # a Windows protocol link such as ms-clock:
        return f"دستور اجرای «{label}» به ویندوز داده شد. " + self._wait_new_window(before, 4.0)[1]

    # -- every other app: look at the real state first, reuse the running instance, start only if needed
    def _open_entry(self, entry) -> str:
        label = entry.name
        ident = _identity(entry)
        st = _State(ident, with_hidden=True)
        real = _running_exe(st, ident)                            # what Windows says about the running program beats any earlier guess
        if real and appindex.PATHS.get(label) != real:
            try:
                appindex.PATHS.add(label, real)
            except (ValueError, OSError):
                pass
        if st.visible:                                            # 1) a normal window exists: restore it and bring it forward
            text, ok = _activate_best(label, st.visible)
            return text if ok else text + " (برنامه دوباره اجرا نشد.)"
        if st.hidden:                                             # 2) running in the tray: its own hidden main window can be shown
            text, ok = _activate_best(label, st.hidden, hidden=True)
            if ok:
                return text
        running_note = ""
        if st.pids:
            names = ", ".join(sorted({p["name"] for p in st.matched if p.get("name")})[:4])
            running_note = (f"«{label}» از قبل در پس‌زمینه/System Tray در حال اجراست ({len(st.pids)} پردازش: {names}) ولی پنجره‌ی قابل‌دیدن ندارد؛ "
                            "برای فعال‌سازی همان نمونه، فقط یک‌بار دستور اجرای عادی داده شد تا خود برنامه نمونه‌ی در حال اجرا را بالا بیاورد. ")
        plan = _launch_plan(entry)
        if not plan:
            where = self._describe(entry)
            raise ToolError(f"«{label}» شناسایی شد ولی مسیر یا روش مطمئن اجرایش مشخص نیست، پس چیزی اجرا نشد تا نمونه‌ی ناخواسته ساخته نشود. {where}"
                            + (f" (برنامه در پس‌زمینه اجراست: {len(st.pids)} پردازش.)" if st.pids else ""))
        if st.pids and not plan[0][2]:
            return (f"«{label}» در پس‌زمینه اجراست ولی پنجره‌ی قابل‌دیدن ندارد و مسیر مطمئنی برای فعال‌سازی‌اش ندارم "
                    f"(فقط حدس: {plan[0][1]}). برای جلوگیری از اجرای نمونه‌ی دوم چیزی اجرا نشد؛ از کاربر بخواه از System Tray بازش کند.")
        errors, started = [], None
        for kind, target, _certain in plan:
            try:
                _start(kind, target)
                started = (kind, target)
                break
            except ToolError as e:
                errors.append(f"{_method_text(kind, target)}: {e}")
            except OSError as e:
                errors.append(f"{_method_text(kind, target)}: {_oserr(e)}")
        if not started:
            raise ToolError(f"اجرای «{label}» ناموفق بود. علت: " + " | ".join(errors))
        wait = _STEAM_WAIT if started[0] == "steam" else _NO_PLAN_WAIT
        report = self._verify(label, ident, st, wait)
        tried = (" (روش‌های ناموفق قبلی: " + " | ".join(errors) + ")") if errors else ""
        return f"{running_note}دستور اجرای «{label}» با {_method_text(*started)} به ویندوز داده شد.{tried} {report}"

    @staticmethod
    def _wait_new_window(before_hwnds: set, seconds: float, pids=None):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            time.sleep(0.5)
            new = [w for w in sysinfo.visible_windows() if w["hwnd"] not in before_hwnds and w["pid"] != os.getpid()]
            if pids is not None:
                new = [w for w in new if w["pid"] in pids] or []
            if new:
                w = new[0]
                return w, f"پنجره‌ی جدید دیده شد: «{w['title'][:60]}» ({w.get('process') or 'نامشخص'})."
        return None, (f"تا {int(seconds)} ثانیه پنجره‌ی جدیدی دیده نشد؛ ممکن است هنوز در حال بالا آمدن باشد یا در System Tray اجرا شود. "
                      "باز شدنش را تأیید نکن، فقط همین را به کاربر بگو.")

    def _verify(self, label: str, ident, before: "_State", seconds: float) -> str:
        """Honest check after a start: a new window, a window of the app's processes, or (at least) its processes."""
        deadline = time.monotonic() + seconds
        other_new = None
        while time.monotonic() < deadline:
            time.sleep(0.5)
            procs = appcatalog.running_processes()
            strong, weak = appcatalog.match_processes(ident, procs)
            pids = {p["pid"] for p in strong + weak}
            new = [w for w in sysinfo.visible_windows() if w["hwnd"] not in before.all_hwnds and w["pid"] != os.getpid()]
            mine = [w for w in new if w["pid"] in pids or _by_name(w, ident.stems)]
            if mine:
                return self._finish(f"پنجره‌ی جدید دیده شد: «{mine[0]['title'][:60]}» ({mine[0].get('process') or 'نامشخص'}).", ident, before)
            if new and other_new is None:
                other_new = new[0]
        procs = appcatalog.running_processes()
        strong, weak = appcatalog.match_processes(ident, procs)
        pids = {p["pid"] for p in strong + weak}
        hidden = [w for w in appcatalog.windows_of_pids(pids) if not w["visible"]] if pids else []
        if hidden:                                                # the relaunch woke the app's tray window: show it
            text, ok = _activate_best(label, hidden, hidden=True)
            if ok:
                return self._finish(text, ident, before)
        if other_new:
            return self._finish(f"پنجره‌ی جدید دیده شد: «{other_new['title'][:60]}» ({other_new.get('process') or 'نامشخص'}) "
                                "(ممکن است پنجره‌ی لانچر/برنامه‌ی واسط باشد، نه خود برنامه).", ident, before)
        if pids:
            names = ", ".join(sorted({p["name"] for p in strong + weak if p.get("name")})[:4])
            return self._finish(f"پردازش برنامه در حال اجراست ({len(pids)} پردازش: {names}) ولی تا {int(seconds)} ثانیه پنجره‌ی جدیدی دیده نشد؛ "
                                "احتمالاً در System Tray/پس‌زمینه است یا با دسترسی Administrator اجرا شده و Kira نمی‌تواند پنجره‌اش را ببیند. "
                                "باز شدنش را تأیید نکن، فقط همین را به کاربر بگو.", ident, before)
        return self._finish(f"تا {int(seconds)} ثانیه پنجره‌ی جدیدی دیده نشد و هیچ پردازشی از این برنامه هم پیدا نشد؛ ویندوز دستور را پذیرفت ولی برنامه بالا نیامد "
                            "(علت ممکن: خطای خود برنامه، نیاز به ورود/به‌روزرسانی، یا مسدود شدن توسط آنتی‌ویروس/UAC). باز شدنش را تأیید نکن، فقط همین را به کاربر بگو.",
                            ident, before)

    @staticmethod
    def _finish(text: str, ident, before: "_State") -> str:
        """Add a warning when the main program now has MORE processes than before (a possible second copy)."""
        try:
            now_procs = appcatalog.running_processes()
            main = next((os.path.normcase(os.path.normpath(e)) for e in ident.exes if e), "")
            after = sum(1 for p in now_procs if main and p.get("exe") and os.path.normcase(os.path.normpath(p["exe"])) == main)
            was = before.main_exe_count()
            if was and after > was:
                text += f" ⚠️ تعداد پردازش‌های برنامه‌ی اصلی از {was} به {after} رسید؛ ممکن است نمونه‌ی دوم هم باز شده باشد (برنامه‌های چندپردازشی ممکن است عادی باشد)."
        except Exception:                                          # noqa: BLE001
            pass
        return text

    def open_path(self, a: dict) -> str:
        path = self.policy.check(a["path"])
        ext = os.path.splitext(path)[1].lower()
        if ext in EXECUTABLE_EXT:
            raise ToolError("اجرای برنامه، اسکریپت یا میان‌بر از طریق open_path ممنوع است. برنامه‌ها فقط با open_app و نامشان باز می‌شوند.", DENIED)
        if not IS_WIN:
            raise ToolError("باز کردن فایل با برنامه‌ی پیش‌فرض فقط روی ویندوز ممکن است.")
        os.startfile(path)
        return ("پوشه در File Explorer باز شد: " if os.path.isdir(path) else "فایل با برنامه‌ی پیش‌فرضش باز شد: ") + path

    def open_url(self, a: dict) -> str:
        url = str(a["url"]).strip()
        if not re.match(r"^[a-z][a-z0-9+.-]*://", url, re.I) and re.match(r"^(?:www\.)?[\w-]+(?:\.[\w-]+)*\.[a-z]{2,}(?:[/?#]\S*)?$", url, re.I):
            url = "https://" + url                                   # "claude.ai" -> https://claude.ai
        if not re.match(r"^https?://[^\s]+$", url, re.I):
            raise ToolError("فقط لینک http یا https باز می‌شود.", DENIED)
        want = str(a.get("browser") or "").strip()
        key = browser_key(want)
        if want and key is None and want.lower() not in ("default", "پیش‌فرض", "پیشفرض"):
            raise ToolError(f"مرورگر «{want}» شناخته نشد (edge / chrome / firefox / brave / opera). چیزی باز نشد.")
        if key:
            exe = browser_exe(key)
            if not exe:
                raise ToolError(f"مرورگر «{key}» روی این سیستم پیدا نشد؛ چیزی باز نشد و مرورگر دیگری جایش باز نشد.")
            before = browser_windows(sysinfo.visible_windows(), key) if IS_WIN else []
            try:
                subprocess.Popen([exe, url], shell=False)             # the named browser itself (never the default one)
            except OSError as exc:
                raise ToolError(f"اجرای {key} ناموفق بود: {exc}") from exc
            if not IS_WIN:
                return f"دستور باز کردن {url} به مرورگر {key} داده شد (باز شدن صفحه تأیید نشد، فقط دستور فرستاده شد)."
            state, win = browser_check(key, url, before, sysinfo.visible_windows)
            return browser_report(state, win, key, url)
        before = browser_windows(sysinfo.visible_windows()) if IS_WIN else []
        if not webbrowser.open(url):
            raise ToolError("مرورگر پیش‌فرض باز نشد.")
        if not IS_WIN:
            return f"لینک در مرورگر پیش‌فرض باز شد: {url}"
        state, win = browser_check(None, url, before, sysinfo.visible_windows)
        return browser_report(state, win, "مرورگر پیش‌فرض", url)
