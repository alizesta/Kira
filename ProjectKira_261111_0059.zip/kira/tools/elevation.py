"""Elevation (T6): how ONE operation that genuinely needs Administrator rights is run - and nothing else.

Kira itself always runs as the normal user. It is never started elevated and never stays elevated. The only way anything runs with Administrator rights is:

  1. a capability declared with permission=ELEVATED (always `elevated` domain, backend `elevated-uac`);
  2. ToolRegistry.execute() -> AccessManager: the user must confirm THIS tool with THESE arguments (one-shot grant, 5 minutes, cleared by Stop).
     The confirmation text says what will happen and why Administrator is needed. A different argument = a different operation = a new question;
  3. only then the handler asks Windows for elevation (ShellExecuteExW, verb `runas`). Windows UAC shows its own prompt for this one process;
     if the user answers No, nothing ran and the result says so (kind=user_cancelled);
  4. the elevated process is the Microsoft-signed Windows PowerShell started with a FIXED, allow-listed script body. The only variable part is a
     base64 JSON blob of arguments that were validated in Python first (closed lists / strict patterns) and that the script reads as DATA.
     No free command, no -ExecutionPolicy Bypass, no file or pipe that a non-elevated process could tamper with: the elevated process reports only
     its exit code (0 = ok, otherwise the HRESULT of the failure);
  5. the exit code is never trusted as proof: the handler re-reads the REAL state with a normal (non-elevated) fixed script and reports that.

What is deliberately NOT here: no stored credentials, no "remember I approved", no automatic retry with elevation after a normal operation failed,
no UAC bypass, no scheduled-task / service trick, no permanent helper. A failed normal operation is never proof that Administrator would help.

Known limit (be honest): Windows shows the UAC prompt for "Windows PowerShell" (Microsoft-signed), not for "Kira", because Kira has no signed elevated
helper of its own. Kira's own confirmation (before the prompt) is the place that explains the exact operation. A signed helper executable would be the
next step; the allow-list below is already the interface it would implement.
"""
from __future__ import annotations

import base64
import json
import re
import time
from dataclasses import dataclass
from typing import Callable

from .registry import ToolError, Param, SENSITIVE, DENIED, ERROR
from .sysaccess import ELEVATED
from .winrunner import FixedScript, run_fixed, powershell_path, IS_WIN
from .wincontrol import Capability, WinModule

UAC_CANCELLED = 1223                         # ERROR_CANCELLED: the user answered "No" in the UAC prompt
WAIT_TIMEOUT = 0x102
SEE_MASK_NOCLOSEPROCESS, SEE_MASK_NOASYNC = 0x40, 0x100
MAX_CMDLINE = 30000                          # Windows limit is 32767 characters for the whole command line
_FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def needs_admin_error(what: str, tool: str = "") -> ToolError:
    """For a normal tool that KNOWS (not guesses) that this exact operation needs Administrator. Nothing is retried; the user is asked first."""
    hint = f" ابزار «{tool}» همین کار را فقط بعد از تأیید صریح و با UAC انجام می‌دهد." if tool else ""
    return ToolError(f"{what} این کار Administrator لازم دارد و با دسترسی عادی انجام نشد. هیچ تغییری داده نشد و خودکار هم UAC درخواست نشد.{hint}", DENIED, "admin_required")


# ---------------------------------------------------------------------------------------------------------------- operations
@dataclass(frozen=True)
class ElevatedOp:
    name: str
    reason: str                              # why Administrator is needed (Persian, shown in the confirmation)
    body: str                                # fixed PowerShell; reads $req (validated data); must `exit` only through the wrapper
    validate: Callable[[dict], dict]         # strict validation -> the data blob (closed lists / patterns only)
    timeout: int = 90                        # seconds to wait for the elevated process AFTER the user approved UAC


# The wrapper: data arrives as base64 JSON (charset A-Za-z0-9+/=, so it cannot carry code), is decoded to an object and only read.
_WRAPPER = r"""
$ErrorActionPreference = 'Stop'
$code = 0
try {
  $req = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('@@DATA@@')) | ConvertFrom-Json
@@BODY@@
} catch {
  $code = [int]$_.Exception.HResult
  if ($code -eq 0) { $code = 1 }
}
exit $code
"""

# A service name is never typed by the model into a script: only these keys exist.
ALLOWED_SERVICES = {"Spooler": "Print Spooler (چاپ)", "Audiosrv": "Windows Audio (صدا)", "bthserv": "Bluetooth Support Service (بلوتوث)"}
_ADAPTER_RX = re.compile(r"^[\w ().#\-]{1,64}$")             # no wildcard characters (* ? [ ]) and no quotes


def _validate_service(a: dict) -> dict:
    name = str(a.get("service") or "").strip()
    if name not in ALLOWED_SERVICES:
        raise ToolError("این سرویس در فهرست مجاز نیست. مجاز: " + "، ".join(ALLOWED_SERVICES), "bad_args")
    return {"service": name}


def _validate_adapter(a: dict) -> dict:
    name = str(a.get("adapter") or "").strip()
    if not _ADAPTER_RX.match(name):
        raise ToolError("نام آداپتور شبکه معتبر نیست (حداکثر ۶۴ نویسه، بدون * ? [ ] و نقل‌قول).", "bad_args")
    enabled = a.get("enabled")
    if not isinstance(enabled, bool):
        raise ToolError("مقدار enabled باید true یا false باشد.", "bad_args")
    return {"adapter": name, "enabled": enabled}


OPS = {
    "service_restart": ElevatedOp(
        "service_restart", "سرویس‌های ویندوز فقط با دسترسی Administrator قابل راه‌اندازی مجدد هستند.",
        "  $svc = Get-Service -Name $req.service -ErrorAction Stop\n  Restart-Service -InputObject $svc -Force -ErrorAction Stop", _validate_service),
    "dns_flush": ElevatedOp(
        "dns_flush", "پاک‌کردن کش DNS ویندوز (Clear-DnsClientCache) بدون Administrator ممکن نیست.",
        "  Clear-DnsClientCache -ErrorAction Stop", lambda a: {}),
    "network_adapter_set": ElevatedOp(
        "network_adapter_set", "فعال/غیرفعال کردن آداپتور شبکه تنظیم سیستمی است و فقط با دسترسی Administrator ممکن است.",
        "  if ($req.enabled) { Enable-NetAdapter -Name $req.adapter -Confirm:$false -ErrorAction Stop }\n"
        "  else { Disable-NetAdapter -Name $req.adapter -Confirm:$false -ErrorAction Stop }", _validate_adapter),
}

# Normal (NOT elevated) fixed scripts that read the real state before / after. Data comes through KIRA_ELEV_REQ and is only read.
_READ_SERVICE = FixedScript("elev-read-service", r"""
$ErrorActionPreference = 'Stop'
try {
  $req = $env:KIRA_ELEV_REQ | ConvertFrom-Json
  $s = Get-Service -Name $req.service
  @{ ok = $true; status = [string]$s.Status } | ConvertTo-Json -Compress
} catch { @{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress }
""")
_READ_ADAPTER = FixedScript("elev-read-adapter", r"""
$ErrorActionPreference = 'Stop'
try {
  $req = $env:KIRA_ELEV_REQ | ConvertFrom-Json
  $a = Get-NetAdapter -Name $req.adapter
  @{ ok = $true; status = [string]$a.Status; name = [string]$a.Name } | ConvertTo-Json -Compress
} catch { @{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress }
""")


def _read(script: FixedScript, req: dict, what: str) -> dict:
    """Normal-user read. -> {'ok': True, 'status': ...} or raises ToolError with the real, classified reason."""
    if not IS_WIN:
        raise ToolError("این عملیات فقط روی ویندوز ممکن است.", ERROR, "missing_component")
    data = run_fixed(script, env={"KIRA_ELEV_REQ": json.dumps(req, ensure_ascii=True)}, timeout=30, api_name=what)
    if data.get("ok"):
        return data
    err = str(data.get("error") or "نامشخص")
    low = err.lower()
    if data.get("fatal"):
        raise ToolError(f"خواندن وضعیت «{what}» ممکن نشد: {err[:250]}", ERROR, str(data.get("kind") or "powershell_failure"))
    if "cannot find" in low or "no msft_netadapter" in low or "no service" in low or "not found" in low:
        raise ToolError(f"«{what}» روی این سیستم پیدا نشد: {err[:200]}", ERROR, "device_unavailable")
    if "not recognized" in low or ("cmdlet" in low and "not" in low):
        raise ToolError(f"مؤلفه‌ی لازم ویندوز برای «{what}» در این سیستم نیست: {err[:200]}", ERROR, "missing_component")
    if "access" in low and "denied" in low:
        raise ToolError(f"ویندوز حتی خواندن «{what}» را اجازه نداد: {err[:200]}", DENIED, "permission_denied")
    raise ToolError(f"خواندن وضعیت «{what}» انجام نشد: {err[:250]}", ERROR, "api_failure")


# ---------------------------------------------------------------------------------------------------------------- the UAC launcher
_EXIT_KIND = {0x80070005: ("permission_denied", "ویندوز یا سیاست سیستم حتی با Administrator اجازه نداد"),
              0x80070424: ("missing_component", "سرویس موردنظر روی این سیستم ثبت نشده است"),
              0x80070057: ("api_failure", "پارامتر برای ویندوز نامعتبر بود"),
              0x80131501: ("missing_component", "دستور لازم PowerShell (ماژول) در این ویندوز نیست")}


def _explain_exit(code: int, doing: str) -> ToolError:
    kind, text = _EXIT_KIND.get(code, ("api_failure", "عملیات با خطای ویندوز تمام شد"))
    hexcode = f"0x{code & 0xFFFFFFFF:08X}"
    return ToolError(f"{doing} انجام نشد: {text} (کد {hexcode}). UAC تأیید شده بود ولی ویندوز نتیجه را موفق گزارش نکرد؛ وضعیت واقعی دوباره بررسی شد/می‌شود.",
                     DENIED if kind == "permission_denied" else ERROR, kind)


def build_script(op: ElevatedOp, data: dict) -> FixedScript:
    """The elevated script = fixed wrapper + fixed body + a base64 JSON blob. Nothing else can enter it."""
    blob = base64.b64encode(json.dumps(data, ensure_ascii=True, sort_keys=True).encode("utf-8")).decode("ascii")
    text = _WRAPPER.replace("@@BODY@@", op.body).replace("@@DATA@@", blob)
    return FixedScript("elevated-" + op.name, text)


def _launch_uac(script: FixedScript, timeout: int, doing: str, access) -> int:
    """Ask Windows UAC to start ONE elevated PowerShell with the script; wait; -> its exit code. Raises ToolError for decline / failure / timeout."""
    if not IS_WIN:
        raise ToolError("درخواست UAC فقط روی ویندوز ممکن است.", ERROR, "missing_component")
    import ctypes
    from ctypes import wintypes

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", ctypes.c_ulong), ("hwnd", wintypes.HWND), ("lpVerb", wintypes.LPCWSTR), ("lpFile", wintypes.LPCWSTR),
                    ("lpParameters", wintypes.LPCWSTR), ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE),
                    ("lpIDList", ctypes.c_void_p), ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY), ("dwHotKey", wintypes.DWORD),
                    ("hIconOrMonitor", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]

    encoded = base64.b64encode(script.text.encode("utf-16-le")).decode("ascii")
    params = f"-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand {encoded}"
    if len(params) > MAX_CMDLINE:
        raise ToolError("اسکریپت عملیات برای خط فرمان ویندوز بیش از حد بزرگ است؛ اجرا نشد.", ERROR, "api_failure")
    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell32.ShellExecuteExW.argtypes = [ctypes.POINTER(SHELLEXECUTEINFOW)]
    shell32.ShellExecuteExW.restype = wintypes.BOOL
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    info = SHELLEXECUTEINFOW()
    info.cbSize = ctypes.sizeof(SHELLEXECUTEINFOW)
    info.fMask = SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC
    info.lpVerb = "runas"                                   # the supported way to request elevation: Windows UAC asks the user
    info.lpFile = powershell_path()                         # Microsoft-signed Windows PowerShell from System32
    info.lpParameters = params
    info.nShow = 0                                          # SW_HIDE
    if not shell32.ShellExecuteExW(ctypes.byref(info)):
        err = ctypes.get_last_error()
        if err == UAC_CANCELLED:
            raise ToolError(f"{doing} لغو شد: در پنجره‌ی UAC ویندوز «No» زده شد (یا UAC بسته شد). هیچ تغییری داده نشد و دوباره هم درخواست نمی‌کنم مگر خودت بخواهی.",
                            DENIED, "user_cancelled")
        raise ToolError(f"{doing} انجام نشد: ویندوز درخواست UAC را شروع نکرد (کد {err}).", ERROR, "api_failure")
    access.set_uac(True)                                    # the user approved the UAC prompt: the journal records that elevation really happened
    handle = info.hProcess
    if not handle:
        raise ToolError(f"{doing}: ویندوز فرایند بالارفته را برنگرداند؛ نتیجه نامعلوم است، وضعیت واقعی را بررسی کن.", ERROR, "api_failure")
    try:
        if kernel32.WaitForSingleObject(handle, int(timeout) * 1000) == WAIT_TIMEOUT:
            raise ToolError(f"{doing}: بعد از تأیید UAC عملیات در {str(timeout).translate(_FA_DIGITS)} ثانیه تمام نشد. متوقفش نکردم؛ وضعیت واقعی را بررسی کن.", ERROR, "timeout")
        code = wintypes.DWORD(0)
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
            raise ToolError(f"{doing}: کد خروج فرایند خوانده نشد؛ وضعیت واقعی بررسی می‌شود.", ERROR, "api_failure")
        return int(code.value)
    finally:
        kernel32.CloseHandle(handle)


def run_elevated(op_name: str, params: dict, access) -> None:
    """Validate -> UAC -> run the allow-listed op once. Raises ToolError (with kind) unless the process reported success. The CALLER then verifies the real state."""
    op = OPS.get(op_name)
    if op is None:
        raise ToolError(f"عملیات بالارفته‌ی «{op_name}» در فهرست مجاز نیست.", "bad_args")
    data = op.validate(params)
    doing = f"عملیات «{op_name}»"
    code = _launch_uac(build_script(op, data), op.timeout, doing, access)
    if code != 0:
        raise _explain_exit(code, doing)


# ---------------------------------------------------------------------------------------------------------------- the module
class ElevationModule(WinModule):
    """The two first elevated capabilities. Each: confirm (exact args) -> read state -> (skip if nothing to do) -> UAC -> re-read the real state."""
    domain = "elevated"

    def __init__(self, access):
        self.access = access

    # ---- service_restart ----
    def _svc_precheck(self, a: dict) -> dict:
        data = _validate_service(a)
        _read(_READ_SERVICE, data, "سرویس " + data["service"])        # a missing service is reported now, not after the question
        return {"service": data["service"]}

    def _svc_confirm(self, a: dict) -> str:
        label = ALLOWED_SERVICES.get(a.get("service"), a.get("service"))
        return (f"راه‌اندازی مجدد (Restart) سرویس «{label}». {OPS['service_restart'].reason} فقط اگر تأیید کنی، ویندوز یک پنجره‌ی UAC (با نام Windows PowerShell) "
                f"برای همین یک عملیات نشان می‌دهد؛ اگر آنجا «No» بزنی هیچ چیز تغییر نمی‌کند. اپ‌هایی که از این سرویس استفاده می‌کنند لحظه‌ای قطع می‌شوند.")

    def _svc_run(self, a: dict) -> str:
        data = _validate_service(a)
        label = ALLOWED_SERVICES[data["service"]]
        before = _read(_READ_SERVICE, data, "سرویس " + data["service"]).get("status")
        run_elevated("service_restart", data, self.access)
        after = _read(_READ_SERVICE, data, "سرویس " + data["service"]).get("status")
        if after != "Running":
            raise ToolError(f"ویندوز عملیات را پذیرفت ولی وضعیت واقعی سرویس «{label}» الان {after} است (قبل: {before}) و Running نشد.", ERROR, "api_failure")
        return f"سرویس «{label}» دوباره راه‌اندازی شد. وضعیت واقعی بعد از عملیات: Running (قبل: {before}). فقط همین عملیات با UAC اجرا شد."

    # ---- network_adapter_set ----
    def _adapter_precheck(self, a: dict) -> dict:
        data = _validate_adapter(a)
        _read(_READ_ADAPTER, data, "آداپتور " + data["adapter"])
        return data

    def _adapter_confirm(self, a: dict) -> str:
        verb = "فعال کردن" if a.get("enabled") else "غیرفعال کردن"
        warn = " توجه: با غیرفعال کردن آداپتور ممکن است اینترنت یا اتصال شبکه‌ی همین PC (و ارتباط Kira با مدل‌های ابری) قطع شود." if not a.get("enabled") else ""
        return (f"{verb} آداپتور شبکه‌ی «{a.get('adapter')}». {OPS['network_adapter_set'].reason} فقط اگر تأیید کنی، ویندوز یک پنجره‌ی UAC (با نام Windows PowerShell) "
                f"برای همین یک عملیات نشان می‌دهد؛ اگر «No» بزنی هیچ چیز تغییر نمی‌کند.{warn}")

    def _adapter_run(self, a: dict) -> str:
        data = _validate_adapter(a)
        name, want = data["adapter"], data["enabled"]
        now = str(_read(_READ_ADAPTER, data, "آداپتور " + name).get("status"))
        if (now != "Disabled") == want:
            return f"آداپتور «{name}» همین حالا {'فعال' if want else 'غیرفعال'} است (وضعیت واقعی: {now}). چیزی تغییر نکرد و UAC هم درخواست نشد."
        run_elevated("network_adapter_set", data, self.access)
        for _ in range(8):                                       # enabling / disabling takes a moment: poll the REAL state
            now = str(_read(_READ_ADAPTER, data, "آداپتور " + name).get("status"))
            if (now != "Disabled") == want:
                return f"آداپتور «{name}» {'فعال' if want else 'غیرفعال'} شد. وضعیت واقعی بعد از عملیات: {now}. فقط همین عملیات با UAC اجرا شد."
            time.sleep(1.0)
        raise ToolError(f"UAC تأیید شد ولی وضعیت واقعی آداپتور «{name}» الان {now} است و به حالت خواسته‌شده نرسید.", ERROR, "api_failure")

    # ---- dns_flush ----
    def _dns_confirm(self, a: dict) -> str:
        return ("پاک‌کردن کش DNS ویندوز. " + OPS["dns_flush"].reason + " فقط اگر تأیید کنی، ویندوز یک پنجره‌ی UAC (با نام Windows PowerShell) برای همین یک عملیات نشان می‌دهد؛ "
                "اگر «No» بزنی هیچ چیز تغییر نمی‌کند. اثرش فقط این است که نام‌های سایت‌ها دوباره از DNS پرسیده می‌شوند.")

    def _dns_run(self, a: dict) -> str:
        run_elevated("dns_flush", {}, self.access)
        self.access.set_verification("unverified")             # the cache content cannot be read back without another PowerShell script: honest UNVERIFIED
        return ("دستور پاک‌کردن کش DNS با UAC اجرا شد و ویندوز بدون خطا برگشت. محتوای کش قابل بازخوانی نیست، پس نتیجه UNVERIFIED است؛ "
                "برای اطمینان می‌توان network_diagnose را اجرا کرد. فقط همین عملیات با UAC اجرا شد.")

    def capabilities(self) -> list[Capability]:
        cat = ("system", "network")
        return [
            Capability("service_restart", "elevated", "restart ONE allow-listed Windows service (Print Spooler, Windows Audio, Bluetooth Support). Needs Administrator: the user confirms first, "
                       "then Windows UAC asks for this single operation. Never run it for a problem that does not need it", self._svc_run, SENSITIVE,
                       (Param("service", "string", "Spooler | Audiosrv | bthserv", True, None, tuple(ALLOWED_SERVICES)),), cat, permission=ELEVATED, backend="elevated-uac",
                       confirm_summary=self._svc_confirm, precheck=self._svc_precheck, memo=lambda a, t: "service_restart → " + str(a.get("service")),
                       verifies_result=True, changes_system=True),
            Capability("dns_flush", "elevated", "clear the Windows DNS resolver cache (for 'sites do not open but internet works' problems). Needs Administrator: the user confirms first, then Windows UAC asks "
                       "for this single operation. The result cannot be read back (UNVERIFIED)", self._dns_run, SENSITIVE, (), cat, permission=ELEVATED, backend="elevated-uac",
                       confirm_summary=self._dns_confirm, memo=lambda a, t: "dns_flush", verifies_result=False, changes_system=True),
            Capability("network_adapter_set", "elevated", "enable (enabled=true) or disable (enabled=false) ONE network adapter by its Windows name (see get_network_info). Needs Administrator: "
                       "the user confirms first, then Windows UAC asks for this single operation", self._adapter_run, SENSITIVE,
                       (Param("adapter", "string", "adapter name exactly as Windows shows it (e.g. Wi-Fi, Ethernet)", True),
                        Param("enabled", "boolean", "true = enable, false = disable", True)), cat, permission=ELEVATED, backend="elevated-uac",
                       confirm_summary=self._adapter_confirm, precheck=self._adapter_precheck, memo=lambda a, t: "network_adapter_set → " + str(a.get("adapter")),
                       verifies_result=True, changes_system=True),
        ]


__all__ = ["ElevationModule", "ElevatedOp", "OPS", "ALLOWED_SERVICES", "run_elevated", "build_script", "needs_admin_error"]
