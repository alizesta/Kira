"""Fixed System32 programs (T6 Phase 3): netsh, ping, pnputil. Never a shell; the program name is a closed list; every argument is built by Kira's own code from
VALIDATED data (a closed list, a number, or a value that was first read back from Windows itself, e.g. a saved Wi-Fi profile name) - never raw model text.
Output is decoded with the console code page (netsh / ping print localized text, so callers parse structure and keywords defensively and say UNVERIFIED when they cannot)."""
from __future__ import annotations

import os
import subprocess
import sys

from .registry import ToolError

IS_WIN = sys.platform == "win32"
NO_WINDOW = 0x08000000 if IS_WIN else 0
ALLOWED = {"netsh": "netsh.exe", "ping": "ping.exe", "pnputil": "pnputil.exe"}


def _decode(raw: bytes) -> str:
    for enc in (("oem", "utf-8") if IS_WIN else ("utf-8",)):
        try:
            return raw.decode(enc)
        except (LookupError, UnicodeDecodeError):
            continue
    return raw.decode("utf-8", "replace")


def run_exe(name: str, args: list, timeout: int = 15) -> tuple:
    """-> (return code, text). Raises ToolError (with a real `kind`) when the program is missing, cannot start or times out."""
    if name not in ALLOWED:
        raise ToolError(f"برنامه‌ی «{name}» در فهرست مجاز نیست.", kind="bad_args")
    if not IS_WIN:
        raise ToolError("این عملیات فقط روی ویندوز ممکن است.", kind="missing_component")
    clean = []
    for x in args:
        x = str(x)
        if not x or len(x) > 260 or any(c in x for c in "\x00\r\n"):
            raise ToolError("آرگومان برنامه‌ی سیستمی معتبر نیست.", kind="bad_args")
        clean.append(x)
    exe = os.path.join(os.environ.get("SystemRoot") or r"C:\Windows", "System32", ALLOWED[name])
    if not os.path.isfile(exe):
        raise ToolError(f"{ALLOWED[name]} پیدا نشد.", kind="missing_component")
    try:
        r = subprocess.run([exe, *clean], capture_output=True, timeout=timeout, creationflags=NO_WINDOW, shell=False)
    except subprocess.TimeoutExpired:
        raise ToolError(f"{ALLOWED[name]} در {timeout} ثانیه پاسخ نداد (Timeout).", kind="timeout") from None
    except PermissionError:
        raise ToolError(f"ویندوز اجازه‌ی اجرای {ALLOWED[name]} را نداد.", kind="permission_denied") from None
    except OSError as e:
        raise ToolError(f"اجرای {ALLOWED[name]} ممکن نشد: {e}", kind="api_failure") from None
    return r.returncode, _decode((r.stdout or b"") + (r.stderr or b""))
