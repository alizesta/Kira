"""T6 Phase 2 - user settings (no Administrator, no PowerShell): wallpaper, light/dark theme, taskbar, toast notifications, mouse, keyboard, power timeouts / plan,
screen brightness. Everything is ctypes (user32 / shell32) or the current user's registry (HKCU); the only program ever started is powercfg.exe from System32 with FIXED,
validated arguments (never a shell, never text from the model).

Every setter re-reads the real value afterwards (verification). When the value cannot be read back from Windows the answer says so ("UNVERIFIED") instead of claiming success.
Every setter is a TRANSACTION: the previous state is read first; if any step fails or the re-read does not match, the previous state is written back and re-read, and the
answer says whether the rollback was confirmed (otherwise the state is reported as UNKNOWN). The last successful change can be undone with settings_undo.
Kira never restarts Explorer or any other program to make a setting visible. Failures are ToolError with a `kind` (unsupported / access_denied / backend_failure / timeout) so the journal shows the real reason.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time

from .access import PathPolicy
from .registry import ToolError, DENIED, Param, READ, ACTION
from .wincontrol import Capability, WinModule

try:
    import winreg
except Exception:                                             # noqa: BLE001
    winreg = None

IS_WIN = sys.platform == "win32"
NO_WINDOW = 0x08000000 if IS_WIN else 0
_PERSONALIZE = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
_ADVANCED = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
_PUSH = r"Software\Microsoft\Windows\CurrentVersion\PushNotifications"
_DESKTOP = r"Control Panel\Desktop"
_IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp"}
_STYLES = {"fill": ("10", "0"), "fit": ("6", "0"), "stretch": ("2", "0"), "tile": ("0", "1"), "center": ("0", "0"), "span": ("22", "0")}
_PLANS = {"balanced": "SCHEME_BALANCED", "high_performance": "SCHEME_MIN", "power_saver": "SCHEME_MAX"}
_POWER = {"screen_off": ("SUB_VIDEO", "VIDEOIDLE", "کم‌شدن/خاموش‌شدن نمایشگر"), "sleep": ("SUB_SLEEP", "STANDBYIDLE", "Sleep"),
          "brightness": ("SUB_VIDEO", "aded5e82-b909-4619-9949-f5d71dac0bcb", "روشنایی")}


def _need_win(what: str):
    if not IS_WIN:
        raise ToolError(f"{what} فقط روی ویندوز ممکن است.", kind="missing_component")


def _reg_get(path: str, name: str, default=None):
    if winreg is None:
        return default
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_READ) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return default


def _reg_set(path: str, name: str, value, kind=None) -> None:
    if winreg is None:
        raise ToolError("رجیستری در دسترس نیست.")
    kind = kind if kind is not None else (winreg.REG_DWORD if isinstance(value, int) else winreg.REG_SZ)
    try:
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, name, 0, kind, value)
    except PermissionError:
        raise ToolError("ویندوز اجازه‌ی نوشتن این تنظیم را نداد (سیاست امنیتی یا Group Policy).", kind="permission_denied")
    except OSError as e:
        raise ToolError(f"نوشتن تنظیم در رجیستری ناموفق بود: {e}")


def _broadcast(area: str = "ImmersiveColorSet") -> None:
    import ctypes
    res = ctypes.c_ulong(0)
    ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, area, 0x2, 3000, ctypes.byref(res))      # WM_SETTINGCHANGE


def _spi(action: int, ui: int = 0, pv=None, flags: int = 0) -> bool:
    import ctypes
    return bool(ctypes.windll.user32.SystemParametersInfoW(action, ui, pv, flags))


def _int_arg(a: dict, name: str, lo: int, hi: int) -> int:
    try:
        v = int(float(str(a[name]).strip().rstrip("%")))
    except (KeyError, ValueError, TypeError):
        raise ToolError(f"«{name}» باید یک عدد صحیح باشد.")
    if not lo <= v <= hi:
        raise ToolError(f"«{name}» باید بین {lo} و {hi} باشد.")
    return v


def _powercfg(*args: str, timeout: int = 10) -> str:
    """Run System32\\powercfg.exe with FIXED arguments. Every argument is checked to be a known alias / GUID / number."""
    for x in args:
        if not re.fullmatch(r"/[a-z]+|SCHEME_[A-Z]+|SUB_[A-Z]+|[A-Za-z]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\d{1,6}", x):
            raise ToolError("آرگومان powercfg مجاز نیست.", DENIED)
    exe = os.path.join(os.environ.get("SystemRoot") or r"C:\Windows", "System32", "powercfg.exe")
    if not os.path.isfile(exe):
        raise ToolError("powercfg.exe پیدا نشد.", kind="missing_component")
    try:
        r = subprocess.run([exe, *args], capture_output=True, timeout=timeout, creationflags=NO_WINDOW, shell=False)
    except subprocess.TimeoutExpired:
        raise ToolError("powercfg پاسخ نداد (Timeout).", kind="timeout")
    text = (r.stdout or b"").decode("utf-8", "ignore") + (r.stderr or b"").decode("utf-8", "ignore")
    if r.returncode != 0:
        raise ToolError("powercfg خطا داد: " + text.strip()[:200], kind="api_failure")
    return text


def _power_values(group: str, setting: str) -> tuple:
    """-> (AC value, DC value) of the active plan (raw numbers; powercfg prints them as 0x........ - the last two are AC and DC)."""
    out = _powercfg("/query", "SCHEME_CURRENT", group, setting)
    hexes = re.findall(r"0x([0-9a-fA-F]{8})", out)
    if len(hexes) < 2:
        raise ToolError("مقدار این تنظیم از powercfg خوانده نشد (احتمالاً روی این دستگاه پشتیبانی نمی‌شود).", kind="unsupported_hardware")
    return int(hexes[-2], 16), int(hexes[-1], 16)



def _guid_of_active() -> str:
    m = re.search(r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})", _powercfg("/getactivescheme"))
    if not m:
        raise ToolError("Power plan فعال خوانده نشد.", kind="api_failure")
    return m.group(1).lower()


def _has_internal_battery() -> bool:
    """True when Windows reports a system battery (laptop / tablet). A desktop PC with an external monitor has none."""
    import ctypes

    class SPS(ctypes.Structure):
        _fields_ = [("AC", ctypes.c_ubyte), ("Flag", ctypes.c_ubyte), ("Pct", ctypes.c_ubyte), ("Sys", ctypes.c_ubyte), ("Life", ctypes.c_ulong), ("Full", ctypes.c_ulong)]
    st = SPS()
    if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(st)):
        return False
    return st.Flag != 255 and not (st.Flag & 128)


class SettingsTools:
    def __init__(self, policy: PathPolicy | None = None, access=None):
        self.policy = policy
        self.access = access                                       # AccessManager: used ONLY to journal a rollback (it grants nothing)
        self._undo = None                                          # (label, snapshot, snap_fn, apply_fn) of the last successful change

    # ------------------------------------------------------------ transaction + undo
    def _txn(self, label: str, snap_fn, apply_fn, do):
        before = snap_fn()
        try:
            msg = do()
        except ToolError as e:
            raise self._rollback(before, snap_fn, apply_fn, e)
        except Exception as e:                                     # noqa: BLE001 - an unexpected crash must not leave a half-applied change
            raise self._rollback(before, snap_fn, apply_fn, ToolError(f"خطای غیرمنتظره در {label}: {type(e).__name__}", kind="api_failure"))
        self._undo = (label, before, snap_fn, apply_fn)
        return msg + " (اگر نخواستی، settings_undo همین تغییر را برمی‌گرداند؛ فقط تا وقتی برنامه بسته نشده.)"

    def _journal(self, tool: str, ok: bool, text: str) -> None:
        """A rollback is part of an operation that ALREADY passed permission / confirmation (the handler only runs after that); it only writes back values this same call
        read a moment before - never anything else - and always leaves its own Journal line. UNKNOWN is recorded when the restore could not be verified."""
        if self.access is not None:
            try:
                self.access.record_event(tool, "settings", "CONTROL", "ok" if ok else "error", "win32", text, "verified" if ok else "unknown", "" if ok else "api_failure")
            except Exception:                                      # noqa: BLE001 - journaling must never break the answer
                pass

    def _rollback(self, before, snap_fn, apply_fn, err: ToolError) -> ToolError:
        try:
            apply_fn(before)
            time.sleep(0.3)
            ok = snap_fn() == before
        except Exception:                                          # noqa: BLE001
            ok = False
        self._journal("settings.rollback", ok, ("وضعیت قبلی برگردانده و تأیید شد" if ok else "بازگردانی تأیید نشد؛ وضعیت واقعی ویندوز نامشخص (UNKNOWN)") + f" — علت شکست اول: {str(err)[:120]}")
        tail = ("تغییر ناقص برگردانده شد و وضعیت قبلی دوباره خوانده و تأیید شد." if ok else
                "بازگردانی هم کامل تأیید نشد؛ وضعیت فعلی ویندوز نامشخص است (UNKNOWN). از کاربر بخواه این تنظیم را در Settings ویندوز بررسی کند.")
        return ToolError(f"{err} — {tail}", kind=getattr(err, "kind", "") or "api_failure")

    def confirm_undo(self, a: dict) -> str:
        if not self._undo:
            return "برگرداندن آخرین تغییر تنظیمات (در این اجرای برنامه تغییری ثبت نشده، پس چیزی برنمی‌گردد)."
        return f"«{self._undo[0]}» به وضعیتی که قبل از آخرین تغییر Kira داشت برمی‌گردد (فقط همان تنظیمات، و بعدش دوباره خوانده می‌شود)."

    def settings_undo(self, a: dict) -> str:
        _need_win("برگرداندن تنظیم")
        if not self._undo:
            raise ToolError("تغییری در این اجرای برنامه برای برگرداندن ثبت نشده است.")
        label, before, snap_fn, apply_fn = self._undo
        apply_fn(before)
        time.sleep(0.4)
        if snap_fn() != before:
            self._journal("settings.undo", False, f"برگرداندن «{label}» تأیید نشد (UNKNOWN)")
            raise ToolError(f"برگرداندن «{label}» کامل تأیید نشد؛ وضعیت نامشخص است (UNKNOWN). کاربر باید در Settings ویندوز نگاه کند.")
        self._undo = None
        return f"«{label}» به حالت قبل از آخرین تغییر برگشت و دوباره خوانده و تأیید شد."

    # ------------------------------------------------------------ wallpaper
    @staticmethod
    def _wallpaper_now() -> str:
        import ctypes
        buf = ctypes.create_unicode_buffer(520)
        _spi(0x0073, 520, buf)                                     # SPI_GETDESKWALLPAPER
        return buf.value

    def _wp_snap(self) -> dict:
        return {"path": os.path.normcase(os.path.normpath(self._wallpaper_now())) if self._wallpaper_now() else "", "raw": self._wallpaper_now(),
                "style": str(_reg_get(_DESKTOP, "WallpaperStyle", "")), "tile": str(_reg_get(_DESKTOP, "TileWallpaper", ""))}

    def _wp_apply(self, snap: dict) -> None:
        if snap["style"] != "":
            _reg_set(_DESKTOP, "WallpaperStyle", snap["style"])
        if snap["tile"] != "":
            _reg_set(_DESKTOP, "TileWallpaper", snap["tile"])
        _spi(0x0014, 0, snap["raw"], 0x3)

    def wallpaper_get(self, a: dict) -> str:
        _need_win("خواندن والپیپر")
        s = self._wp_snap()
        name = next((k for k, v in _STYLES.items() if v == (s["style"], s["tile"])), "نامشخص")
        return f"والپیپر فعلی: {s['raw'] or 'تک‌رنگ/نامشخص'} (حالت نمایش: {name})."

    def wallpaper_set(self, a: dict) -> str:
        _need_win("تغییر والپیپر")
        if self.policy is None:
            raise ToolError("سیاست مسیر در دسترس نیست.")
        path = self.policy.check(a["path"])
        if os.path.splitext(path)[1].lower() not in _IMG_EXT or not os.path.isfile(path):
            raise ToolError("فقط فایل تصویر موجود (jpg، png یا bmp) در پوشه‌های مجاز می‌تواند والپیپر شود.", DENIED)
        style = str(a.get("style") or "").strip().lower()
        if style and style not in _STYLES:
            raise ToolError("حالت نمایش باید یکی از fill, fit, stretch, tile, center, span باشد.")

        def do():
            if style:
                _reg_set(_DESKTOP, "WallpaperStyle", _STYLES[style][0])
                _reg_set(_DESKTOP, "TileWallpaper", _STYLES[style][1])
            if not _spi(0x0014, 0, path, 0x3):                   # SPI_SETDESKWALLPAPER, UPDATEINIFILE | SENDCHANGE
                raise ToolError("ویندوز تغییر والپیپر را نپذیرفت.", kind="api_failure")
            time.sleep(0.4)
            now = self._wallpaper_now()
            if os.path.normcase(os.path.normpath(now)) != os.path.normcase(os.path.normpath(path)):
                raise ToolError(f"والپیپر بعد از دستور همان نشد که خواستی (ویندوز «{now}» را نشان می‌دهد).", kind="api_failure")
            return f"والپیپر عوض شد و دوباره از ویندوز خوانده شد: {now}" + (f" (حالت {style})." if style else ".")
        return self._txn("والپیپر", self._wp_snap, self._wp_apply, do)

    # ------------------------------------------------------------ theme
    @staticmethod
    def _theme_snap() -> dict:
        return {"apps": int(_reg_get(_PERSONALIZE, "AppsUseLightTheme", 1)), "system": int(_reg_get(_PERSONALIZE, "SystemUsesLightTheme", 1))}

    @staticmethod
    def _theme_apply(s: dict) -> None:
        _reg_set(_PERSONALIZE, "AppsUseLightTheme", int(s["apps"]))
        _reg_set(_PERSONALIZE, "SystemUsesLightTheme", int(s["system"]))
        _broadcast("ImmersiveColorSet")

    def theme_get(self, a: dict) -> str:
        _need_win("خواندن تم")
        t = self._theme_snap()
        f = lambda v: "light" if v else "dark"
        return f"تم برنامه‌ها: {f(t['apps'])}، تم سیستم (Taskbar/Start): {f(t['system'])}."

    def theme_set(self, a: dict) -> str:
        _need_win("تغییر تم")
        mode = str(a["mode"]).strip().lower()
        if mode not in ("light", "dark"):
            raise ToolError("mode باید light یا dark باشد.")
        scope = str(a.get("scope") or "both").strip().lower()
        if scope not in ("apps", "system", "both"):
            raise ToolError("scope باید apps، system یا both باشد.")
        v = 1 if mode == "light" else 0

        def do():
            new = self._theme_snap()
            if scope in ("apps", "both"):
                new["apps"] = v
            if scope in ("system", "both"):
                new["system"] = v
            self._theme_apply(new)
            time.sleep(0.3)
            if self._theme_snap() != new:
                raise ToolError("مقدار تم بعد از نوشتن همان نشد که خواستی.", kind="api_failure")
            return f"تم {mode} شد و دوباره خوانده شد. برنامه‌های باز ممکن است چند لحظه بعد یا بعد از باز شدن دوباره عوض شوند."
        return self._txn("تم", self._theme_snap, self._theme_apply, do)

    # ------------------------------------------------------------ taskbar (Kira NEVER restarts Explorer; see docs)
    @staticmethod
    def _taskbar_hwnd() -> int:
        import ctypes
        return int(ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None) or 0)

    def _appbar_state(self, new: int | None = None) -> int:
        import ctypes
        from ctypes import wintypes

        class APPBARDATA(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND), ("uCallbackMessage", wintypes.UINT), ("uEdge", wintypes.UINT),
                        ("rc", wintypes.RECT), ("lParam", wintypes.LPARAM)]
        d = APPBARDATA()
        d.cbSize = ctypes.sizeof(APPBARDATA)
        d.hWnd = self._taskbar_hwnd()
        fn = ctypes.windll.shell32.SHAppBarMessage
        fn.restype = ctypes.c_size_t
        if new is not None:
            d.lParam = new
            fn(10, ctypes.byref(d))                                # ABM_SETSTATE
        return int(fn(4, ctypes.byref(d)))                         # ABM_GETSTATE

    def _tb_snap(self) -> dict:
        return {"state": self._appbar_state(), "al": _reg_get(_ADVANCED, "TaskbarAl", None)}

    def _tb_apply(self, s: dict) -> None:
        self._appbar_state(int(s["state"]))
        if s["al"] is not None:
            _reg_set(_ADVANCED, "TaskbarAl", int(s["al"]))
            _broadcast("TraySettings")

    def taskbar_get(self, a: dict) -> str:
        _need_win("خواندن Taskbar")
        s = self._tb_snap()
        parts = [f"پنهان‌شدن خودکار: {'روشن' if s['state'] & 1 else 'خاموش'}"]
        if s["al"] is not None:
            parts.append(f"چینش آیکون‌ها (مقدار ثبت‌شده): {'وسط' if s['al'] else 'چپ'}")
        return "Taskbar — " + "، ".join(parts) + "."

    def taskbar_set(self, a: dict) -> str:
        _need_win("تغییر Taskbar")
        auto = a.get("autohide") not in (None, "")
        align = a.get("alignment") not in (None, "")
        if not (auto or align):
            raise ToolError("حداقل یکی از autohide یا alignment را بده.")
        if align:
            al = str(a["alignment"]).strip().lower()
            if al not in ("left", "center"):
                raise ToolError("alignment باید left یا center باشد.")
            if sys.getwindowsversion().build < 22000:
                raise ToolError("چینش آیکون‌های Taskbar فقط در ویندوز ۱۱ وجود دارد.", kind="missing_component")

        def do():
            done = []
            if auto:
                want = str(a["autohide"]).strip().lower() in ("1", "true", "yes", "on", "روشن")
                cur = self._appbar_state()
                self._appbar_state((cur | 1) if want else (cur & ~1))
                time.sleep(0.4)
                if bool(self._appbar_state() & 1) != want:
                    raise ToolError("وضعیت پنهان‌شدن خودکار Taskbar عوض نشد.", kind="api_failure")
                done.append("پنهان‌شدن خودکار " + ("روشن شد" if want else "خاموش شد") + " (بازخوانی‌شده)")
            if align:
                _reg_set(_ADVANCED, "TaskbarAl", 1 if al == "center" else 0)
                _broadcast("TraySettings")
                time.sleep(0.4)
                if _reg_get(_ADVANCED, "TaskbarAl", None) != (1 if al == "center" else 0):
                    raise ToolError("مقدار چینش Taskbar ثبت نشد.", kind="api_failure")
                done.append(f"چینش {al} در رجیستری ثبت و بازخوانی شد؛ اعمال دیداری آن روی Taskbar تأیید نشده (UNVERIFIED). "
                            "اگر عوض نشد، تا خروج و ورود دوباره‌ی کاربر یا ریستارت Explorer طول می‌کشد؛ Kira خودش Explorer را ریستارت نمی‌کند — فقط اگر کاربر خودش صریحاً بخواهد و تأیید کند")
            return "Taskbar: " + "؛ ".join(done) + "."
        return self._txn("Taskbar", self._tb_snap, self._tb_apply, do)

    # ------------------------------------------------------------ notifications (toast banners)
    @staticmethod
    def _notif_snap() -> dict:
        return {"toast": int(_reg_get(_PUSH, "ToastEnabled", 1))}

    @staticmethod
    def _notif_apply(s: dict) -> None:
        _reg_set(_PUSH, "ToastEnabled", int(s["toast"]))
        _broadcast("WindowsNotification")

    def notifications_get(self, a: dict) -> str:
        _need_win("خواندن اعلان‌ها")
        return f"نمایش بنر اعلان‌های ویندوز: {'روشن' if self._notif_snap()['toast'] else 'خاموش'}."

    def notifications_set(self, a: dict) -> str:
        _need_win("تغییر اعلان‌ها")
        want = 1 if str(a["enabled"]).strip().lower() in ("1", "true", "yes", "on", "روشن") else 0

        def do():
            self._notif_apply({"toast": want})
            if self._notif_snap()["toast"] != want:
                raise ToolError("تنظیم اعلان‌ها عوض نشد.", kind="api_failure")
            return (f"نمایش بنر اعلان‌ها {'روشن' if want else 'خاموش'} شد (مقدار رجیستری بازخوانی شد). این همان سوییچ کلی «Get notifications» است؛ "
                    "حالت Focus/Do Not Disturb را عوض نمی‌کند و روی برخی نسخه‌ها بعد از چند لحظه دیده می‌شود.")
        return self._txn("اعلان‌ها", self._notif_snap, self._notif_apply, do)

    # ------------------------------------------------------------ mouse / keyboard (user confirms the exact change first)
    @staticmethod
    def _mouse_snap() -> dict:
        import ctypes
        sp = ctypes.c_int(0)
        _spi(0x0070, 0, ctypes.byref(sp))                          # SPI_GETMOUSESPEED
        return {"speed": sp.value, "swap": bool(ctypes.windll.user32.GetSystemMetrics(23))}

    @staticmethod
    def _mouse_apply(s: dict) -> None:
        import ctypes
        _spi(0x0071, 0, ctypes.c_void_p(int(s["speed"])), 0x3)     # SPI_SETMOUSESPEED (value goes in pvParam)
        _spi(0x0021, 1 if s["swap"] else 0, None, 0x3)             # SPI_SETMOUSEBUTTONSWAP

    def mouse_get(self, a: dict) -> str:
        _need_win("خواندن ماوس")
        s = self._mouse_snap()
        return f"سرعت ماوس: {s['speed']} از ۲۰؛ دکمه‌ی اصلی: {'راست (جابه‌جاشده)' if s['swap'] else 'چپ'}."

    def confirm_mouse_set(self, a: dict) -> str:
        cur = self._mouse_snap() if IS_WIN else {"speed": "?", "swap": False}
        lines = []
        if a.get("speed") not in (None, ""):
            lines.append(f"سرعت ماوس از {cur['speed']} به {a['speed']} (از ۲۰)")
        if a.get("swap_buttons") not in (None, ""):
            lines.append(f"دکمه‌ی اصلی ماوس از {'راست' if cur['swap'] else 'چپ'} به {'راست' if str(a['swap_buttons']).lower() in ('1', 'true', 'yes', 'on', 'روشن') else 'چپ'}")
        return "تنظیمات ماوس عوض می‌شود: " + "؛ ".join(lines) + ". (ماوس بد تنظیم‌شده کار با سیستم را سخت می‌کند؛ با «برگردان» به حالت قبل برمی‌گردد.)"

    def mouse_set(self, a: dict) -> str:
        _need_win("تغییر ماوس")
        sp = _int_arg(a, "speed", 1, 20) if a.get("speed") not in (None, "") else None
        sw = (str(a["swap_buttons"]).strip().lower() in ("1", "true", "yes", "on", "روشن")) if a.get("swap_buttons") not in (None, "") else None
        if sp is None and sw is None:
            raise ToolError("حداقل یکی از speed (۱ تا ۲۰) یا swap_buttons را بده.")

        def do():
            new = self._mouse_snap()
            if sp is not None:
                new["speed"] = sp
            if sw is not None:
                new["swap"] = sw
            self._mouse_apply(new)
            time.sleep(0.2)
            got = self._mouse_snap()
            if got != new:
                raise ToolError(f"ماوس بعد از تغییر همان نشد که خواستی (الان: سرعت {got['speed']}، دکمه‌ی اصلی {'راست' if got['swap'] else 'چپ'}).", kind="api_failure")
            return f"ماوس: سرعت {got['speed']}، دکمه‌ی اصلی {'راست' if got['swap'] else 'چپ'} (بازخوانی‌شده)."
        return self._txn("ماوس", self._mouse_snap, self._mouse_apply, do)

    @staticmethod
    def _kb_snap() -> dict:
        import ctypes
        sp, dl = ctypes.c_uint(0), ctypes.c_uint(0)
        _spi(0x000A, 0, ctypes.byref(sp))                          # SPI_GETKEYBOARDSPEED
        _spi(0x0016, 0, ctypes.byref(dl))                          # SPI_GETKEYBOARDDELAY
        return {"speed": sp.value, "delay": dl.value}

    @staticmethod
    def _kb_apply(s: dict) -> None:
        _spi(0x000B, int(s["speed"]), None, 0x3)
        _spi(0x0017, int(s["delay"]), None, 0x3)

    def keyboard_get(self, a: dict) -> str:
        _need_win("خواندن کیبورد")
        s = self._kb_snap()
        return f"سرعت تکرار کلید: {s['speed']} از ۳۱؛ تأخیر شروع تکرار: {s['delay']} از ۳ (۰ کوتاه‌ترین)."

    def confirm_keyboard_set(self, a: dict) -> str:
        cur = self._kb_snap() if IS_WIN else {"speed": "?", "delay": "?"}
        lines = []
        if a.get("repeat_speed") not in (None, ""):
            lines.append(f"سرعت تکرار کلید از {cur['speed']} به {a['repeat_speed']} (از ۳۱)")
        if a.get("repeat_delay") not in (None, ""):
            lines.append(f"تأخیر تکرار از {cur['delay']} به {a['repeat_delay']} (از ۳)")
        return "تنظیمات کیبورد عوض می‌شود: " + "؛ ".join(lines) + ". (با «برگردان» به حالت قبل برمی‌گردد.)"

    def keyboard_set(self, a: dict) -> str:
        _need_win("تغییر کیبورد")
        sp = _int_arg(a, "repeat_speed", 0, 31) if a.get("repeat_speed") not in (None, "") else None
        dl = _int_arg(a, "repeat_delay", 0, 3) if a.get("repeat_delay") not in (None, "") else None
        if sp is None and dl is None:
            raise ToolError("حداقل یکی از repeat_speed (۰ تا ۳۱) یا repeat_delay (۰ تا ۳) را بده.")

        def do():
            new = self._kb_snap()
            if sp is not None:
                new["speed"] = sp
            if dl is not None:
                new["delay"] = dl
            self._kb_apply(new)
            got = self._kb_snap()
            if got != new:
                raise ToolError(f"کیبورد بعد از تغییر همان نشد که خواستی (الان: سرعت {got['speed']}، تأخیر {got['delay']}).", kind="api_failure")
            return f"کیبورد: سرعت تکرار {got['speed']}، تأخیر {got['delay']} (بازخوانی‌شده)."
        return self._txn("کیبورد", self._kb_snap, self._kb_apply, do)

    # ------------------------------------------------------------ power (plan, screen / sleep timeouts) - user confirms first
    @staticmethod
    def _pw_snap() -> dict:
        s = {"plan": _guid_of_active()}
        for key in ("screen_off", "sleep", "brightness"):
            grp, st, _ = _POWER[key]
            try:
                s[key] = _power_values(grp, st)
            except ToolError:
                s[key] = None                                      # not supported on this PC (e.g. brightness on a desktop)
        return s

    @staticmethod
    def _pw_apply(s: dict) -> None:
        _powercfg("/setactive", s["plan"])
        for key in ("screen_off", "sleep", "brightness"):
            if s.get(key) is None:
                continue
            grp, st, _ = _POWER[key]
            _powercfg("/setacvalueindex", "SCHEME_CURRENT", grp, st, str(s[key][0]))
            _powercfg("/setdcvalueindex", "SCHEME_CURRENT", grp, st, str(s[key][1]))
        _powercfg("/setactive", "SCHEME_CURRENT")

    def power_get(self, a: dict) -> str:
        _need_win("خواندن Power")
        out = _powercfg("/getactivescheme")
        m = re.search(r"\(([^)]+)\)\s*\*?\s*$", out.strip().splitlines()[-1]) if out.strip() else None
        lines = [f"Power plan فعال: {m.group(1) if m else out.strip()[:80]}"]
        s = self._pw_snap()
        f = lambda v: "هرگز" if v == 0 else f"{v // 60} دقیقه"
        for key in ("screen_off", "sleep"):
            label = _POWER[key][2]
            lines.append(f"{label}: " + (f"روی برق {f(s[key][0])}، روی باتری {f(s[key][1])}" if s[key] else "خوانده نشد"))
        return "؛ ".join(lines) + "."

    def confirm_power_set(self, a: dict) -> str:
        try:
            cur = self._pw_snap()
        except ToolError:
            cur = {}
        f = lambda v: "هرگز" if v == 0 else f"{v // 60} دقیقه"
        lines = []
        for key in ("screen_off", "sleep"):
            if a.get(key + "_minutes") not in (None, ""):
                old = f"{f(cur[key][0])} / {f(cur[key][1])}" if cur.get(key) else "نامعلوم"
                lines.append(f"{_POWER[key][2]}: از (برق/باتری) {old} به {f(int(a[key + '_minutes']) * 60)} برای هر دو")
        if a.get("plan"):
            lines.append(f"Power plan به «{a['plan']}»")
        return "تنظیمات Power عوض می‌شود: " + "؛ ".join(lines) + ". (فقط تنظیمات؛ سیستم Sleep یا خاموش نمی‌شود. با «برگردان» به حالت قبل برمی‌گردد.)"

    def power_set(self, a: dict) -> str:
        _need_win("تغییر Power")
        plan = str(a.get("plan") or "").strip().lower()
        if plan and plan not in _PLANS:
            raise ToolError("plan باید balanced، high_performance یا power_saver باشد.")
        mins = {k: _int_arg(a, k + "_minutes", 0, 1440) for k in ("screen_off", "sleep") if a.get(k + "_minutes") not in (None, "")}
        if not plan and not mins:
            raise ToolError("حداقل یکی از plan، screen_off_minutes یا sleep_minutes را بده (۰ یعنی هرگز).")

        def do():
            done = []
            for key, m in mins.items():                              # values first (in the CURRENT plan), the plan switch last: a rollback is then one plan only
                grp, st, label = _POWER[key]
                _powercfg("/setacvalueindex", "SCHEME_CURRENT", grp, st, str(m * 60))
                _powercfg("/setdcvalueindex", "SCHEME_CURRENT", grp, st, str(m * 60))
                _powercfg("/setactive", "SCHEME_CURRENT")
                got = _power_values(grp, st)
                if got != (m * 60, m * 60):
                    raise ToolError(f"{label} عوض نشد (بعد از بازخوانی: برق {got[0] // 60}، باتری {got[1] // 60} دقیقه).", kind="api_failure")
                done.append(f"{label} روی {'هرگز' if m == 0 else str(m) + ' دقیقه'} (برق و باتری، بازخوانی‌شده)")
            if plan:
                _powercfg("/setactive", _PLANS[plan])
                time.sleep(0.3)
                done.append(f"plan {plan} فعال شد (بازخوانی‌شده)")
            return "Power: " + "؛ ".join(done) + ". (Sleep/Restart/Shutdown خود سیستم در این ابزار نیست.)"
        return self._txn("Power", self._pw_snap, self._pw_apply, do)

    # ------------------------------------------------------------ LAPTOP internal screen brightness (through the Power plan; not a general monitor control)
    def laptop_brightness_get(self, a: dict) -> str:
        _need_win("خواندن روشنایی")
        if not _has_internal_battery():
            return ("روی این کامپیوتر باتری/صفحه‌ی داخلی دیده نمی‌شود (احتمالاً دسکتاپ با مانیتور خارجی)؛ این ابزار فقط برای صفحه‌ی داخلی لپ‌تاپ است و "
                    "روشنایی مانیتور خارجی را نمی‌خواند.")
        grp, st, _ = _POWER["brightness"]
        ac, dc = _power_values(grp, st)
        return (f"روشنایی صفحه‌ی داخلی در Power plan فعال: روی برق {ac}%، روی باتری {dc}%. (مقدار تنظیم plan است، نه خواندن مستقیم پنل؛ "
                "مانیتور خارجی و چند مانیتور پوشش داده نمی‌شوند.)")

    def laptop_brightness_set(self, a: dict) -> str:
        _need_win("تغییر روشنایی")
        v = _int_arg(a, "percent", 5, 100)
        if not _has_internal_battery():
            raise ToolError("باتری/صفحه‌ی داخلی دیده نشد؛ این ابزار فقط برای صفحه‌ی داخلی لپ‌تاپ است و روشنایی مانیتور خارجی را عوض نمی‌کند.", kind="unsupported_hardware")

        def do():
            grp, st, _ = _POWER["brightness"]
            _powercfg("/setacvalueindex", "SCHEME_CURRENT", grp, st, str(v))
            _powercfg("/setdcvalueindex", "SCHEME_CURRENT", grp, st, str(v))
            _powercfg("/setactive", "SCHEME_CURRENT")
            got = _power_values(grp, st)
            if got != (v, v):
                raise ToolError(f"روشنایی در plan عوض نشد (بازخوانی: برق {got[0]}%، باتری {got[1]}%).", kind="unsupported_hardware")
            return (f"روشنایی صفحه‌ی داخلی لپ‌تاپ در Power plan روی {v}% گذاشته و دوباره خوانده شد. تغییر واقعی نور پنل از اینجا قابل اندازه‌گیری نیست "
                    "(UNVERIFIED برای خود پنل)؛ مانیتور خارجی تحت تأثیر نیست.")
        return self._txn("روشنایی لپ‌تاپ", self._pw_snap, self._pw_apply, do)


# ------------------------------------------------------------------ declaration
def _rx(*words: str):
    return re.compile("|".join(words), re.I)


WALLPAPER_RX = _rx(r"والپیپر", r"وال\s*پیپر", r"wallpaper", r"پس\s*زمینه", r"background", r"عکس\s*دسکتاپ")
THEME_RX = _rx(r"\bتم\b", r"theme", r"dark", r"light\s*mode", r"تاریک", r"دارک", r"حالت\s*روشن", r"لایت", r"شب")
TASKBAR_RX = _rx(r"تسک\s*بار", r"نوار\s*وظیفه", r"taskbar", r"نوار\s*پایین")
NOTIF_RX = _rx(r"اعلان", r"نوتیف", r"notification", r"toast", r"بنر")
MOUSE_RX = _rx(r"ماوس", r"موس", r"mouse", r"pointer", r"اشاره\s*گر")
KEYBOARD_RX = _rx(r"کیبورد", r"صفحه\s*کلید", r"keyboard", r"تکرار\s*کلید", r"repeat")
POWER_RX = _rx(r"پاور", r"power", r"خواب", r"sleep", r"خاموش\s*شدن\s*(?:صفحه|نمایشگر|مانیتور)", r"screen\s*(?:off|timeout)", r"صفحه\s*(?:رو|را)?\s*خاموش", r"بالانس", r"balanced",
                 r"پرفورمنس", r"performance", r"صرفه\s*جویی", r"saver", r"باتری")
UNDO_RX = _rx(r"برگردان", r"برگرد", r"قبلی", r"قبل", r"لغو\s*(?:تغییر|کن)", r"\bundo\b", r"\brevert\b", r"\bback\b", r"اشتباه")
BRIGHT_RX = _rx(r"روشنایی", r"نور\s*(?:صفحه|مانیتور|نمایشگر)", r"brightness", r"کم\s*نور", r"پر\s*نور")


class SettingsModule(WinModule):
    domain = "settings"

    def __init__(self, policy: PathPolicy | None = None, access=None):
        self.t = SettingsTools(policy, access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("settings",)
        onoff = lambda n, d: Param(n, "string", d, False, None, ("true", "false"))

        def cap(name, desc, fn, risk, params, rx=None, memo=None, confirm=None):
            # confirm: permission stays CONTROL; `requires_confirmation` is a separate flag - the user approves the EXACT change first
            # (mouse / keyboard / power can make the PC hard to use if set badly). It does not make the tool PROTECTED and does not replace any other rule.
            kw = {"risk": risk, "requires_confirmation": True, "confirm_summary": confirm} if confirm else {"risk": risk}
            return Capability(name, "settings", desc, fn, params=params, categories=cat, intent_rx=rx, memo=memo, verifies_result=risk == ACTION,
                              changes_system=risk == ACTION, backend="powercfg" if name.startswith(("power_", "laptop_brightness")) else "win32", **kw)
        return [
            cap("wallpaper_get", "read the current Windows wallpaper path and fit mode (changes nothing)", t.wallpaper_get, READ, ()),
            cap("wallpaper_set", "set the wallpaper to an image file (jpg/png/bmp) inside an allowed folder; optional style fill|fit|stretch|tile|center|span; re-reads the real wallpaper. ONLY on explicit request",
                t.wallpaper_set, ACTION, (Param("path", "string", "full path of the image", True), Param("style", "string", "optional fit mode", False, None, tuple(_STYLES))), WALLPAPER_RX,
                lambda a, x: f"wallpaper_set → {os.path.basename(str(a.get('path')))}"),
            cap("theme_get", "read whether Windows apps / system use the light or dark theme (changes nothing)", t.theme_get, READ, ()),
            cap("theme_set", "switch Windows to light or dark theme (scope apps | system | both, default both); re-reads the value. ONLY on explicit request",
                t.theme_set, ACTION, (Param("mode", "string", "light | dark", True, None, ("light", "dark")), Param("scope", "string", "apps | system | both", False, None, ("apps", "system", "both"))), THEME_RX,
                lambda a, x: f"theme_set → {a.get('mode')}"),
            cap("taskbar_get", "read Taskbar auto-hide and icon alignment (changes nothing)", t.taskbar_get, READ, ()),
            cap("taskbar_set", "set Taskbar auto-hide (autohide true|false) and/or icon alignment (left|center, Windows 11 only); re-reads. ONLY on explicit request",
                t.taskbar_set, ACTION, (onoff("autohide", "true or false"), Param("alignment", "string", "left | center", False, None, ("left", "center"))), TASKBAR_RX,
                lambda a, x: "taskbar_set → " + str({k: v for k, v in a.items() if v})),
            cap("notifications_get", "read whether Windows notification banners are on (changes nothing)", t.notifications_get, READ, ()),
            cap("notifications_set", "turn Windows notification banners on or off (the global toast switch, not Focus assist); re-reads. ONLY on explicit request",
                t.notifications_set, ACTION, (Param("enabled", "string", "true | false", True, None, ("true", "false")),), NOTIF_RX, lambda a, x: f"notifications_set → {a.get('enabled')}"),
            cap("mouse_get", "read mouse pointer speed and primary button (changes nothing)", t.mouse_get, READ, ()),
            cap("mouse_set", "set mouse speed (1-20) and/or swap the primary button; re-reads. ONLY on explicit request (the user confirms the exact change first)",
                t.mouse_set, ACTION, (Param("speed", "integer", "1-20 (10 is Windows default)"), onoff("swap_buttons", "true = right button is primary")), MOUSE_RX,
                lambda a, x: "mouse_set → " + str({k: v for k, v in a.items() if v}), confirm=t.confirm_mouse_set),
            cap("keyboard_get", "read keyboard repeat speed and delay (changes nothing)", t.keyboard_get, READ, ()),
            cap("keyboard_set", "set keyboard repeat speed (0-31) and/or repeat delay (0-3); re-reads. ONLY on explicit request",
                t.keyboard_set, ACTION, (Param("repeat_speed", "integer", "0-31"), Param("repeat_delay", "integer", "0 (short) - 3 (long)")), KEYBOARD_RX,
                lambda a, x: "keyboard_set → " + str({k: v for k, v in a.items() if v}), confirm=t.confirm_keyboard_set),
            cap("power_get", "read the active Power plan and the screen-off / sleep timeouts (changes nothing)", t.power_get, READ, ()),
            cap("power_set", "set the Power plan (balanced | high_performance | power_saver) and/or screen-off / sleep timeout in minutes (0 = never); re-reads. Does NOT sleep, restart or shut down. ONLY on explicit request",
                t.power_set, ACTION, (Param("plan", "string", "balanced | high_performance | power_saver", False, None, tuple(_PLANS)), Param("screen_off_minutes", "integer", "0-1440, 0 = never"),
                                      Param("sleep_minutes", "integer", "0-1440, 0 = never")), POWER_RX, lambda a, x: "power_set → " + str({k: v for k, v in a.items() if v}), confirm=t.confirm_power_set),
            cap("laptop_brightness_get", "read the brightness of a LAPTOP's built-in screen as set in the active Power plan (not a general monitor control; external monitors are not covered; changes nothing)",
                t.laptop_brightness_get, READ, ()),
            cap("laptop_brightness_set", "set the brightness (5-100%) of a LAPTOP's built-in screen through the active Power plan. It does NOT control external monitors or other displays; refused on PCs without a battery. ONLY on explicit request",
                t.laptop_brightness_set, ACTION, (Param("percent", "integer", "5-100", True),), BRIGHT_RX, lambda a, x: f"laptop_brightness_set → {a.get('percent')}"),
            cap("settings_undo", "undo the LAST change made by a settings tool (wallpaper, theme, taskbar, notifications, mouse, keyboard, power, laptop brightness) and re-read the state. ONLY when the user asks to undo / go back (the user confirms first)",
                t.settings_undo, ACTION, (), UNDO_RX, lambda a, x: "settings_undo", confirm=t.confirm_undo),
        ]
