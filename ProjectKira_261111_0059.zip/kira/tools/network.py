"""T6 Phase 3 - network: IP / DNS / adapter information, Wi-Fi (saved profiles only), ping and a staged diagnosis. No PowerShell.

Sources: the adapter list comes from psutil when it is installed, the gateway / DNS / DHCP facts from the Windows registry (readable without Administrator),
Wi-Fi from netsh.exe with FIXED arguments, ping from ping.exe, reachability from plain sockets. Nothing here changes a Windows network setting except
`wifi_connect` / `wifi_disconnect`, which only use a Wi-Fi profile the user ALREADY saved: Kira never receives, stores or types a Wi-Fi password and never
creates a profile. Both are CONTROL + requires_confirmation (the user sees "from -> to" first), re-read the real connection state, and a failed `wifi_connect`
reconnects the previous network (rollback, journaled). A Windows that is not English prints netsh labels in another language: then the state cannot be
parsed and the answer says UNVERIFIED instead of guessing. Enabling / disabling an adapter stays in elevation.py (ELEVATED + UAC).
"""
from __future__ import annotations

import re
import socket
import threading
import time

from .registry import ToolError, Param, READ, ACTION
from .sysexe import run_exe, IS_WIN
from .wincontrol import Capability, WinModule

try:
    import winreg
except Exception:                                             # noqa: BLE001
    winreg = None

_NET_CLASS = r"SYSTEM\CurrentControlSet\Control\Network\{4D36E972-E325-11CE-BFC1-08002BE10318}"
_TCPIP = r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
_HOST_RX = re.compile(r"^(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?)(?:\.[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?)*$|^[0-9A-Fa-f:]{2,39}$")
_PROBES = (("1.1.1.1", 443), ("8.8.8.8", 53), ("9.9.9.9", 53))        # several, because one of them may be filtered on some networks
_DNS_NAMES = ("www.microsoft.com", "www.google.com", "www.cloudflare.com")


def _need_win(what: str) -> None:
    if not IS_WIN:
        raise ToolError(f"{what} فقط روی ویندوز ممکن است.", kind="missing_component")


def _reg(path: str, name: str, default=None):
    if winreg is None:
        return default
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return default


def _guid_by_name() -> dict:
    """{friendly adapter name (lower): '{GUID}'} from the registry connection list."""
    out = {}
    if winreg is None:
        return out
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, _NET_CLASS, 0, winreg.KEY_READ) as k:
            i = 0
            while True:
                try:
                    guid = winreg.EnumKey(k, i)
                except OSError:
                    break
                i += 1
                name = _reg(_NET_CLASS + "\\" + guid + "\\Connection", "Name")
                if name and guid.startswith("{"):
                    out[str(name).lower()] = guid
    except OSError:
        pass
    return out


def _as_list(v) -> list:
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if str(x).strip()]
    return [x for x in re.split(r"[,\s]+", str(v)) if x]


def _kind_of(name: str) -> str:
    return "Wi-Fi" if re.search(r"wi-?fi|wlan|wireless|بی‌?سیم", name, re.I) else "Ethernet/دیگر"


def _tcp_ok(host: str, port: int, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _resolve_ok(host: str, timeout: float = 5.0) -> bool:
    box = []

    def work():
        try:
            box.append(bool(socket.getaddrinfo(host, 443)))
        except OSError:
            box.append(False)
    t = threading.Thread(target=work, daemon=True)
    t.start()
    t.join(timeout)
    return bool(box and box[0])


def _kv(text: str, key: str) -> str:
    m = re.search(r"^\s*" + re.escape(key) + r"\s*:\s*(.+?)\s*$", text, re.M)
    return m.group(1) if m else ""


class NetworkTools:
    def __init__(self, access=None):
        self.access = access                                       # AccessManager: journals a rollback / sets UNVERIFIED (grants nothing)
        self._last_wifi = ""

    # ------------------------------------------------------------ adapters / IP / DNS
    def _adapters(self, show_all: bool) -> list:
        try:
            import psutil
        except Exception:                                          # noqa: BLE001 - psutil is optional
            psutil = None
        guids = _guid_by_name()
        stats = psutil.net_if_stats() if psutil else {}
        addrs = psutil.net_if_addrs() if psutil else {}
        names = list(addrs) if psutil else [n for n in guids]
        rows = []
        for name in names:
            if re.search(r"loopback|pseudo", name, re.I):
                continue
            st = stats.get(name)
            up = bool(st and st.isup) if st else None
            if not show_all and up is False:
                continue
            ip4, mask, mac = "", "", ""
            for a in addrs.get(name, []):
                if a.family == socket.AF_INET and not ip4:
                    ip4, mask = a.address, a.netmask or ""
                elif str(a.family).endswith("AF_LINK") or getattr(a.family, "name", "") == "AF_LINK" or a.family == -1:
                    mac = a.address
            guid = guids.get(name.lower(), "")
            base = _TCPIP + "\\" + guid if guid else ""
            dhcp = bool(_reg(base, "EnableDHCP", 0)) if base else None
            gw = _as_list(_reg(base, "DhcpDefaultGateway" if dhcp else "DefaultGateway")) if base else []
            static_dns = _as_list(_reg(base, "NameServer")) if base else []
            dns = static_dns or (_as_list(_reg(base, "DhcpNameServer")) if base else [])
            rows.append({"name": name, "kind": _kind_of(name), "up": up, "speed": getattr(st, "speed", 0) if st else 0, "ip4": ip4, "mask": mask, "mac": mac,
                         "dhcp": dhcp, "gateway": gw, "dns": dns, "dns_static": bool(static_dns)})
        return rows

    def network_status(self, a: dict) -> str:
        _need_win("خواندن وضعیت شبکه")
        rows = self._adapters(str(a.get("show_all", "")).lower() in ("1", "true", "yes"))
        if not rows:
            return "آداپتور شبکه‌ی فعالی پیدا نشد (کابل/Wi-Fi وصل نیست یا آداپتور غیرفعال است)."
        lines = []
        for r in rows:
            state = "نامعلوم" if r["up"] is None else "وصل" if r["up"] else "قطع"
            parts = [f"{r['name']} ({r['kind']}): {state}"]
            if r["ip4"]:
                parts.append(f"IPv4 {r['ip4']}" + (f"/{r['mask']}" if r["mask"] else "") + (" (APIPA؛ آدرس معتبر از DHCP نگرفته)" if r["ip4"].startswith("169.254.") else ""))
            if r["gateway"]:
                parts.append("Gateway " + "، ".join(r["gateway"]))
            if r["dns"]:
                parts.append("DNS " + "، ".join(r["dns"]) + (" (دستی)" if r["dns_static"] else " (از DHCP)"))
            if r["dhcp"] is not None:
                parts.append("DHCP " + ("روشن" if r["dhcp"] else "خاموش/IP ثابت"))
            if r["speed"]:
                parts.append(f"سرعت لینک {r['speed']} Mbps")
            if r["mac"]:
                parts.append("MAC " + r["mac"])
            lines.append(" · ".join(parts))
        note = "" if _guid_by_name() else " (جزئیات Gateway/DNS از رجیستری خوانده نشد.)"
        return "آداپتورها:\n" + "\n".join(lines) + note

    # ------------------------------------------------------------ ping / diagnosis
    def network_ping(self, a: dict) -> str:
        _need_win("ping")
        host = str(a["host"]).strip()
        if not _HOST_RX.match(host) or len(host) > 253 or host.startswith("-"):
            raise ToolError("آدرس برای ping معتبر نیست (فقط نام دامنه یا IP).", kind="bad_args")
        try:
            n = max(1, min(8, int(a.get("count") or 4)))
        except (TypeError, ValueError):
            n = 4
        rc, out = run_exe("ping", ["-n", str(n), "-w", "2000", host], timeout=n * 3 + 6)
        got = len(re.findall(r"TTL\s*=", out, re.I))
        times = [int(x) for x in re.findall(r"(?:time|زمان|Zeit|temps)\s*[=<]\s*(\d+)\s*ms", out, re.I)]
        if got == 0:
            return (f"از «{host}» هیچ پاسخی نیامد ({n} بسته). دلیل قطعی نیست: می‌تواند قطع بودن شبکه، نام نادرست، یا مسدود بودن ICMP روی مقصد باشد. "
                    "با network_diagnose می‌توان لایه‌ها را جدا بررسی کرد.")
        avg = f"، میانگین {sum(times) // len(times)}ms" if times else ""
        return f"ping «{host}»: {got} از {n} پاسخ ({100 * (n - got) // n}% گم‌شده){avg}."

    def network_diagnose(self, a: dict) -> str:
        _need_win("عیب‌یابی شبکه")
        steps, verdict = [], ""
        rows = [r for r in self._adapters(False) if r["up"] is not False and r["ip4"]]
        usable = [r for r in rows if not r["ip4"].startswith("169.254.")]
        if not rows:
            steps.append("۱) آداپتور: هیچ آداپتور وصل با IPv4 دیده نشد ✗")
            verdict = "به‌احتمال زیاد کابل/Wi-Fi وصل نیست یا آداپتور غیرفعال است."
        elif not usable:
            steps.append("۱) آداپتور: فقط آدرس APIPA (169.254.x.x) دارد ✗")
            verdict = "آداپتور وصل است ولی آدرس معتبر از DHCP (مودم/روتر) نگرفته؛ احتمالاً مشکل بین PC و مودم/روتر."
        else:
            r = usable[0]
            steps.append(f"۱) آداپتور: «{r['name']}» با IPv4 {r['ip4']} ✓")
            gw = next(iter(r["gateway"]), "")
            gw_ok = None
            if gw and _HOST_RX.match(gw):
                _, out = run_exe("ping", ["-n", "2", "-w", "1500", gw], timeout=12)
                gw_ok = bool(re.search(r"TTL\s*=", out, re.I))
                steps.append(f"۲) Gateway {gw}: " + ("پاسخ داد ✓" if gw_ok else "پاسخ نداد ✗ (ممکن است ICMP را نپذیرد)"))
            else:
                steps.append("۲) Gateway: ثبت نشده / خوانده نشد")
            tcp = [f"{h}:{p}" for h, p in _PROBES if _tcp_ok(h, p)]
            steps.append("۳) اتصال مستقیم به IP اینترنت: " + ("باز ✓ (" + "، ".join(tcp) + ")" if tcp else "هیچ‌کدام از " + "، ".join(f"{h}:{p}" for h, p in _PROBES) + " باز نشد ✗"))
            dns_ok = [h for h in _DNS_NAMES if _resolve_ok(h)]
            steps.append("۴) DNS: " + ("نام‌ها resolve شد ✓" if dns_ok else "هیچ نامی resolve نشد ✗"))
            if tcp and dns_ok:
                verdict = "اتصال سالم به نظر می‌رسد. اگر یک سایت یا برنامه‌ی خاص کار نمی‌کند، مشکل از همان سرویس یا فیلترینگ است نه کل شبکه."
            elif tcp and not dns_ok:
                verdict = "اینترنت با IP کار می‌کند ولی DNS جواب نمی‌دهد؛ به‌احتمال زیاد مشکل DNS (می‌شود DNS را عوض کرد یا کش را پاک کرد؛ هر دو نیاز به تأیید/Administrator دارند)."
            elif gw_ok is False:
                verdict = "به Gateway هم نمی‌رسد؛ احتمالاً مشکل PC ↔ مودم/روتر (کابل، Wi-Fi، یا خود مودم)."
            else:
                verdict = "به Gateway می‌رسد ولی به اینترنت نه؛ احتمالاً مشکل از مودم/ISP یا فیلتر روی این پورت‌ها (قطعی نیست)."
        return "\n".join(steps) + "\nنتیجه (احتمال، نه قطعی): " + verdict

    # ------------------------------------------------------------ Wi-Fi (saved profiles only)
    def _wlan(self, *args: str, timeout: int = 15) -> tuple:
        return run_exe("netsh", ["wlan", *args], timeout=timeout)

    def _wifi_state(self):
        """{'state','ssid','profile','signal'} of the first Wi-Fi interface, or None when the text cannot be parsed (not English / no adapter)."""
        rc, out = self._wlan("show", "interfaces")
        if rc != 0 and not re.search(r"^\s*State\s*:", out, re.M):
            return None
        state = _kv(out, "State")
        if not state:
            return None
        return {"state": state.lower(), "ssid": _kv(out, "SSID"), "profile": _kv(out, "Profile"), "signal": _kv(out, "Signal")}

    def wifi_status(self, a: dict) -> str:
        _need_win("خواندن Wi-Fi")
        rc, out = self._wlan("show", "interfaces")
        s = self._wifi_state()
        if s is None:
            if re.search(r"wlansvc|not running|no wireless|There is no wireless", out, re.I):
                raise ToolError("آداپتور Wi-Fi یا سرویس WLAN AutoConfig در این PC فعال نیست.", kind="missing_component")
            return "وضعیت Wi-Fi خوانده نشد: خروجی netsh قابل‌تحلیل نبود (احتمالاً ویندوز غیرانگلیسی یا بدون Wi-Fi). UNVERIFIED."
        if s["state"] != "connected":
            return f"Wi-Fi به شبکه‌ای وصل نیست (وضعیت: {s['state']})."
        return f"Wi-Fi وصل است: SSID «{s['ssid']}»" + (f"، پروفایل «{s['profile']}»" if s["profile"] and s["profile"] != s["ssid"] else "") + (f"، قدرت سیگنال {s['signal']}" if s["signal"] else "") + "."

    def _profiles(self) -> list:
        rc, out = self._wlan("show", "profiles")
        names = [m.group(1).strip() for m in re.finditer(r"^\s*(?:All User Profile|User Profile)\s*:\s*(.+?)\s*$", out, re.M)]
        if not names and rc != 0:
            raise ToolError("فهرست پروفایل‌های Wi-Fi خوانده نشد (آداپتور Wi-Fi یا سرویس WLAN در دسترس نیست).", kind="missing_component")
        return names

    def wifi_profiles(self, a: dict) -> str:
        _need_win("خواندن پروفایل‌های Wi-Fi")
        names = self._profiles()
        if not names:
            return "پروفایل ذخیره‌شده‌ای پیدا نشد (یا خروجی netsh قابل‌تحلیل نبود؛ ویندوز غیرانگلیسی؟). رمز هیچ شبکه‌ای خوانده نمی‌شود."
        return "شبکه‌های Wi-Fi ذخیره‌شده (فقط نام؛ رمزها خوانده نمی‌شوند): " + "، ".join(names[:40])

    def wifi_scan(self, a: dict) -> str:
        _need_win("جست‌وجوی Wi-Fi")
        rc, out = self._wlan("show", "networks", timeout=20)
        blocks = re.split(r"^\s*SSID\s+\d+\s*:\s*", out, flags=re.M)[1:]
        if not blocks:
            return "شبکه‌ای در دسترس دیده نشد یا خروجی netsh قابل‌تحلیل نبود (Wi-Fi خاموش؟ ویندوز غیرانگلیسی؟). UNVERIFIED."
        rows = []
        for b in blocks[:25]:
            name = b.splitlines()[0].strip() or "(پنهان)"
            sig = re.search(r"Signal\s*:\s*(\d+)%", b)
            auth = _kv(b, "Authentication")
            rows.append(f"{name}" + (f" — سیگنال {sig.group(1)}%" if sig else "") + (f" — {auth}" if auth else ""))
        return "شبکه‌های Wi-Fi دیده‌شده:\n" + "\n".join(rows)

    def _match_profile(self, wanted: str) -> str:
        wanted = str(wanted).strip()
        for p in self._profiles():
            if p.lower() == wanted.lower():
                return p
        raise ToolError(f"«{wanted}» جزو پروفایل‌های ذخیره‌شده‌ی Wi-Fi نیست. Kira رمز نمی‌گیرد و پروفایل نمی‌سازد؛ اول باید یک بار خود کاربر در ویندوز به آن وصل شده باشد. "
                        "با wifi_profiles نام‌های ذخیره‌شده را ببین.", kind="bad_args")

    def _wait(self, pred, seconds: float):
        end = time.monotonic() + seconds
        s = None
        while time.monotonic() < end:
            s = self._wifi_state()
            if s is not None and pred(s):
                return True, s
            time.sleep(1.0)
        return False, s

    def _event(self, tool: str, ok: bool, text: str) -> None:
        if self.access is not None:
            try:
                self.access.record_event(tool, "network", "CONTROL", "ok" if ok else "error", "system-exe", text, "verified" if ok else "unknown", "" if ok else "api_failure")
            except Exception:                                      # noqa: BLE001
                pass

    def confirm_wifi_connect(self, a: dict) -> str:
        cur = ""
        try:
            s = self._wifi_state() if IS_WIN else None
            cur = f"الان: «{s['ssid']}»" if s and s["state"] == "connected" else "الان به Wi-Fi وصل نیست" if s else "وضعیت فعلی خوانده نشد"
        except ToolError:
            cur = "وضعیت فعلی خوانده نشد"
        return (f"اتصال Wi-Fi به شبکه‌ی ذخیره‌شده‌ی «{a.get('profile')}» ({cur}). اتصال فعلی ممکن است قطع شود (و ارتباط Kira با مدل‌های ابری موقتاً بریده شود). "
                "اگر وصل نشد، Kira دوباره به شبکه‌ی قبلی برمی‌گردد.")

    def wifi_connect(self, a: dict) -> str:
        _need_win("اتصال Wi-Fi")
        target = self._match_profile(a["profile"])
        before_state = self._wifi_state()
        before = (before_state["profile"] or before_state["ssid"]) if before_state and before_state["state"] == "connected" else ""
        if before and before.lower() == target.lower():
            return f"همین حالا به «{target}» وصل است؛ چیزی تغییر نکرد."
        rc, out = self._wlan("connect", f"name={target}", timeout=20)
        match = lambda s: s["state"] == "connected" and target.lower() in (s["profile"].lower(), s["ssid"].lower())
        if before_state is None:                                    # cannot read the state at all: never claim success
            if self.access is not None:
                self.access.set_verification("unverified")
            return f"دستور اتصال به «{target}» فرستاده شد (netsh کد {rc}) ولی وضعیت واقعی Wi-Fi قابل خواندن نیست، پس موفقیت تأیید نشد (UNVERIFIED)."
        ok, s = self._wait(match, 15)
        if ok:
            net = "اینترنت: " + ("در دسترس" if any(_tcp_ok(h, p, 2.5) for h, p in _PROBES) else "از این PC دیده نشد (ممکن است هنوز آماده نشده یا فیلتر باشد)")
            self._last_wifi = before
            return f"به «{target}» وصل شد (وضعیت واقعی بازخوانی شد). {net}."
        tail = ""
        if before:
            self._wlan("connect", f"name={before}", timeout=20)
            back, _ = self._wait(lambda x: x["state"] == "connected" and before.lower() in (x["profile"].lower(), x["ssid"].lower()), 15)
            self._event("wifi.rollback", back, f"بازگشت به «{before}» " + ("تأیید شد" if back else "تأیید نشد (UNKNOWN)"))
            tail = (f" به شبکه‌ی قبلی «{before}» برگشتم و بازخوانی تأیید شد." if back else
                    f" تلاش برای برگشت به «{before}» هم تأیید نشد؛ وضعیت واقعی Wi-Fi نامشخص است (UNKNOWN).")
        raise ToolError(f"اتصال به «{target}» تأیید نشد (وضعیت: {(s or {}).get('state', 'نامعلوم')}؛ رمز تغییر‌کرده، سیگنال ضعیف یا شبکه در دسترس نیست).{tail}", kind="api_failure")

    def confirm_wifi_disconnect(self, a: dict) -> str:
        return ("قطع اتصال Wi-Fi فعلی. بعد از آن اینترنتِ همین PC (و ارتباط Kira با مدل‌های ابری) قطع می‌شود مگر کابل Ethernet وصل باشد. "
                "با wifi_connect می‌شود دوباره وصل شد.")

    def wifi_disconnect(self, a: dict) -> str:
        _need_win("قطع Wi-Fi")
        before = self._wifi_state()
        if before is not None and before["state"] != "connected":
            return "Wi-Fi از قبل به شبکه‌ای وصل نبود؛ چیزی تغییر نکرد."
        name = (before["profile"] or before["ssid"]) if before else ""
        rc, out = self._wlan("disconnect", timeout=15)
        if before is None:
            if self.access is not None:
                self.access.set_verification("unverified")
            return f"دستور قطع Wi-Fi فرستاده شد (netsh کد {rc}) ولی وضعیت واقعی قابل خواندن نیست؛ UNVERIFIED."
        ok, s = self._wait(lambda x: x["state"] != "connected", 10)
        if not ok:
            raise ToolError("دستور قطع داده شد ولی Wi-Fi هنوز وصل نشان می‌دهد؛ وضعیت را تغییر‌یافته فرض نکن.", kind="api_failure")
        self._last_wifi = name
        return f"Wi-Fi از «{name}» قطع شد (بازخوانی شد). برای وصل دوباره: wifi_connect با همین نام."


_RX = lambda *w: re.compile("|".join(w), re.I)
WIFI_RX = _RX(r"وای\s*فای", r"wi-?fi", r"شبکه\s*بی\s*سیم", r"وصل", r"قطع", r"connect", r"disconnect", r"شبکه", r"اینترنت")


class NetworkModule(WinModule):
    domain = "network"

    def __init__(self, access=None):
        self.t = NetworkTools(access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("network",)

        def cap(name, desc, fn, risk, params=(), rx=None, memo=None, confirm=None):
            kw = {"risk": risk, "requires_confirmation": True, "confirm_summary": confirm} if confirm else {"risk": risk}
            return Capability(name, "network", desc, fn, params=params, categories=cat, intent_rx=rx, memo=memo, verifies_result=risk == ACTION,
                              changes_system=risk == ACTION, backend="system-exe", **kw)
        return [
            cap("network_status", "show network adapters: up/down, IPv4, gateway, DNS (static or DHCP), DHCP, link speed (changes nothing); show_all=true also lists disconnected adapters",
                t.network_status, READ, (Param("show_all", "string", "true to include disconnected adapters", False, None, ("true", "false")),)),
            cap("network_ping", "ping a host name or IP (1-8 packets) and report replies / loss. A probe only; changes nothing", t.network_ping, READ,
                (Param("host", "string", "domain name or IP address", True), Param("count", "integer", "1-8, default 4"))),
            cap("network_diagnose", "staged network diagnosis: adapter/IP, gateway, direct internet, DNS - then a probable (never certain) cause. Changes nothing", t.network_diagnose, READ),
            cap("wifi_status", "show the current Wi-Fi connection (SSID, signal). Changes nothing", t.wifi_status, READ),
            cap("wifi_profiles", "list the Wi-Fi networks already saved in Windows (names only; passwords are never read)", t.wifi_profiles, READ),
            cap("wifi_scan", "list Wi-Fi networks visible right now with signal and security type. Changes nothing", t.wifi_scan, READ),
            cap("wifi_connect", "connect Wi-Fi to a network ALREADY saved in Windows (profile from wifi_profiles). Never creates a profile, never takes a password. The user confirms first; "
                "the real state is re-read and the previous network is restored if it fails. ONLY on explicit request",
                t.wifi_connect, ACTION, (Param("profile", "string", "saved Wi-Fi profile name exactly as wifi_profiles shows it", True),), WIFI_RX,
                lambda a, x: f"wifi_connect → {a.get('profile')}", confirm=t.confirm_wifi_connect),
            cap("wifi_disconnect", "disconnect the current Wi-Fi network (cuts this PC's internet unless Ethernet is plugged in). The user confirms first. ONLY on explicit request",
                t.wifi_disconnect, ACTION, (), WIFI_RX, lambda a, x: "wifi_disconnect", confirm=t.confirm_wifi_disconnect),
        ]
