"""T6 - image generation tools (domain `images`): `image_providers` (READ) and `image_generate` (CONTROL, explicit request only; one image, or a short looping GIF when frames >= 2).

The work is done by kira/imagegen.py on top of the API Manager: any registered API that can make images is used, in the order of the user's API priority, with failover.
Safety: the prompt leaves the PC to a third-party service, so it must not contain a secret (netguard.contains_secret) and is limited in length; the tool runs only when
the user's CURRENT message asks for an image (intent_rx) and, like every CONTROL tool, needs the user's confirmation in a turn that read external content. The image is
validated (real PNG / JPEG / WebP) and saved as a NEW file (never overwriting) in the Pictures folder, sub-folder "Kira Images" (an allowed folder, so open_path / file tools can reach it); if that is
not possible it goes to Kira's own data folder and the answer says so. Nothing is opened automatically.
"""
from __future__ import annotations

import os
import re
import secrets
import time
from pathlib import Path

from .. import imagegen
from ..webintel import netguard
from .access import PathPolicy, _known_folder, _KNOWN_FOLDERS
from .registry import ToolError, Param, READ, ACTION, DENIED, ERROR
from .wincontrol import Capability, WinModule

MAX_PROMPT = 1500
IMAGE_RX = re.compile(
    r"عکس|تصویر|نقاشی|بکش|لوگو|پوستر|ایلاستریشن|ایمیج|طراحی\s*کن|"
    r"گیف|جیف|متحرک|انیمیشن|\b(?:draw|paint|illustrate|image|picture|photo|logo|poster|artwork|gifs?|animat(?:e|ed|ion))\b|generate\s+(?:an?\s+)?(?:image|picture|photo|logo)", re.I)
GIF_DEFAULT_FRAMES = 4
GIF_BUDGET = 480.0                      # seconds for ALL frames of one GIF (each frame is one provider request with its own timeout)
_KIND_MAP = {"auth": "permission_denied", "quota": "api_failure", "model": "missing_component", "content": "api_failure", "network": "api_failure",
             "timeout": "timeout", "server": "api_failure", "response": "api_failure", "unsupported": "missing_component", "config": "missing_component"}


_SAVED_RX = re.compile(r"VERIFIED:[^)\n]*\)\s*:\s*(.+?)\s*(?:\n|$)")


def saved_path(text: str) -> str:
    """The file path inside a VERIFIED image_generate / GIF result ('' when the text holds none)."""
    m = _SAVED_RX.search(str(text or ""))
    return m.group(1).strip() if m else ""


class ImageTools:
    def __init__(self, policy: PathPolicy, access=None):
        self.policy = policy
        self.access = access

    def _settings(self) -> dict:
        return self.policy.settings if isinstance(self.policy.settings, dict) else {}

    def _folder(self) -> tuple[str, bool]:
        """-> (folder, reachable by file tools). Pictures\\Kira Images when that is an allowed folder, otherwise Kira's own data folder."""
        pics = _known_folder(_KNOWN_FOLDERS["Pictures"]) or str(Path.home() / "Pictures")
        for folder, reachable in ((os.path.join(pics, "Kira Images"), True),
                                  (os.path.join(str(self.policy.data_dir or Path.home() / ".kira"), "generated_images"), False)):
            try:
                if reachable and not self.policy.is_allowed(pics):
                    continue
                os.makedirs(folder, exist_ok=True)
                return folder, reachable
            except OSError:
                continue
        raise ToolError("پوشه‌ای برای ذخیره‌ی تصویر ساخته نشد.", ERROR, "permission_denied")

    def image_providers(self, a: dict) -> str:
        cands, notes = imagegen.list_candidates(self._settings())
        lines = []
        if cands:
            lines.append("APIهای ثبت‌شده‌ای که الان می‌توانند تصویر بسازند (به ترتیب اولویت):")
            for c in cands:
                lines.append(f"- {c.label} — مدل {c.model}")
        else:
            lines.append("هیچ API ثبت‌شده‌ای الان مدل تولید تصویر ندارد.")
        lines += [f"✗ {n}" for n in notes]
        lines.append("نکته: وجود مدل در فهرست یعنی سرویس آن را گزارش کرده؛ دسترسی/سهمیه‌ی واقعی (مثلاً پلن پولی Imagen) هنگام ساخت مشخص می‌شود.")
        return "\n".join(lines)

    def image_generate(self, a: dict) -> str:
        try:
            frames = int(a.get("frames") or 1)
        except (TypeError, ValueError):
            frames = 1
        if frames >= 2:
            return self._generate_gif(a)                       # an animated GIF is a few generated frames + assembly (below)
        prompt = " ".join(str(a.get("prompt") or "").split())
        if not prompt:
            raise ToolError("توضیح تصویر (prompt) خالی است.", "bad_args")
        if len(prompt) > MAX_PROMPT:
            raise ToolError(f"توضیح تصویر بیش از {MAX_PROMPT} نویسه است؛ کوتاه‌ترش کن.", "bad_args")
        if netguard.contains_secret(prompt, self._settings()):
            raise ToolError("توضیح تصویر شبیه کلید/رمز است و به سرویس بیرونی فرستاده نمی‌شود.", DENIED, "permission_denied")
        aspect = a.get("aspect", "square")
        try:
            raw, ext, cand, failures = imagegen.generate(self._settings(), prompt, aspect, only=str(a.get("provider") or ""))
        except imagegen.ImageError as exc:
            raise ToolError(str(exc), DENIED if exc.kind == "auth" else ERROR, _KIND_MAP.get(exc.kind, "api_failure")) from exc
        folder, reachable = self._folder()
        path = os.path.join(folder, f"kira_image_{time.strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(2)}.{ext}")
        try:
            with open(path, "xb") as f:                                           # "x": never overwrite
                f.write(raw)
        except OSError as exc:
            raise ToolError(f"تصویر ساخته شد ولی ذخیره‌اش ممکن نشد: {exc}", ERROR, "permission_denied") from exc
        if not os.path.isfile(path) or os.path.getsize(path) != len(raw):
            raise ToolError("تصویر ذخیره شد ولی بررسی فایل نهایی تأیید نشد (UNVERIFIED).", ERROR, "api_failure")
        text = (f"تصویر ساخته و ذخیره شد (VERIFIED: فایل معتبر {ext.upper()}، {len(raw) // 1024} KB): {path}\n"
                f"ساخته‌شده با {cand.label} / {cand.model}. "
                + ("برای نمایش به کاربر می‌توانی open_path را با همین مسیر بزنی (فقط اگر خواست)." if reachable else "این مسیر داخل پوشه‌ی داده‌ی خود Kira است و ابزارهای فایل به آن دسترسی ندارند؛ آدرسش را به کاربر بگو."))
        if aspect != "square" and cand.service == "cloudflare":
            text += " (Cloudflare اندازه‌ی تصویر را از این ابزار نمی‌گیرد؛ نسبت ممکن است مربعی باشد.)"
        if failures:
            text += f" [{len(failures)} تلاش قبلی روی APIهای دیگر ناموفق بود.]"
        return text

    @staticmethod
    def _frame_prompt(prompt: str, motion: str, i: int, n: int) -> str:
        """Each frame is an independent still: the wording asks for the same scene with only the motion changing (consistency is up to the model)."""
        pct = round(100 * (i - 1) / max(1, n - 1))
        return (f"{prompt}\n\nThis image is frame {i} of {n} of a short looping animated GIF, drawn as separate stills. "
                f"Motion across the frames: {motion or 'subtle, natural movement of the main subject'}. This frame shows the moment at {pct}% of the motion. "
                "Keep exactly the same subject, art style, colors, framing, camera angle and background in every frame; change only what moves.")

    def _generate_gif(self, a: dict) -> str:
        prompt = " ".join(str(a.get("prompt") or "").split())
        motion = " ".join(str(a.get("motion") or "").split())
        if not prompt:
            raise ToolError("توضیح صحنه (prompt) خالی است.", "bad_args")
        if len(prompt) > MAX_PROMPT or len(motion) > 400:
            raise ToolError(f"توضیح صحنه بیش از {MAX_PROMPT} نویسه (یا توضیح حرکت بیش از ۴۰۰ نویسه) است؛ کوتاه‌ترش کن.", "bad_args")
        for text in (prompt, motion):
            if text and netguard.contains_secret(text, self._settings()):
                raise ToolError("توضیح شبیه کلید/رمز است و به سرویس بیرونی فرستاده نمی‌شود.", DENIED, "permission_denied")
        if not imagegen.gif_available():
            raise ToolError("برای ساخت GIF بسته‌ی Pillow لازم است و نصب نیست. «python -m pip install Pillow» را اجرا کن (یا install.bat را دوباره بزن). هیچ درخواستی به API فرستاده نشد.",
                            ERROR, "missing_component")
        try:
            n = int(a.get("frames") or GIF_DEFAULT_FRAMES)
        except (TypeError, ValueError):
            n = GIF_DEFAULT_FRAMES
        n = max(imagegen.GIF_MIN_FRAMES, min(imagegen.GIF_MAX_FRAMES, n))
        duration = max(imagegen.GIF_MIN_MS, min(imagegen.GIF_MAX_MS, int(a.get("duration_ms") or 250)))
        ping_pong = a.get("ping_pong", True) is not False
        aspect = a.get("aspect", "square")
        only = str(a.get("provider") or "")
        raws, cand, failures, stopped = [], None, [], ""
        started = time.monotonic()
        for i in range(1, n + 1):
            if time.monotonic() - started > GIF_BUDGET:
                stopped = "مهلت کل ساخت GIF تمام شد."
                break
            try:
                raw, ext, c, fails = imagegen.generate(self._settings(), self._frame_prompt(prompt, motion, i, n), aspect, only=(cand.pid if cand else only))
            except imagegen.ImageError as exc:
                if not raws:
                    raise ToolError(str(exc), DENIED if exc.kind == "auth" else ERROR, _KIND_MAP.get(exc.kind, "api_failure")) from exc
                stopped = f"فریم {i} ساخته نشد: {exc}"
                break
            cand = cand or c                                  # every frame comes from the SAME API, so the look stays as consistent as possible
            failures += fails
            raws.append(raw)
        if len(raws) < imagegen.GIF_MIN_FRAMES:
            raise ToolError("برای GIF حداقل دو فریم لازم است و فقط " + str(len(raws)) + " فریم ساخته شد. " + stopped, ERROR, "api_failure")
        try:
            data, info = imagegen.build_gif(raws, duration, ping_pong)
        except imagegen.ImageError as exc:
            raise ToolError(str(exc), ERROR, _KIND_MAP.get(exc.kind, "api_failure")) from exc
        folder, reachable = self._folder()
        path = os.path.join(folder, f"kira_gif_{time.strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(2)}.gif")
        try:
            with open(path, "xb") as f:                       # "x": never overwrite
                f.write(data)
        except OSError as exc:
            raise ToolError(f"GIF ساخته شد ولی ذخیره‌اش ممکن نشد: {exc}", ERROR, "permission_denied") from exc
        if not os.path.isfile(path) or os.path.getsize(path) != len(data):
            raise ToolError("GIF ذخیره شد ولی بررسی فایل نهایی تأیید نشد (UNVERIFIED).", ERROR, "api_failure")
        w, h = info["size"]
        text = (f"GIF ساخته و ذخیره شد (VERIFIED: GIF معتبر، {info['frames']} فریم در حلقه، {w}×{h}، {info['bytes'] // 1024} KB، هر فریم {info['duration_ms']} میلی‌ثانیه): {path}\n"
                f"فریم‌ها جدا و با {cand.label} / {cand.model} ساخته شدند ({len(raws)} درخواست)؛ هماهنگی بین فریم‌ها تضمین‌شده نیست. "
                + ("برای نمایش به کاربر می‌توانی open_path را با همین مسیر بزنی (فقط اگر خواست)." if reachable else "این مسیر داخل پوشه‌ی داده‌ی خود Kira است و ابزارهای فایل به آن دسترسی ندارند؛ آدرسش را به کاربر بگو."))
        if stopped:
            text += f" ⚠️ {len(raws)} از {n} فریم ساخته شد و GIF با همان‌ها ساخته شد ({stopped})"
        if info["frames"] != info["source_frames"]:
            text += f" (حالت رفت‌وبرگشت: {info['source_frames']} فریم اصلی)"
        if failures:
            text += f" [{len(failures)} تلاش قبلی روی APIهای دیگر ناموفق بود.]"
        return text


class ImageModule(WinModule):
    domain = "images"

    def __init__(self, policy: PathPolicy, access=None):
        self.t = ImageTools(policy, access)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("images",)
        return [
            Capability("image_providers", "images", "list which registered APIs (Google AI Studio, Cloudflare, a custom OpenAI-compatible API) can generate images and which cannot. Changes nothing",
                       t.image_providers, risk=READ, categories=cat, backend="network"),
            Capability("image_generate", "images", "generate ONE image (or, with frames 2-8, ONE short looping animated GIF) from a text description with the user's own registered APIs (first one that works) and save it as a file in Pictures\\Kira Images. "
                       "ONLY when the user's message asks for an image. The prompt is sent to the provider: never put secrets or private data in it",
                       t.image_generate, risk=ACTION,
                       params=(Param("prompt", "string", "detailed description of the image (any language; max 1500 characters)", True),
                               Param("aspect", "string", "square | landscape | portrait", False, "square", imagegen.ASPECTS),
                               Param("provider", "string", "optional: API name from image_providers; default = first one that works"),
                               Param("frames", "integer", "1 = one image (default). 2-8 = a short looping animated GIF: that many frames are generated (ONE provider request each, so it uses quota) and assembled; use ONLY when the user asks for a GIF / animation", False, 1),
                               Param("motion", "string", "GIF only: what moves across the frames, e.g. 'the cat blinks and wags its tail' (max 400 characters)"),
                               Param("duration_ms", "integer", "GIF only: milliseconds per frame 60-2000, default 250", False, 250),
                               Param("ping_pong", "boolean", "GIF only: play forward then backward for a smooth loop, default true", False, True)),
                       categories=cat, backend="network", intent_rx=IMAGE_RX, memo=lambda a, x: "image_generate", verifies_result=True, changes_system=True),
        ]
