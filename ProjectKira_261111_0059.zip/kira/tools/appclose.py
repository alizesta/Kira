"""close_app - close an app BY NAME the way the user would (the X button), and report what REALLY happened. Plus the open / close guard.

close_app (ACTION, CONTROL level; the user's CURRENT message must ask to close - enforced by the access manager through CLOSE_RX)
  Sends WM_CLOSE (SendMessageTimeout, so a hung window can not freeze Kira) to every real top-level window of the app, then LOOKS again:
    closed         no window and no process of the app is left                        -> normal success text
    partial        the window closed but the app still runs (System Tray / background) -> PARTIAL text, journaled as unverified
    nothing closed it showed a dialog ("save?"), minimized itself, ignored the message, is not responding, or runs elevated -> ToolError with the reason
  Force close is NOT done here: process_kill (existing tool, user confirms first) is the only way.

What belongs to the app is decided strictly: an EXACT process name (or exact executable path), never "the name contains ...", never "same folder"
(closing Steam does not touch a game; closing Notepad does not touch Notepad++). Kira itself, the console it runs in (and its parent programs), the
Windows shell and system processes are never closed. PowerShell / CMD are matched by WINDOW only; a PowerShell tab inside Windows Terminal is not
closed (that would close every tab): Kira reports it so the model can ask ONE question.

The guard (used by open_app): a message that asks to CLOSE and does not ask to open can never end in open_app, and when the user named one of the
known programs (PowerShell, Windows Terminal, CMD, Steam, Wallpaper Engine, Notepad, Calculator ...) open_app refuses to start a DIFFERENT known one.
Nothing here is tested on a real Windows PC (static checks only).
"""
from __future__ import annotations

import os
import re
import sys
import time

from . import appcatalog, sysinfo
from .registry import ToolError, Param, ACTION, DENIED, ERROR
from .wincontrol import Capability, WinModule

IS_WIN = sys.platform == "win32"
WM_CLOSE = 0x0010
SMTO_ABORTIFHUNG = 0x0002
WAIT_CLOSE = 6.0
_FRAME = "applicationframehost"
PROTECTED_STEMS = {"explorer", "winlogon", "csrss", "wininit", "services", "lsass", "smss", "dwm", "svchost", "system", "registry", "fontdrvhost", "sihost",
                   "taskhostw", "ctfmon", "python", "pythonw", "py", "kira"}
_CONSOLE_HOSTS = {"conhost", "openconsole"}
_TERMINAL = {"windowsterminal", "wt"}

_NORM = str.maketrans({"ي": "ی", "ك": "ک", "‌": " ", "‏": " ", "ـ": ""})
CLOSE_RX = re.compile(r"(?<![\u0600-\u06ffa-z0-9])(?:ببند|بستن|کلوز|بسته\s*کن|close|quit|exit|kill|shut\s*down|terminate)(?:ش|شو|ید|ین|ی)?(?![\u0600-\u06ffa-z0-9])", re.I)
_OPEN_RX = re.compile(r"(?<![\u0600-\u06ffa-z0-9])(?:باز\s*کن|بازش\s*کن|بازکن|اجرا\s*کن|اجراش\s*کن|ران\s*کن|بیار|بیاور|open|launch|start)(?:ش|شو|ید|ین|ی)?(?![\u0600-\u06ffa-z0-9])", re.I)

# id -> (label, spoken / written names, EXACT process names, console program?)
KNOWN = {
    "powershell": ("Windows PowerShell", ("windows powershell", "powershell", "power shell", "پاورشل", "پاور شل", "ویندوز پاورشل", "پاورشل ویندوز"), {"powershell"}, True),
    "terminal": ("Windows Terminal", ("windows terminal", "terminal", "wt", "ترمینال", "ترمینال ویندوز", "ویندوز ترمینال"), {"windowsterminal", "wt"}, False),
    "cmd": ("Command Prompt (CMD)", ("cmd", "command prompt", "کامند پرامپت", "سی ام دی", "خط فرمان"), {"cmd"}, True),
    "notepad": ("Notepad", ("notepad", "نوت پد", "نوتپد", "نوتپاد", "ویرایشگر متن"), {"notepad"}, False),
    "calculator": ("Calculator", ("calculator", "calc", "ماشین حساب", "کلکولاتور"), {"calculatorapp", "calculator", "win32calc", "calc"}, False),
    "steam": ("Steam", ("steam", "استیم"), {"steam", "steamwebhelper"}, False),
    "wallpaperengine": ("Wallpaper Engine", ("wallpaper engine", "wallpaperengine", "wallpaper", "والپیپر انجین", "وال پیپر انجین", "والپیپر", "وال پیپر"),
                        {"wallpaper32", "wallpaper64", "ui32", "ui64", "webwallpaper32", "webwallpaper64"}, False),
}
_TITLE_WORDS = {"powershell": ("powershell",), "cmd": ("command prompt", "cmd.exe")}


def squash(text: str) -> str:
    return re.sub(r"[^0-9a-z\u0600-\u06ff]+", "", str(text or "").lower().translate(_NORM))


_LOOKUP = {}
for _id, (_label, _names, _stems, _console) in KNOWN.items():
    for _n in (_id, _label) + tuple(_names):
        _LOOKUP[squash(_n)] = _id


def known_id(name: str) -> str | None:
    """The id of the known program a name is exactly ('Windows PowerShell' -> 'powershell'); None for anything else (also 'PowerShell 7')."""
    return _LOOKUP.get(squash(name))


def mentioned_ids(text: str) -> set:
    """Known programs named in a message (1-3 word phrases, with the Persian suffixes '-رو' / '-ش' tolerated)."""
    tokens = re.sub(r"[^\w\u0600-\u06ff]+", " ", str(text or "").lower().translate(_NORM)).split()
    found, i = set(), 0
    while i < len(tokens):
        hit = None
        for n in (3, 2, 1):
            phrase = "".join(tokens[i:i + n])
            if i + n <= len(tokens):
                for cand in (phrase, re.sub(r"(?:رو|را|شو|ش)$", "", phrase)):
                    if cand and squash(cand) in _LOOKUP:
                        hit = (_LOOKUP[squash(cand)], n)
                        break
            if hit:
                break
        if hit:
            found.add(hit[0])
            i += hit[1]
        else:
            i += 1
    return found


def asks_close_not_open(text: str) -> bool:
    t = str(text or "").lower().translate(_NORM)
    return bool(CLOSE_RX.search(t)) and not _OPEN_RX.search(t)


def open_guard(user_text: str, name: str) -> str:
    """'' = open_app may go on; otherwise the REAL reason it must not run (shown to the model)."""
    if not user_text:
        return ""
    if asks_close_not_open(user_text):
        return f"کاربر در همین پیام «بستن» برنامه را خواسته، نه باز کردن؛ پس «{name}» باز نشد و چیزی تغییر نکرد. برای بستن از close_app استفاده کن."
    wanted = mentioned_ids(user_text)
    got = known_id(name)
    if wanted and got and got not in wanted:
        return (f"کاربر درباره‌ی «{' ، '.join(KNOWN[i][0] for i in sorted(wanted))}» حرف زده ولی «{KNOWN[got][0]}» خواسته شد؛ این‌ها یک برنامه نیستند، پس چیزی باز نشد. "
                "اگر درخواست مبهم است فقط یک سؤال مشخص بپرس و برنامه‌ی دیگری را به‌جای آن باز نکن.")
    return ""


# ------------------------------------------------------------------------------------------------ what must never be closed
def _protected_pids() -> set:
    pids = {os.getpid()}
    try:
        import psutil
        pids |= {p.pid for p in psutil.Process().parents()}
        return pids
    except Exception:                                              # noqa: BLE001
        pass
    if not IS_WIN:
        return pids
    try:                                                           # no psutil: walk the parent chain with a Toolhelp snapshot
        import ctypes
        from ctypes import wintypes

        class PE(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
                        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

        k32 = ctypes.windll.kernel32
        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        snap = k32.CreateToolhelp32Snapshot(0x2, 0)
        parent, e = {}, PE()
        e.dwSize = ctypes.sizeof(PE)
        ok = k32.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            parent[int(e.th32ProcessID)] = int(e.th32ParentProcessID)
            ok = k32.Process32NextW(snap, ctypes.byref(e))
        k32.CloseHandle(snap)
        cur = os.getpid()
        for _ in range(12):
            cur = parent.get(cur, 0)
            if not cur or cur in pids:
                break
            pids.add(cur)
    except Exception:                                              # noqa: BLE001
        pass
    return pids


def _own_console() -> int:
    try:
        import ctypes
        return int(ctypes.windll.kernel32.GetConsoleWindow() or 0)
    except Exception:                                              # noqa: BLE001
        return 0


def _stem(name) -> str:
    return os.path.splitext(str(name or "").lower())[0].replace(" ", "")


# ------------------------------------------------------------------------------------------------ the target
class _Target:
    def __init__(self, label: str, key: str = "", stems=(), exes=(), console: bool = False, frame_titles=()):
        self.label, self.key, self.console = label, key, console
        self.stems = {s for s in stems if s}
        self.exes = {os.path.normcase(os.path.normpath(e)) for e in exes if e}
        self.frame_titles = tuple(frame_titles)

    def owns(self, p: dict) -> bool:
        path = os.path.normcase(os.path.normpath(p["exe"])) if p.get("exe") else ""
        return _stem(p.get("name")) in self.stems or (bool(path) and path in self.exes)


def _build_target(name: str):
    """-> (_Target, None) | (None, [options]) when the name is ambiguous. Raises ToolError when no such app is known."""
    from . import apps                                              # late import: apps.py imports this module for the guard
    kid = known_id(name)
    if kid:
        label, _names, stems, console = KNOWN[kid]
        frames = tuple(n.lower() for n in _names if len(n) > 4) if kid == "calculator" else ()
        return _Target(label, kid, stems, (), console, frames), None
    kind, val = apps.resolve_app(name)
    if kind == "ambiguous":
        return None, list(val)
    if kind == "builtin":
        label, how, target, aliases = apps.BUILTIN_APPS[val]
        return _Target(label, val, {_stem(target)}), None
    if kind == "app":
        ident = apps._identity(val)
        return _Target(val.name, "", ident.stems, ident.exes), None
    close = f" شاید منظور این‌ها باشد: {' ، '.join(val)}" if val else ""
    raise ToolError(f"برنامه‌ای به نام «{name}» پیدا نشد که بتوان بست.{close} چیزی بسته نشد و برنامه‌ی دیگری هم به‌جای آن بسته یا باز نشد.", ERROR, "app_not_installed")


def _windows(t: _Target, protected: set, own_console: int) -> list:
    import ctypes
    user32 = ctypes.windll.user32
    out = []
    for w in sysinfo.visible_windows():
        if w["pid"] in protected or w["hwnd"] == own_console:
            continue
        proc, title = _stem(w.get("process")), (w.get("title") or "").lower()
        mine = proc in t.stems
        if not mine and t.console and proc in _CONSOLE_HOSTS and any(x in title for x in _TITLE_WORDS.get(t.key, ())):
            mine = True
        if not mine and proc == _FRAME and t.frame_titles and any(x in title for x in t.frame_titles):
            mine = True
        if mine:
            out.append({**w, "iconic": bool(user32.IsIconic(w["hwnd"]))})
    return out


def _terminal_hosted(t: _Target, protected: set, own_console: int) -> list:
    words = _TITLE_WORDS.get(t.key, ())
    return [w for w in sysinfo.visible_windows() if w["pid"] not in protected and w["hwnd"] != own_console and _stem(w.get("process")) in _TERMINAL
            and any(x in (w.get("title") or "").lower() for x in words)]


def _processes(t: _Target, protected: set) -> list:
    if t.console:
        return []                                                  # powershell.exe / cmd.exe also run scripts and tabs of other programs: only WINDOWS count
    return [p for p in appcatalog.running_processes() if p.get("pid") and p["pid"] not in protected and _stem(p.get("name")) not in PROTECTED_STEMS and t.owns(p)]


def _titles(ws: list, n: int = 3) -> str:
    return " ، ".join(f"«{w['title'][:40]}»" for w in ws[:n]) + (f" و {len(ws) - n} پنجره‌ی دیگر" if len(ws) > n else "")


def _names(procs: list) -> str:
    names = sorted({p.get("name") for p in procs if p.get("name")})
    return f"{len(procs)} پردازش ({', '.join(names[:4])})" if procs else "بدون پردازش"


def _pid_hint(procs: list, n: int = 4) -> str:
    """'pid 123 «x.exe»' pairs, so a follow-up process_kill can use the EXACT pid + name without a second lookup. Valid only right now: never stored."""
    rows = [f"pid {p['pid']} «{p['name']}»" for p in procs[:n] if p.get("pid") and p.get("name")]
    return (" پردازش‌های فعلی (فقط برای همین لحظه معتبر، ذخیره نکن): " + " ، ".join(rows) + ".") if rows else ""


def _send_close(wins: list):
    """WM_CLOSE to every window (what the X button does). -> (reached, [titles Windows refused: access denied], [titles not responding])."""
    import ctypes
    from ctypes import wintypes
    user32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    user32.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM, wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
    user32.SendMessageTimeoutW.restype = ctypes.c_size_t
    sent, denied, hung = 0, [], []
    for w in wins:
        result = ctypes.c_size_t(0)
        k32.SetLastError(0)
        if user32.SendMessageTimeoutW(w["hwnd"], WM_CLOSE, 0, 0, SMTO_ABORTIFHUNG, 2500, ctypes.byref(result)):
            sent += 1
        elif k32.GetLastError() == 5:
            denied.append(w["title"])
        else:
            hung.append(w["title"])
    return sent, denied, hung


# ------------------------------------------------------------------------------------------------ the tool
class CloseTools:
    def __init__(self, access=None):
        self.access = access

    def _unverified(self) -> None:
        if self.access is not None:
            self.access.set_verification("unverified")

    def close_app(self, a: dict) -> str:
        name = str(a["name"]).strip()
        if not IS_WIN:
            raise ToolError("بستن برنامه فقط روی ویندوز ممکن است.")
        t, options = _build_target(name)
        if t is None:
            return (f"نام «{name}» مبهم است و چیزی بسته نشد. گزینه‌ها: " + " ، ".join(options) + ". فقط یک سؤال مشخص از کاربر بپرس (کدام یک؟)؛ جوابش به همین درخواست «بستن» وصل است. چیز دیگری را نبند و باز نکن.")
        if t.stems & PROTECTED_STEMS or t.key in PROTECTED_STEMS:
            raise ToolError(f"«{t.label}» بخشی از خود ویندوز یا Kira است و Kira آن را نمی‌بندد.", DENIED)
        protected, own = _protected_pids(), _own_console()
        wins, procs = _windows(t, protected, own), _processes(t, protected)
        if t.console and not wins:
            hosted = _terminal_hosted(t, protected, own)
            if hosted:
                self._unverified()
                return (f"چیزی بسته نشد: «{t.label}» داخل یک پنجره‌ی Windows Terminal باز است («{hosted[0]['title'][:50]}») و بستن آن پنجره همه‌ی تب‌های ترمینال را می‌بندد. "
                        "فقط یک سؤال بپرس: «کل Windows Terminal با همه‌ی تب‌هایش بسته شود؟» و فقط اگر صریح گفت بله، close_app را با نام «Windows Terminal» صدا بزن.")
        if not wins and not procs:
            return f"«{t.label}» الان اجرا نیست (نه پنجره‌ای دارد و نه پردازشی)؛ چیزی برای بستن نبود. وضعیت واقعی: بسته."
        if not wins:
            raise ToolError(f"«{t.label}» پنجره‌ی بازی ندارد که بسته شود؛ فقط در System Tray/پس‌زمینه اجراست ({_names(procs)}) و بستن عادی چیزی را عوض نمی‌کند. "
                            "بستن از منوی System Tray (Exit) با ابزار فعلی ممکن نیست. اگر کاربر می‌خواهد کاملاً بسته شود (End Task)، process_kill را با pid + name دقیق صدا بزن (کاربر تأیید می‌کند؛ کار ذخیره‌نشده از بین می‌رود)." + _pid_hint(procs))
        sent, denied, hung = _send_close(wins)
        deadline = time.monotonic() + WAIT_CLOSE
        now_wins, now_procs = wins, procs
        while time.monotonic() < deadline:
            time.sleep(0.35)
            now_wins, now_procs = _windows(t, protected, own), _processes(t, protected)
            if not now_wins and (not now_procs or t.console):
                break
        before_ids = {w["hwnd"] for w in wins}
        left = [w for w in now_wins if w["hwnd"] in before_ids]
        dialogs = [w for w in now_wins if w["hwnd"] not in before_ids]
        if not now_wins and not now_procs:
            return f"«{t.label}» بسته شد و دوباره بررسی شد: هیچ پنجره یا پردازشی از آن نمانده (WM_CLOSE به {sent} پنجره رسید)."
        if not left and not dialogs:
            if t.console:
                return f"پنجره‌ی «{t.label}» بسته شد و دوباره بررسی شد."
            self._unverified()
            return (f"ناقص (PARTIAL): پنجره‌ی «{t.label}» بسته شد ولی خود برنامه هنوز در System Tray/پس‌زمینه اجراست ({_names(now_procs)}). برنامه کاملاً بسته نشد؛ "
                    "این رفتار عادی بسیاری از برنامه‌هاست. این را صادقانه به کاربر بگو و فقط اگر خودش خواست، process_kill را (با تأیید) پیشنهاد بده.")
        reasons = []
        if denied:
            reasons.append("ویندوز اجازه‌ی بستن را نداد (احتمالاً برنامه با دسترسی Administrator اجراست): " + " ، ".join(f"«{x[:30]}»" for x in denied[:3]))
        if hung:
            reasons.append("برنامه پاسخ نداد (Not Responding): " + " ، ".join(f"«{x[:30]}»" for x in hung[:3]))
        if dialogs:
            reasons.append("برنامه پنجره/پیام تازه‌ای باز کرد که منتظر کاربر است (مثلاً ذخیره‌ی تغییرات): " + _titles(dialogs))
        was_min = {w["hwnd"] for w in wins if w["iconic"]}
        newly_min = [w for w in left if w["iconic"] and w["hwnd"] not in was_min]
        if newly_min:
            reasons.append("برنامه به‌جای بسته شدن Minimize شد: " + _titles(newly_min))
        if not reasons:
            reasons.append("برنامه پیام بستن را گرفت ولی پنجره‌اش را نبست (ممکن است بستن را نادیده بگیرد)")
        if len(wins) - len(left) > 0:
            self._unverified()
            return (f"ناقص (PARTIAL): {len(wins) - len(left)} از {len(wins)} پنجره‌ی «{t.label}» بسته شد و {len(left)} پنجره هنوز باز است. علت: " + " | ".join(reasons)
                    + ". همین را صادقانه بگو؛ بستن اجباری فقط با process_kill و تأیید خود کاربر.")
        raise ToolError(f"«{t.label}» بسته نشد (دوباره بررسی شد: {len(left)} پنجره هنوز باز است). علت: " + " | ".join(reasons)
                        + ". همین را صادقانه بگو؛ بستن اجباری فقط با process_kill و تأیید خود کاربر.", ERROR, "permission_denied" if denied else "")


class AppCloseModule(WinModule):
    domain = "apps"

    def __init__(self, access=None):
        self.t = CloseTools(access)

    def capabilities(self) -> list[Capability]:
        return [
            Capability("close_app", "apps", "close an app by name the way the X button does (Steam, Notepad, Wallpaper Engine, Windows PowerShell, CMD, Windows Terminal, any installed app), then re-check the real state: "
                       "closed / still running in the tray / not closed (dialog, minimized, ignored, elevated). ONLY when the user explicitly asks to close it. Never use open_app for a close request",
                       self.t.close_app, ACTION, (Param("name", "string", "app name as the user said it", True),), ("apps",), intent_rx=CLOSE_RX,
                       memo=lambda a, t: f"close_app → {a.get('name')}", verifies_result=True, changes_system=True),
        ]
