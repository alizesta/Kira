"""File insight (T6 Phase 1): large files, duplicate files, folder usage. READ only: nothing is changed or deleted here.

Everything goes through PathPolicy (allowed folders only; Kira's own data, AppData, the Windows folder and anything that looks like a secret are skipped).
Links / junctions are not followed. A time and file-count budget keeps a huge folder from freezing the chat; when a budget is hit the answer says the
scan was PARTIAL instead of presenting an incomplete list as complete. Deleting what is found is a separate, confirmed step (delete_file / batch_files).
"""
from __future__ import annotations

import hashlib
import os
import time

from .access import PathPolicy
from .registry import ToolError, Param, READ
from .wincontrol import Capability, WinModule

MAX_FILES = 60000
BUDGET_S = 25.0
HEAD = 65536


def _size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n} B"


class FileInsightTools:
    def __init__(self, policy: PathPolicy):
        self.policy = policy

    def _walk(self, folder: str, deadline: float):
        """Yield (path, size) of readable, non-sensitive files. Sets self._partial when a budget stops the walk."""
        self._partial, self._count = False, 0
        root = self.policy.check(folder)
        if not os.path.isdir(root):
            raise ToolError("باید یک پوشه‌ی موجود باشد.")
        for cur, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if not self.policy.sensitive_name(d) and d.lower() not in {"appdata", "$recycle.bin", "system volume information", ".git", "node_modules"}
                       and not os.path.islink(os.path.join(cur, d))]
            for n in names:
                if time.time() > deadline or self._count >= MAX_FILES:
                    self._partial = True
                    return
                full = os.path.join(cur, n)
                try:
                    if os.path.islink(full) or self.policy.sensitive_name(n):
                        continue
                    st = os.stat(full)
                except OSError:
                    continue
                self._count += 1
                yield full, st.st_size

    def _tail(self) -> str:
        return (f"\n[اسکن ناقص (UNVERIFIED کامل‌بودن): به سقف زمان/تعداد ({self._count} فایل) رسید؛ پوشه‌ی کوچک‌تری بده تا کامل بررسی شود.]" if self._partial
                else f"\n[اسکن کامل شد: {self._count} فایل بررسی شد.]")

    def find_large_files(self, a: dict) -> str:
        min_mb = max(1, int(a.get("min_mb", 100)))
        limit = max(1, min(int(a.get("max_results", 15)), 40))
        found = [(sz, p) for p, sz in self._walk(a["folder"], time.time() + BUDGET_S) if sz >= min_mb * 1048576]
        found.sort(reverse=True)
        if not found:
            return f"فایلی بزرگ‌تر از {min_mb} MB در این پوشه پیدا نشد." + self._tail()
        lines = [f"فایل‌های بزرگ‌تر از {min_mb} MB ({len(found)} مورد، نمایش {min(limit, len(found))}):"]
        lines += [f"{i}. {p} — {_size(sz)}" for i, (sz, p) in enumerate(found[:limit], 1)]
        return "\n".join(lines) + self._tail()

    def find_duplicate_files(self, a: dict) -> str:
        min_kb = max(1, int(a.get("min_kb", 64)))
        limit = max(1, min(int(a.get("max_groups", 10)), 25))
        deadline = time.time() + BUDGET_S
        by_size: dict[int, list[str]] = {}
        for p, sz in self._walk(a["folder"], deadline):
            if sz >= min_kb * 1024:
                by_size.setdefault(sz, []).append(p)
        partial = self._partial
        groups: dict[str, list[str]] = {}
        for sz, paths in by_size.items():
            if len(paths) < 2:
                continue
            heads: dict[str, list[str]] = {}
            for p in paths:
                if time.time() > deadline:
                    partial = True
                    break
                try:
                    with open(p, "rb") as f:
                        heads.setdefault(hashlib.blake2b(f.read(HEAD), digest_size=16).hexdigest(), []).append(p)
                except OSError:
                    continue
            for same in heads.values():
                if len(same) < 2:
                    continue
                for p in same:
                    if time.time() > deadline:
                        partial = True
                        break
                    try:
                        h = hashlib.sha256()
                        with open(p, "rb") as f:
                            for chunk in iter(lambda: f.read(1 << 20), b""):
                                h.update(chunk)
                        groups.setdefault(f"{sz}:{h.hexdigest()}", []).append(p)
                    except OSError:
                        continue
        dups = sorted(((int(k.split(":")[0]), v) for k, v in groups.items() if len(v) > 1), key=lambda kv: kv[0] * (len(kv[1]) - 1), reverse=True)
        tail = (f"\n[اسکن ناقص (UNVERIFIED کامل‌بودن): به سقف زمان/تعداد رسید؛ ممکن است تکراری‌های بیشتری باشد.]" if partial
                else f"\n[اسکن کامل شد: {self._count} فایل بررسی شد؛ تکراری = محتوای کاملاً یکسان (SHA-256).]")
        if not dups:
            return f"فایل تکراری (بزرگ‌تر از {min_kb} KB) پیدا نشد." + tail
        waste = sum(sz * (len(v) - 1) for sz, v in dups)
        lines = [f"{len(dups)} گروه فایل تکراری؛ فضای قابل‌آزادشدن حدود {_size(waste)} (نمایش {min(limit, len(dups))} گروه). هیچ‌چیز حذف نشد:"]
        for i, (sz, v) in enumerate(dups[:limit], 1):
            lines.append(f"{i}. {_size(sz)} × {len(v)}: " + " | ".join(v[:4]) + (" ..." if len(v) > 4 else ""))
        return "\n".join(lines) + tail

    def folder_usage(self, a: dict) -> str:
        root = self.policy.check(a["folder"])
        deadline = time.time() + BUDGET_S
        total, per = 0, {}
        for p, sz in self._walk(root, deadline):
            total += sz
            rel = os.path.relpath(p, root).split(os.sep)
            top = rel[0] if len(rel) > 1 else "(فایل‌های همین پوشه)"
            per[top] = per.get(top, 0) + sz
        lines = [f"مصرف فضای «{root}»: {_size(total)}" + (" (ناقص)" if self._partial else "")]
        for name, sz in sorted(per.items(), key=lambda kv: kv[1], reverse=True)[:12]:
            lines.append(f"- {name} — {_size(sz)}")
        return "\n".join(lines) + self._tail()


class FileInsightModule(WinModule):
    domain = "files"

    def __init__(self, policy: PathPolicy):
        self.t = FileInsightTools(policy)

    def capabilities(self) -> list[Capability]:
        t, cat = self.t, ("files",)
        folder = Param("folder", "string", "full path of an allowed folder", True)
        return [
            Capability("find_large_files", "files", "find the biggest files in an allowed folder (min_mb default 100). Read only", t.find_large_files, READ,
                       (folder, Param("min_mb", "integer", "minimum size in MB", False, 100), Param("max_results", "integer", "default 15, max 40", False, 15)), cat),
            Capability("find_duplicate_files", "files", "find files with identical content in an allowed folder (reports only, deletes nothing)", t.find_duplicate_files, READ,
                       (folder, Param("min_kb", "integer", "ignore files smaller than this (default 64)", False, 64), Param("max_groups", "integer", "default 10, max 25", False, 10)), cat),
            Capability("folder_usage", "files", "how much disk space a folder uses, split by its top-level items. Read only", t.folder_usage, READ, (folder,), cat),
        ]
