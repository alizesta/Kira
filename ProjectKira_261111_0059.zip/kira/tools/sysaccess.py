"""Unified System Access Manager (T5-Core): the ONE place that decides what Kira may do on this PC, whether the user must confirm it, which
backend runs it, and what really happened.

Every tool - Windows control (apps / Bluetooth / audio / desktop), file agent, web, MCP, agents - passes through ToolRegistry.execute(), and
execute() asks this manager. No module has (or may create) a permission system of its own; a module only DECLARES its operation (permission
level, explicit-request gate, backend) and the manager enforces it. Nothing here knows about a Provider or a model.

Permission levels
  PERMISSION (what kind of operation) and CONFIRMATION (does the user have to approve it) are TWO SEPARATE things since T6 Phase 2 review:
  `requires_confirmation` is an independent flag; ELEVATED always carries it, any other level may. A confirmation can NEVER replace the level's own rule.

  READ       reads / looks up information. Runs when the user asks.
  CONTROL    ordinary, reversible control of apps and Windows (volume, window state, open an app, Bluetooth, typing into a window ...).
             No repeated confirmation; sensitive ones carry an explicit-request gate (the user's CURRENT message must ask for it).
  FILE       ordinary file / folder management that is reversible or non-destructive (create, copy, rename, append). Same gates as CONTROL
             and always inside PathPolicy (allowed folders, never secrets).
  ELEVATED   needs Administrator rights. ALWAYS confirmed, and the elevation (UAC) is requested only for that one operation, never kept.
             Execution goes ONLY through kira/tools/elevation.py (T6): a fixed, allow-listed operation is started by Windows UAC after the exact-operation
             confirmation; Kira itself never runs as Administrator. See docs/SYSTEM_ACCESS_FA.md.
  PROTECTED  never on the model's / an agent's own initiative: it is offered for confirmation (and runs) ONLY when the user's CURRENT message directly and explicitly asks for
             exactly this (`intent_rx` is mandatory; refused after external content was read in the turn). It is also always confirmed. Examples: force-ending a process,
             uninstalling a program. Plain "destructive" operations (delete a file, click a raw point, read the clipboard) are CONTROL / FILE + requires_confirmation.

Rules enforced in code (not by trusting the model)
  * Confirmation is bound to the exact tool AND arguments: the agent grants it only when the user's own message is a bare confirmation, the
    grant is one-shot, expires, is cleared by Stop, and is checked again inside execute(). A different argument = a different operation.
  * Explicit-request gate (`intent_rx`): the user's CURRENT message must ask for the operation; a model cannot trigger it on its own.
  * Taint: after a tool returned EXTERNAL content in this turn (web page, file text, MCP / agent output) every CONTROL / FILE operation that
    has no explicit-request gate needs a confirmation, so text inside a page or document cannot make Kira open / do something silently.
  * Backends: an operation names its backend (win32, uia, com, sendinput, powershell-fixed, winrt, ...). Alternative backends can be chained;
    a backend that is not available hands over to the next one, and the one that really ran is journaled. No free PowerShell exists.
  * Journal: every call - allowed, denied, needing confirmation, failed - is recorded with its real result (memory only, never on disk).
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from collections import deque
from dataclasses import dataclass

from .registry import ToolError, redact_secrets, READ, ACTION, SENSITIVE, FAILURE_KINDS

# ------------------------------------------------------------------ permission levels
READ_P, CONTROL, FILE, ELEVATED, PROTECTED = 1, 2, 3, 4, 5
PERMISSION_NAMES = {READ_P: "READ", CONTROL: "CONTROL", FILE: "FILE", ELEVATED: "ELEVATED", PROTECTED: "PROTECTED"}
PERMISSION_FA = {READ_P: "فقط خواندن", CONTROL: "کنترل عادی", FILE: "مدیریت فایل", ELEVATED: "نیازمند Administrator", PROTECTED: "فقط با درخواست مستقیم و صریح کاربر در همان پیام (هیچ‌وقت ابتکار Agent) + تأیید"}
CONFIRM_FROM = ELEVATED                       # ELEVATED and PROTECTED always need confirmation; lower levels need it only when `requires_confirmation` is set

BACKENDS = {"win32": "Windows API", "uia": "UI Automation", "com": "COM مستقیم (از داخل خود برنامه)", "sendinput": "SendInput", "powershell-fixed": "PowerShell ثابت و کنترل‌شده (داخلش ممکن است COM / UIA / WinRT صدا زده شود)", "elevated-uac": "PowerShell ثابت با درخواست UAC برای همین عملیات", "winget": "winget (ابزار رسمی ویندوز، بدون shell)", "registry": "رجیستری ویندوز (فقط خواندن) + فرایند نصب‌کننده‌ی خود برنامه",
            "winrt": "Windows Runtime", "filesystem": "فایل‌سیستم (PathPolicy)", "network": "شبکه (netguard)", "external": "MCP / ایجنت خارجی", "python": "کد داخلی Kira", "system-exe": "برنامه‌ی ثابت System32 (netsh / ping / pnputil) با آرگومان اعتبارسنجی‌شده، بدون shell", "powercfg": "powercfg.exe از System32 با آرگومان ثابت و اعتبارسنجی‌شده (بدون shell)"}

GRANT_TTL = 300.0
JOURNAL_SIZE = 300
EXTERNAL_TOOL_NAMES = {"read_file"}           # their RESULT is content written by somebody else
EXTERNAL_CATEGORIES = {"web", "mcp", "agents"}
PRIVATE_PARAMS = {"text", "content", "body", "password", "secret", "token", "key", "quote", "message"}
_STATUS_FA = {"ok": "موفق", "error": "خطا", "denied": "رد شد", "needs_confirmation": "منتظر تأیید", "bad_args": "ورودی نادرست", "unknown_tool": "ابزار ناشناخته"}


class BackendUnavailable(Exception):
    """Raised by a backend that cannot run on this PC (missing API, blocked, wrong Windows version): the next backend is tried."""


@dataclass(frozen=True)
class Policy:
    permission: int
    domain: str
    backend: str
    intent_rx: object
    external: bool
    verifies: bool
    intent_alt: object = None
    confirm: bool = False                     # `requires_confirmation` declared by the operation (independent of the level)

    @property
    def name(self) -> str:
        return PERMISSION_NAMES[self.permission]

    @property
    def needs_confirmation(self) -> bool:
        return self.confirm or self.permission >= CONFIRM_FROM

    always_confirm = needs_confirmation                    # old name, same meaning (kept for older callers)

    @property
    def direct_request_only(self) -> bool:
        return self.permission == PROTECTED


def _digest(tool: str, args: dict) -> str:
    return hashlib.sha256((tool + "\0" + json.dumps(args, sort_keys=True, ensure_ascii=False, default=str)).encode("utf-8")).hexdigest()


def _norm_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").lower().replace("ي", "ی").replace("ك", "ک").replace("‌", " "))


class Journal:
    """In-memory record of what was really done (never written to disk, never part of the chat history)."""

    def __init__(self, size: int = JOURNAL_SIZE):
        self._items: deque = deque(maxlen=size)
        self._lock = threading.Lock()

    def add(self, **entry):
        entry.setdefault("ts", time.time())
        with self._lock:
            self._items.append(entry)

    def recent(self, n: int = 10) -> list[dict]:
        with self._lock:
            return list(self._items)[-n:]


def _args_brief(args: dict) -> str:
    parts = []
    for k, v in (args or {}).items():
        if k in PRIVATE_PARAMS:
            parts.append(f"{k}=<{len(str(v))} نویسه>")
        else:
            parts.append(f"{k}={str(v)[:60]}")
    return redact_secrets(", ".join(parts))[:160]


class AccessManager:
    def __init__(self, registry):
        self.registry = registry
        self.journal = Journal()
        self._grants: dict[str, float] = {}
        self._lock = threading.RLock()
        self._tainted = False
        self._turn_text = ""
        # True in the real application (ToolAgent turns it on): a confirmed execute() then needs a grant that the agent created from the user's own
        # bare confirmation. A bare ToolRegistry (development / unit tests) keeps accepting confirmed=True from its caller.
        self.require_grants = False
        self._local = threading.local()

    # ------------------------------------------------------------ policy
    @staticmethod
    def policy_for(tool) -> Policy:
        """The policy of any tool. A capability declares it; a plain registry Tool gets it from its legacy level (READ / ACTION / SENSITIVE)."""
        perm = int(getattr(tool, "permission", 0) or 0)
        if perm not in PERMISSION_NAMES:
            if tool.level >= ACTION:                       # an old level-3 (SENSITIVE) tool is ordinary CONTROL / FILE that must be CONFIRMED; it is not PROTECTED
                perm = FILE if "files" in tool.categories else CONTROL
            else:
                perm = READ_P
        cats = set(tool.categories or ())
        domain = getattr(tool, "domain", "") or ("files" if "files" in cats else "web" if "web" in cats else "mcp" if cats & {"mcp", "agents"} else
                                               sorted(cats)[0] if cats else "system")
        external = bool(getattr(tool, "external", False)) or tool.name in EXTERNAL_TOOL_NAMES or bool(cats & EXTERNAL_CATEGORIES)
        backend = getattr(tool, "backend", "") or ("filesystem" if domain == "files" else "network" if domain == "web" else "external" if cats & {"mcp", "agents"} else "python")
        return Policy(perm, domain, backend, getattr(tool, "intent_rx", None), external, bool(getattr(tool, "verifies_result", False)), getattr(tool, "intent_alt", None),
                      bool(getattr(tool, "requires_confirmation", False)) or tool.level >= SENSITIVE)

    # ------------------------------------------------------------ turn state (taint)
    def begin_turn(self, user_text: str):
        try:
            from .. import experience                           # the previous turn is over: write its episode (no-op when it ran no tool)
            experience.flush(self._turn_text, self._tainted)
        except Exception:                                       # noqa: BLE001
            pass
        with self._lock:
            self._turn_text = str(user_text or "")
            self._tainted = False

    @property
    def user_text(self) -> str:
        return self._turn_text

    @property
    def tainted(self) -> bool:
        return self._tainted

    def check_intent(self, tool, pol: Policy) -> bool:
        if pol.intent_rx is None:
            return True
        text = _norm_text(self._turn_text)
        if pol.intent_rx.search(text):
            return True
        try:
            return bool(pol.intent_alt and pol.intent_alt(text))
        except Exception:                                  # noqa: BLE001 - a broken helper never opens the gate
            return False

    def confirmation_reason(self, tool, pol: Policy) -> str:
        """'' when no confirmation is needed, else why one is (shown to the user)."""
        if pol.needs_confirmation:
            return "elevated" if pol.permission == ELEVATED else "protected" if pol.permission == PROTECTED else "confirm"
        if self._tainted and pol.permission in (CONTROL, FILE) and pol.intent_rx is None:
            return "tainted"
        return ""

    # ------------------------------------------------------------ one-shot confirmations bound to (tool, arguments)
    def grant(self, tool: str, args: dict):
        with self._lock:
            now = time.time()
            self._grants = {d: t for d, t in self._grants.items() if t > now}
            self._grants[_digest(tool, args)] = now + GRANT_TTL

    def consume_grant(self, tool: str, args: dict) -> bool:
        with self._lock:
            exp = self._grants.pop(_digest(tool, args), 0.0)
            return exp > time.time()

    def revoke_grants(self):
        with self._lock:
            self._grants.clear()

    # ------------------------------------------------------------ backends
    def set_backend(self, name: str):
        self._local.backend = name

    def take_backend(self) -> str:
        name = getattr(self._local, "backend", "")
        self._local.backend = ""
        return name

    def set_verification(self, state: str):
        """A handler that could NOT confirm the final state says so ('unverified' | 'unknown'); the journal then never shows 'verified' for it."""
        self._local.verification = str(state)

    def take_verification(self) -> str:
        state = getattr(self._local, "verification", "")
        self._local.verification = ""
        return state

    def set_uac(self, used: bool):
        """elevation.py calls this when it really asked Windows for UAC for the running operation (journaled as uac_used)."""
        self._local.uac = bool(used)

    def take_uac(self) -> bool:
        used = bool(getattr(self._local, "uac", False))
        self._local.uac = False
        return used

    # ------------------------------------------------------------ recording
    def record(self, tool, pol: Policy, res, confirmed: bool = False, reason: str = ""):
        backend = self.take_backend() or pol.backend
        uac_used = self.take_uac()
        ok = res.status == "ok"
        override = self.take_verification()
        verified = bool(pol.verifies and ok and not override)
        verification = (override if ok and override else "verified" if verified else "not_applicable" if pol.permission == READ_P else "unverified" if ok else "not_run")
        self.journal.add(tool=tool.name, domain=pol.domain, permission=pol.name, status=res.status, ms=res.ms, backend=backend,
                         confirmed=bool(confirmed and ok and (pol.needs_confirmation or reason == "tainted")),
                         verified=verified, verification=verification, uac_required=pol.permission == ELEVATED, uac_used=uac_used,
                         confirmation_required=bool(pol.needs_confirmation or reason == "tainted"), kind=str(getattr(res, "kind", "") or ""),
                         args=_args_brief(res.args), summary=redact_secrets(" ".join(str(res.text).split()))[:220])
        if pol.external and res.status == "ok":
            with self._lock:
                self._tainted = True                         # what came back may carry instructions written by someone else

    def record_event(self, tool: str, domain: str, permission: str, status: str, backend: str, summary: str, verification: str = "unverified", kind: str = ""):
        """A SUB-operation of an already authorised call (e.g. a rollback inside a failed settings change) gets its own Journal line; it never creates a new permission."""
        self.journal.add(tool=tool, domain=domain, permission=permission, status=status, ms=0, backend=backend, confirmed=False, verified=verification == "verified",
                         verification=verification, uac_required=False, uac_used=False, confirmation_required=False, kind=kind, args="", summary=redact_secrets(summary)[:220])

    # ------------------------------------------------------------ report (READ tool windows_control_info)
    def info_text(self, recent: int = 8) -> str:
        tools = sorted(self.registry.all(), key=lambda t: (self.policy_for(t).permission, self.policy_for(t).domain, t.name))
        lines = ["مدیر مرکزی دسترسی (سطح · دامنه · ابزار · Backend · شرط اجرا):"]
        for t in tools:
            p = self.policy_for(t)
            gate = (("درخواست مستقیم کاربر در همان پیام + " if p.direct_request_only else "") + "تأیید صریح کاربر روی همین عملیات و پارامترها" if p.needs_confirmation
                    else "فقط با درخواست صریح در همان پیام" if p.intent_rx is not None
                    else "با درخواست کاربر (بعد از خواندن محتوای خارجی: تأیید)" if p.permission in (CONTROL, FILE) else "فقط خواندن")
            lines.append(f"- {p.name} · {p.domain} · {t.name} · {BACKENDS.get(p.backend, p.backend)} · {gate}" + (" · نتیجه دوباره بررسی می‌شود" if p.verifies else ""))
        items = [e for e in self.journal.recent(recent + 2) if e["tool"] != "windows_control_info"][-recent:]
        lines.append("")
        if items:
            lines.append(f"آخرین عملیات ثبت‌شده ({len(items)}):")
            for e in items:
                clock = time.strftime("%H:%M:%S", time.localtime(e["ts"]))
                kind = FAILURE_KINDS.get(e.get("kind", ""), "")
                lines.append(f"- {clock} {e['tool']}({e['args']}) [{e['permission']}/{BACKENDS.get(e['backend'], e['backend'])}] ← {_STATUS_FA.get(e['status'], e['status'])}"
                             f"{' · تأییدشده' if e['confirmed'] else ''}{' · UAC' if e.get('uac_used') else ''}{' · بازبینی‌شده' if e['verified'] else ''}"
                             f"{' · علت: ' + kind if kind else ''}: {e['summary'][:150]}")
        else:
            lines.append("هنوز عملیاتی در این اجرای برنامه ثبت نشده است.")
        return "\n".join(lines)


__all__ = ["AccessManager", "Policy", "Journal", "BackendUnavailable", "ToolError", "READ_P", "CONTROL", "FILE", "ELEVATED", "PROTECTED",
           "PERMISSION_NAMES", "BACKENDS", "READ", "FAILURE_KINDS"]
