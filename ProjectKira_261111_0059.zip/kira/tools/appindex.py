"""Open-ended app discovery helpers (Phase 1b): so a NEW program (3ds Max, PotPlayer ...) can be opened without changing Kira's code.

Four independent pieces, all data-only (nothing here starts a program, nothing is built from model text as a command):
  * AliasStore       learned name -> app name pairs in %LOCALAPPDATA%\\Kira\\app_aliases.json (written only through the remember_app_alias tool,
                     and only for an app that really resolves). Next time the spoken / Persian name just works.
  * latin_forms()    Persian / spoken name -> Latin look-alikes ("پات پلیر" -> "potplayer", "تری دی مکس" -> "3dsmax"), so fuzzy matching can compare.
  * collect_portable()  bounded scan for programs that have no Start Menu entry / registry record (portable apps, game folders on other drives).
                     Result is cached on disk for a day; the scan never goes deeper than SCAN_DEPTH and stops at SCAN_BUDGET seconds.
  * collect_uwp_registry()  Store (UWP) apps from the package registry + each package's AppxManifest.xml - no PowerShell involved.
Every function degrades to "nothing found" on non-Windows systems or when a source is unreadable.
"""
from __future__ import annotations

import difflib
import json
import os
import re
import sys
import time
import xml.etree.ElementTree as ET

try:
    import winreg
except Exception:                                             # noqa: BLE001
    winreg = None

IS_WIN = sys.platform == "win32"
SCAN_DEPTH = 3
SCAN_BUDGET = 8.0                                             # seconds, whole portable scan
SCAN_MAX_ENTRIES = 4000
INDEX_TTL = 24 * 3600
_SKIP_DIRS = {"windows", "$recycle.bin", "system volume information", "windowsapps", "node_modules", ".git", "__pycache__", "appdata", "temp", "cache",
              "programdata", "common files", "windows kits", "dotnet", "microsoft.net", "reference assemblies", "installer", "driverstore", "winsxs"}


def _data_dir() -> str:
    try:
        from ..config import DATA_DIR
        return str(DATA_DIR)
    except Exception:                                         # noqa: BLE001
        base = os.environ.get("KIRA_DATA_DIR") or os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "Kira")
        return base


def _norm(text: str) -> str:
    from .appcatalog import norm
    return norm(text)


# ------------------------------------------------------------------ learned aliases
class AliasStore:
    """spoken name (normalised) -> app display name. Small JSON file; a damaged file is ignored, never fatal."""

    def __init__(self, path: str = ""):
        self.path = path or os.path.join(_data_dir(), "app_aliases.json")
        self._data: dict | None = None

    def _load(self) -> dict:
        if self._data is None:
            try:
                with open(self.path, "r", encoding="utf-8") as fh:
                    raw = json.load(fh)
                self._data = {str(k): str(v) for k, v in raw.items()} if isinstance(raw, dict) else {}
            except (OSError, ValueError):
                self._data = {}
        return self._data

    def get(self, spoken: str) -> str:
        return self._load().get(_norm(spoken), "")

    def add(self, spoken: str, app_name: str) -> None:
        key = _norm(spoken)
        if not key or not str(app_name).strip() or len(key) > 80:
            raise ValueError("نام نامعتبر است.")
        data = self._load()
        if len(data) >= 500 and key not in data:
            raise ValueError("تعداد نام‌های ذخیره‌شده به سقف رسیده است.")
        data[key] = str(app_name).strip()[:120]
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(tmp, self.path)

    def all(self) -> dict:
        return dict(self._load())


STORE = AliasStore()


# ------------------------------------------------------------------ learned REAL executable paths
class PathStore:
    """app display name (normalised) -> full path of its .exe, in %LOCALAPPDATA%\\Kira\\app_paths.json.

    Only a path that really exists as a launchable program is ever stored and it is checked again on every read, so a moved / uninstalled
    program silently stops being used. A process id is never stored (it is only valid while that process lives); the file holds
    nothing but "this app's program is here"."""

    def __init__(self, path: str = ""):
        self.path = path or os.path.join(_data_dir(), "app_paths.json")
        self._data: dict | None = None

    def _load(self) -> dict:
        if self._data is None:
            try:
                with open(self.path, "r", encoding="utf-8") as fh:
                    raw = json.load(fh)
                self._data = {str(k): str(v) for k, v in raw.items()} if isinstance(raw, dict) else {}
            except (OSError, ValueError):
                self._data = {}
        return self._data

    def get(self, app_name: str) -> str:
        """The stored exe when it still exists and is still allowed, else ''."""
        from .appcatalog import is_safe_exe
        path = self._load().get(_norm(app_name), "")
        return path if path and is_safe_exe(path) else ""

    def add(self, app_name: str, exe: str) -> None:
        from .appcatalog import is_safe_exe
        key = _norm(app_name)
        if not key or len(key) > 80 or not is_safe_exe(exe):
            raise ValueError("مسیر فایل اجرایی معتبر نیست یا فایل وجود ندارد.")
        data = self._load()
        if data.get(key) == exe:
            return
        if len(data) >= 500 and key not in data:
            raise ValueError("تعداد مسیرهای ذخیره‌شده به سقف رسیده است.")
        data[key] = str(exe)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(tmp, self.path)

    def forget(self, app_name: str) -> None:
        data = self._load()
        if data.pop(_norm(app_name), None) is not None:
            try:
                with open(self.path, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, ensure_ascii=False, indent=1, sort_keys=True)
            except OSError:
                pass


PATHS = PathStore()


# ------------------------------------------------------------------ Persian / spoken name -> Latin look-alikes
_WORDS = {  # whole spoken words that are usually written differently in English
    "تری": "3", "تری‌دی": "3d", "تریدی": "3d", "تو": "2", "دی": "d", "مکس": "max", "مایا": "maya", "بلندر": "blender", "فتوشاپ": "photoshop",
    "ایلوستریتور": "illustrator", "پریمیر": "premiere", "افترافکت": "aftereffects", "افتر": "after", "افکت": "effects", "لایتروم": "lightroom",
    "اتوکد": "autocad", "ریویت": "revit", "اسکچاپ": "sketchup", "زیبراش": "zbrush", "ددرسولور": "davinciresolve", "داوینچی": "davinci", "رزالو": "resolve",
    "اوبس": "obs", "ویسی": "vlc", "وی‌ال‌سی": "vlc", "پات": "pot", "پلیر": "player", "کروم": "chrome", "فایرفاکس": "firefox",
    "تلگرام": "telegram", "دیسکورد": "discord", "اسپاتیفای": "spotify", "استیم": "steam", "ورد": "word", "اکسل": "excel", "پاورپوینت": "powerpoint",
    "ویژوال": "visual", "استودیو": "studio", "کد": "code", "یونیتی": "unity", "آنریل": "unreal", "انجین": "engine", "اپیک": "epic", "گیمز": "games",
    "لانچر": "launcher", "زوم": "zoom", "اسکایپ": "skype", "واتساپ": "whatsapp", "نوتپد": "notepad", "وینرار": "winrar", "سون‌زیپ": "7zip", "قفل": "lock",
}
_LETTERS = {"ا": "a", "آ": "a", "ب": "b", "پ": "p", "ت": "t", "ث": "s", "ج": "j", "چ": "ch", "ح": "h", "خ": "kh", "د": "d", "ذ": "z", "ر": "r", "ز": "z",
            "ژ": "zh", "س": "s", "ش": "sh", "ص": "s", "ض": "z", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh", "ف": "f", "ق": "gh", "ک": "k", "گ": "g", "ل": "l",
            "م": "m", "ن": "n", "و": "v", "ه": "h", "ی": "y", "ئ": "y", "ء": "", "ؤ": "v", "ة": "h", "ي": "y", "ك": "k"}
_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
_PERSIAN_RX = re.compile(r"[؀-ۿ]")


def _skeleton(text: str) -> str:
    """Consonant skeleton used for sound-alike comparison: 'potplayer' and 'پاتپلیر' both give 'ptplyr'."""
    t = re.sub(r"[^a-z0-9]", "", text.lower())
    t = t.replace("ph", "f").replace("ck", "k").replace("c", "k").replace("q", "k").replace("w", "v").replace("x", "ks")
    t = re.sub(r"(?<=[a-z])[aeiou]+", "", t)                  # keep a leading vowel, drop the others
    return re.sub(r"(.)\1+", r"\1", t)


def latin_forms(spoken: str) -> set:
    """Possible Latin spellings of a spoken name (normalised, no spaces). An all-Latin name returns only itself."""
    text = str(spoken or "").translate(_FA_DIGITS).strip()
    if not text:
        return set()
    base = _norm(text)
    if not _PERSIAN_RX.search(text):
        return {base}
    out = set()
    words = [w for w in re.split(r"[\s‌]+", text.lower()) if w]
    mapped, phonetic = [], []
    for w in words:
        if w in _WORDS:
            mapped.append(_WORDS[w])
            phonetic.append(_WORDS[w])
        else:
            mapped.append(w)
            phonetic.append("".join(_LETTERS.get(ch, ch) for ch in w))
    for parts in (mapped, phonetic):
        joined = "".join(parts)
        if not _PERSIAN_RX.search(joined):
            out.add(_norm(joined))
    return {o for o in out if o}


def sound_match(spoken: str, names: dict, cutoff: float = 0.8) -> list:
    """names = {normalised key: display}. -> up to 3 display names that sound like `spoken` (Persian or Latin)."""
    forms = latin_forms(spoken)
    scored = []
    for key, display in names.items():
        k_skel = _skeleton(key)
        best = 0.0
        for f in forms:
            if len(f) >= 3 and (f in key or (len(key) >= 4 and key in f)):
                best = max(best, 0.95)
            f_skel = _skeleton(f)
            if len(f_skel) >= 3 and len(k_skel) >= 3:
                best = max(best, difflib.SequenceMatcher(None, f_skel, k_skel).ratio())
        if best >= cutoff:
            scored.append((best, display))
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:3]]


# ------------------------------------------------------------------ portable programs (no Start Menu entry, no registry record)
_NOT_MAIN_RX = re.compile(r"(?i)unins|uninstall|setup|install|updat|crash|helper|report|redist|vcredist|dotnet|webview|elevat|maintenance|repair|"
                          r"cef|squirrel|diagnos|telemetry|bootstrap|notifier|launcher_?service|^unity|vc_redist|ndp|msedgewebview|crashpad")
_BLOCKED = {"cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "mshta.exe", "regsvr32.exe", "rundll32.exe", "msiexec.exe", "reg.exe",
            "wmic.exe", "bash.exe", "wsl.exe", "certutil.exe", "bitsadmin.exe", "schtasks.exe", "sc.exe", "net.exe", "net1.exe", "taskkill.exe",
            "msbuild.exe", "installutil.exe", "regasm.exe", "regsvcs.exe", "forfiles.exe", "at.exe", "python.exe", "pythonw.exe"}


def _scan_roots() -> list:
    roots = []
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        v = os.environ.get(env)
        if v:
            roots.append(os.path.join(v, "Programs") if env == "LOCALAPPDATA" else v)
    home = os.environ.get("USERPROFILE")
    if home:
        roots += [os.path.join(home, d) for d in ("Desktop", "Downloads", "Documents")]
    try:
        import string
        for letter in string.ascii_uppercase:
            drive = letter + ":\\"
            if letter == "C" or not os.path.isdir(drive):
                continue
            roots.append(drive)                                   # top level of other drives (depth-limited below)
    except Exception:                                         # noqa: BLE001
        pass
    seen, out = set(), []
    for r in roots:
        k = os.path.normcase(r)
        if k not in seen and os.path.isdir(r):
            seen.add(k)
            out.append(r)
    return out


def scan_portable(roots=None, depth: int = SCAN_DEPTH, budget: float = SCAN_BUDGET) -> list:
    """-> [(display name, exe path)]. One entry per folder: the best .exe in it (name close to the folder name wins; installers / helpers are skipped)."""
    deadline = time.monotonic() + budget
    found: list = []
    for root in (roots if roots is not None else _scan_roots()):
        stack = [(root, 0)]
        while stack and len(found) < SCAN_MAX_ENTRIES:
            if time.monotonic() > deadline:
                return found
            folder, d = stack.pop()
            try:
                with os.scandir(folder) as it:
                    items = list(it)
            except OSError:
                continue
            exes = [e.name for e in items if e.is_file(follow_symlinks=False) and e.name.lower().endswith(".exe")
                    and e.name.lower() not in _BLOCKED and not _NOT_MAIN_RX.search(e.name)]
            if exes:
                fname = _norm(os.path.basename(folder))
                exes.sort(key=lambda n: (-difflib.SequenceMatcher(None, _norm(os.path.splitext(n)[0]), fname).ratio(), len(n)))
                best = exes[0]
                stem = os.path.splitext(best)[0]
                folder_ok = d > 0 and os.path.basename(folder).lower() not in _SKIP_DIRS
                if len(exes) == 1 or difflib.SequenceMatcher(None, _norm(stem), fname).ratio() >= 0.6 or d == 0:
                    found.append((stem, os.path.join(folder, best)))
                    if folder_ok and _norm(stem) != fname:
                        found.append((os.path.basename(folder), os.path.join(folder, best)))   # also findable by the folder name ("Blender Foundation")
            if d < depth:
                for e in items:
                    try:
                        if e.is_dir(follow_symlinks=False) and e.name.lower() not in _SKIP_DIRS and not e.name.startswith("."):
                            stack.append((e.path, d + 1))
                    except OSError:
                        continue
    return found


def _index_path() -> str:
    return os.path.join(_data_dir(), "app_index.json")


def portable_index(force: bool = False) -> list:
    """Cached scan result (one day). -> [(name, exe)] with only files that still exist."""
    path = _index_path()
    if not force:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if time.time() - float(data.get("time", 0)) < INDEX_TTL:
                return [(n, p) for n, p in data.get("items", []) if os.path.isfile(p)]
        except (OSError, ValueError, TypeError):
            pass
    items = scan_portable()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"time": time.time(), "items": items}, fh, ensure_ascii=False)
    except OSError:
        pass
    return items


def collect_portable(add) -> None:
    for name, exe in portable_index():
        add(name, "portable-scan", "exe", exe, install_dir=os.path.dirname(exe), exe=exe)


# ------------------------------------------------------------------ Store (UWP) apps without PowerShell
_PKG_KEY = r"Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages"
_AUMID_PART_RX = re.compile(r"^[A-Za-z0-9.\-_]+$")


def _pretty(identity_name: str) -> str:
    last = identity_name.split(".")[-1]
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", last).strip() or identity_name


def _manifest_apps(root: str, family: str) -> list:
    """[(display name, AUMID)] from <root>\\AppxManifest.xml."""
    try:
        tree = ET.parse(os.path.join(root, "AppxManifest.xml"))
    except (OSError, ET.ParseError):
        return []
    r = tree.getroot()
    ident = next((e for e in r.iter() if e.tag.endswith("}Identity") or e.tag == "Identity"), None)
    pkg_name = ident.get("Name", "") if ident is not None else ""
    out = []
    for app in (e for e in r.iter() if e.tag.endswith("}Application") or e.tag == "Application"):
        app_id = app.get("Id", "")
        if not _AUMID_PART_RX.match(app_id):
            continue
        visual = next((c for c in app.iter() if c.tag.endswith("}VisualElements") or c.tag == "VisualElements"), None)
        if visual is None or visual.get("AppListEntry", "default") == "none":
            continue                                          # no Start-menu presence: a background component
        name = visual.get("DisplayName", "")
        if not name or name.lower().startswith("ms-resource"):
            name = _pretty(pkg_name or app_id)
        out.append((name, f"{family}!{app_id}"))
    return out


def collect_uwp_registry(add) -> None:
    if not (IS_WIN and winreg is not None):
        return
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _PKG_KEY)
    except OSError:
        return
    with key:
        i = 0
        while True:
            try:
                full = winreg.EnumKey(key, i)
            except OSError:
                break
            i += 1
            parts = full.split("_")
            if len(parts) < 5:
                continue
            family = parts[0] + "_" + parts[-1]
            try:
                with winreg.OpenKey(key, full) as sub:
                    root = winreg.QueryValueEx(sub, "PackageRootFolder")[0]
            except OSError:
                continue
            if not root or "framework" in parts[0].lower() or "vclibs" in parts[0].lower() or "runtime" in parts[0].lower():
                continue
            for name, aumid in _manifest_apps(str(root), family):
                add(name, "store-registry", "uwp", aumid)
