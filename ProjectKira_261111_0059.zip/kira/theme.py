"""Visual theme: one stylesheet, two looks.

``build_style("off")``      solid dark theme.
``build_style("acrylic")`` / ``build_style("mica")``  "glass" theme for Windows 11: the window itself is transparent
(the DWM paints the blurred backdrop, see winfx.py) and every card/field is a translucent tint on top of it.
"""
STYLE = """
/* KIRA NEON // midnight glass */
QMainWindow, QWidget { background: #0b0e18; color: #e8edff; font-family: "Segoe UI", "Vazirmatn", Tahoma; font-size: 10pt; }
QLabel, QCheckBox, QSlider, QToolButton { background: transparent; }
QLabel#brandTitle { color: #f2f5ff; font-size: 12pt; font-weight: 900; letter-spacing: 2px; }
QLabel#brandSubtitle { color: #6e829f; font-size: 7pt; letter-spacing: 1px; }
QLabel#title { font-size: 15pt; font-weight: 850; color: #f1f4ff; }
QLabel#chatSubtitle { color: #7185a5; font-size: 8pt; padding-bottom: 2px; }
QLabel#hint { color: #8995b5; font-size: 9pt; }
QLabel#status { color: #7debdc; font-size: 8.5pt; }
QToolTip { background: #111a2b; color: #e8edff; border: 1px solid #20cfc4; padding: 5px 7px; }

QFrame#navRail { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #121a2b,stop:1 #101522); border: 1px solid #263a56; border-radius: 18px; }
QLabel#navCaption { color: #647b9c; font-size: 7.5pt; font-weight: 800; letter-spacing: 1.4px; padding: 4px 8px; }
QLabel#navVersion { color: #536783; font-size: 7pt; padding-top: 5px; }
QFrame#navDivider { background: #26364f; border: none; max-height: 1px; }
QToolButton#navItem { background: transparent; border: 1px solid transparent; border-radius: 10px; padding: 9px 10px; text-align: left; color: #9eacc7; font-weight: 600; }
QToolButton#navItem:hover { background: #1a2940; border-color: #2b4663; color: #edf7ff; }
QToolButton#navItem:checked { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #123c49,stop:1 #20243f); border: 1px solid #20cfc4; color: #b4fff5; }
QFrame#avatarCard { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #151b31,stop:0.55 #101729,stop:1 #20152e); border: 1px solid #33466d; border-right: 2px solid #23d7cf; border-radius: 18px; }
QFrame#chatCard { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #111a2a,stop:1 #0d1422); border: 1px solid #2a3d59; border-radius: 18px; }
QFrame#composer { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #17243a,stop:1 #111b2c); border: 1px solid #36516f; border-top: 2px solid #25d9ce; border-radius: 15px; }
QTextEdit#chatView, QTextBrowser#chatView { background: transparent; border: none; padding: 8px 10px; selection-background-color: #315a80; }
QTextBrowser#chatView a { color: #8fb8ff; text-decoration: none; }
QTextBrowser#chatView a:hover { color: #b7d5ff; }
QLabel#typingIndicator { background: transparent; color: #7debdc; font-size: 8.5pt; font-weight: 600; padding: 2px 4px; }
QPlainTextEdit#chatInput { background: transparent; border: none; padding: 3px 5px; selection-background-color: #315a80; }

QTextEdit, QPlainTextEdit, QLineEdit, QSpinBox, QDoubleSpinBox { background: #111a2a; border: 1px solid #2a3c57; border-radius: 9px; padding: 7px 9px; selection-background-color: #246c79; }
QTextEdit:focus, QPlainTextEdit:focus, QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus { border: 1px solid #20d5c9; }
QTextEdit#chatView:focus, QPlainTextEdit#chatInput:focus { border: none; }
QPushButton { background: #263a59; border: 1px solid #3a5476; border-radius: 9px; padding: 8px 14px; color: #eaf2ff; font-weight: 650; }
QPushButton:hover { background: #304d70; border-color: #20cfc4; }
QPushButton:pressed { background: #1d304b; }
QPushButton:disabled { background: #202a3b; color: #65718c; border-color: #29364a; }
QPushButton:checked { background: #164d55; border-color: #20cfc4; color: #a8fff3; }
QPushButton#save { background: #087e78; border: 1px solid #23d7cf; padding: 7px 16px; }
QPushButton#save:hover { background: #0b9b91; }

QToolButton { border: 1px solid transparent; border-radius: 10px; padding: 7px; color: #aab9d6; }
QToolButton:hover { background: #1a2b43; border-color: #31506a; color: #ffffff; }
QToolButton:pressed { background: #203c54; }
QToolButton:checked { background: #123b47; border: 1px solid #20cfc4; color: #83fff0; }
QToolButton:disabled { background: transparent; }
QToolButton::menu-indicator { image: none; }
QToolButton#sendBtn { background: #087e78; border: 1px solid #23d7cf; border-radius: 16px; padding: 0px; }
QToolButton#sendBtn:hover { background: #0ca99d; }
QToolButton#sendBtn:disabled { background: #263448; border-color: #34465d; }
QToolButton#routeChip { background: #122b39; border: 1px solid #1d8d91; border-radius: 12px; padding: 4px 10px; color: #9df7ee; font-size: 8.5pt; }
QToolButton#routeChip:hover { background: #183b4a; border: 1px solid #32e2d4; }
QToolButton#menuBtn { background: #141e30; border: 1px solid #2b4563; }
QToolButton#composerTool { background: #1a2940; border: 1px solid #304963; border-radius: 11px; padding: 3px; }
QToolButton#composerTool:hover { background: #203b54; border-color: #27cfc5; }
QToolButton#composerTool:checked { background: #123f49; border-color: #27d8ce; color: #aafff5; }

QComboBox { background: #111a2a; border: 1px solid #2a3c57; padding: 7px 9px; border-radius: 9px; }
QComboBox QAbstractItemView { background: #111a2a; border: 1px solid #31506a; selection-background-color: #174b59; }
QMenu { background: #111a2a; border: 1px solid #31506a; border-radius: 11px; padding: 6px; }
QMenu::item { padding: 8px 24px; border-radius: 7px; }
QMenu::item:selected { background: #173b4b; color: #9df7ee; }
QMenu::item:disabled { color: #64718d; }
QMenu::separator { height: 1px; background: #263650; margin: 5px 9px; }

QGroupBox { background: #101a2a; border: 1px solid #2a3d59; border-radius: 14px; margin-top: 17px; padding: 16px 12px 10px 12px; font-weight: 650; }
QGroupBox::title { subcontrol-origin: margin; left: 15px; padding: 0 7px; color: #73e9df; }
QTabWidget::pane { border: 1px solid #263d59; border-radius: 12px; background: #0f1726; top: -1px; }
QTabBar::tab { background: #141f31; border: 1px solid #293d59; padding: 9px 17px; margin: 3px 3px 0 3px; border-top-left-radius: 9px; border-top-right-radius: 9px; color: #a9b8d2; }
QTabBar::tab:selected { background: #173b4b; border-color: #20cfc4; color: #a8fff3; }
QTabBar::tab:hover:!selected { background: #1b2d45; }
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical { background: transparent; width: 9px; margin: 3px; }
QScrollBar::handle:vertical { background: #30445f; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #20a9a7; }
QScrollBar:horizontal { background: transparent; height: 9px; margin: 3px; }
QScrollBar::handle:horizontal { background: #30445f; border-radius: 4px; min-width: 30px; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QSlider::groove:horizontal { height: 5px; background: #293c57; border-radius: 2px; }
QSlider::handle:horizontal { background: #75eee2; border: 2px solid #0e202e; width: 14px; margin: -5px 0; border-radius: 8px; }
QSlider::sub-page:horizontal { background: #159b9a; border-radius: 2px; }
QToolButton#genStop { background: #9b345c; border: 1px solid #e85b91; border-radius: 16px; padding: 0px; }
QToolButton#genStop:hover { background: #bf3d70; }
QFrame#attTile { background: #172338; border: 1px solid #34506b; border-radius: 12px; }
QLabel#attThumb { background: #101a2a; border-radius: 8px; color: #78e8df; font-size: 12pt; font-weight: 700; }
QLabel#attOverlay { background: rgba(4,10,20,0.72); border-radius: 8px; color: #ffffff; font-size: 13pt; font-weight: 700; }
QToolButton#attClose { background: rgba(0,0,0,0.62); color: #ffffff; border-radius: 10px; padding: 0px; font-size: 8pt; }
QToolButton#attClose:hover { background: #b53b68; }
"""

# Opaque surface -> translucent tint used in glass mode.
GLASS_TINTS = {'#101a2a': 'rgba(16,26,42,0.58)', '#141e30': 'rgba(20,30,48,0.62)', '#111a2a': 'rgba(17,26,42,0.58)', '#151b31': 'rgba(21,27,49,0.56)', '#101729': 'rgba(16,23,41,0.52)', '#1a2b43': 'rgba(255,255,255,0.08)', '#2a3c57': 'rgba(255,255,255,0.10)', '#263650': 'rgba(255,255,255,0.08)', '#31506a': 'rgba(255,255,255,0.10)'}

# Windows that DWM does not blend must stay opaque even in glass mode (menus, dialogs, tooltips, combo popups).
GLASS_OPAQUE = """
QDialog, QMessageBox, QFileDialog { background: #0e1523; }
QMenu { background: #111a2a; }
QToolTip { background: #111a2b; }
QComboBox QAbstractItemView { background: #111a2a; }
QListWidget { background: rgba(20,22,32,0.45); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; }
QDialog QListWidget { background: #14151d; }
"""


def build_style(effect="off"):
    """Stylesheet for the window effect: 'off' | 'mica' | 'acrylic'."""
    if effect not in ("mica", "acrylic"):
        return STYLE
    alpha = "0.30" if effect == "acrylic" else "0.55"            # Mica is nearly flat, so it needs a stronger tint than Acrylic
    css = STYLE.replace("QMainWindow, QWidget { background: #14151d;", "QMainWindow, QWidget { background: transparent;", 1)
    for opaque, tint in GLASS_TINTS.items():
        css = css.replace(opaque, tint)
    return css + f"\nQMainWindow {{ background: rgba(14,15,22,{alpha}); }}\n" + GLASS_OPAQUE
