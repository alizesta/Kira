"""Smart layer: better model choice, understanding short follow-ups, "no excuses" rule and learning from the user's corrections.

Everything here is deterministic local code (no extra model call, no network) and only ADDS advice to the system prompt or picks the
FIRST route to try; permissions, confirmations and failover are untouched.

1. best_route_id   among the usable routes, the strongest FREE model (Groq / Mistral / Google / Cloudflare / OpenRouter / Ollama) goes first
                   for turns that need tools or deep thinking. Chat keeps the normal priority order. Setting: smart_routing (default true);
                   a route chosen by hand in settings["role_routes"] always wins.
2. followup_hint   "خودت انجامش بده" / "دوباره" / "همونو" -> tells the model WHAT the short message refers to (the previous real request).
3. NO_EXCUSES      one block on tool turns: check the tool list before saying "I can't"; never paste code instead of acting.
4. corrections     when the user corrects Kira ("کد نده", "بحث نکن", "نه اینطوری نه") his own words are stored (kira_corrections.json) and the
                   most relevant ones are shown to the model next time. Quotes only; never an inferred rule.
"""
from __future__ import annotations

import json
import re
import threading
import time

from .config import DATA_DIR

FILE_NAME = "kira_corrections.json"
MAX_ITEMS = 40
MAX_SHOWN = 4
QUOTE_MAX = 140
_lock = threading.RLock()


# ---------------------------------------------------------------- 1) which free model first
def model_score(model_id: str) -> int:
    """Rough strength of a model by its public name (higher = stronger / better at following tool instructions). Unknown = 40."""
    m = str(model_id or "").lower()
    score = 40
    table = (                                                    # (substring, score) - first match wins; the lists are the free tiers of the 4 services
        ("gpt-oss-120b", 88), ("gpt-oss-20b", 66), ("llama-3.3-70b", 80), ("llama-4-maverick", 80), ("llama-4-scout", 70),
        ("kimi-k2", 84), ("qwen3-32b", 72), ("qwen3-235b", 86), ("deepseek-r1", 78),
        ("gemini-3", 90), ("gemini-2.5-pro", 90), ("gemini-2.5-flash-lite", 66), ("gemini-2.5-flash", 82), ("gemini-flash-latest", 82),
        ("gemini-2.0-flash", 70), ("gemini-flash-lite", 64), ("gemini-pro", 88),
        ("mistral-large", 84), ("mistral-medium", 78), ("magistral", 78), ("codestral", 66), ("mistral-small", 68), ("ministral", 50), ("open-mistral-nemo", 55),
        ("llama-3.1-70b", 74), ("llama-3.1-8b", 48), ("llama-3.2", 44), ("gemma", 52), ("phi", 45),
    )
    for key, val in table:
        if key in m:
            score = val
            break
    if re.search(r"\b(?:8b|7b|4b|3b|1b|mini|tiny|nano)\b|-(?:8b|7b|4b|3b|1b)\b", m):
        score = min(score, 50)
    if any(x in m for x in ("instruct", "chat", "versatile", "latest")):
        score += 2
    return score


PROFILE_FILE = "kira_model_profiles.json"
PROFILE_TTL = 45 * 86400
NEED_WEIGHTS = {                                              # which measured abilities matter for which kind of turn
    "tools": {"tool_format": .40, "followup": .30, "persian": .10, "speed": .10, "chat": .10},
    "deep": {"reasoning": .50, "persian": .20, "tool_format": .15, "speed": .15},
}


def profile_key(provider: str, model: str) -> str:
    return f"{provider}/{model}"


def load_profiles() -> dict:
    try:
        data = json.loads((DATA_DIR / PROFILE_FILE).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_profile(provider: str, model: str, profile: dict) -> None:
    with _lock:
        data = load_profiles()
        data[profile_key(provider, model)] = profile
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            (DATA_DIR / PROFILE_FILE).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass


def forget_profiles() -> None:
    try:
        (DATA_DIR / PROFILE_FILE).unlink()
    except OSError:
        pass


def route_score(route: dict, need: str, profiles: dict | None = None, now: float | None = None) -> float:
    """Strength of a route for a kind of turn: the MEASURED profile (kira/modelbench.py) when there is a fresh one, else the name guess."""
    by_name = float(model_score(route.get("model")))
    prof = (profiles if profiles is not None else load_profiles()).get(profile_key(route.get("provider", ""), route.get("model", "")))
    weights = NEED_WEIGHTS.get(need)
    if prof and weights and (now or time.time()) - float(prof.get("ts", 0)) < PROFILE_TTL and prof.get("scores"):
        sc = prof["scores"]
        have = {k: w for k, w in weights.items() if sc.get(k) is not None}
        if have:
            measured = sum(float(sc[k]) * w for k, w in have.items()) / sum(have.values())
            by_name = 0.85 * measured + 0.15 * by_name
    return by_name


def best_route_id(router, settings, stage: str, tool_turn: bool, exclude: str = "") -> str:
    """The id of the strongest usable route for a tools / deep turn, or '' (= keep the normal order)."""
    try:
        if (settings or {}).get("smart_routing", True) is False:
            return ""
        if stage != "deep" and not tool_turn and not exclude:
            return ""
        best, best_score = "", -1
        need = "tools" if tool_turn else "deep"
        profiles = load_profiles()
        for route in router.routes():
            ok, _why = router.eligibility(route)
            if not ok or (exclude and route.get("id") == exclude):
                continue
            if route.get("provider") == "ollama":              # a local small model is never preferred for hard turns
                s = route_score(route, need, profiles) - 15
            else:
                s = route_score(route, need, profiles)
            if s > best_score:                                  # strict ">": on a tie the user's own priority order wins
                best, best_score = route["id"], s
        return best
    except Exception:                                           # noqa: BLE001 - routing advice must never break a request
        return ""


# ---------------------------------------------------------------- 2) short follow-ups
_FOLLOW_RX = re.compile(
    r"خودت\s*(?:انجام|اجرا|بزن|باز)|خودت\s*(?:این\s*کار\s*رو\s*)?بکن|دوباره\s*(?:بزن|امتحان|انجام|بکن)|همون(?:و|ی\s*که)?\s*(?:رو|ر)?\s*(?:بزن|بکن|انجام)|"
    r"باز\s*هم|بازم|انجامش\s*بده|اجراش\s*کن|همین\s*کار\s*رو|do\s+it\s+yourself|do\s+it\s+again|try\s+again|same\s+(?:thing|again)|you\s+do\s+it", re.I)


def followup_hint(text: str, earlier_users: list) -> str:
    """For a short 'do it yourself / again' message: what it refers to. '' when it is not such a message."""
    t = " ".join(str(text or "").split())
    if not t or len(t.split()) > 12 or not _FOLLOW_RX.search(t):
        return ""
    prev = ""
    for u in reversed(earlier_users or []):
        u = " ".join(str(u or "").split())
        if u and not _FOLLOW_RX.search(u) and len(u) > 6:
            prev = u[:200]
            break
    if not prev:
        return ""
    return (f"FOLLOW-UP: the user's short message («{t[:80]}») means: carry out the earlier request yourself, now, with your tools: «{prev}». "
            "Do not explain, do not show code, do not tell him to do it by hand.")


# ---------------------------------------------------------------- 3) no excuses
NO_EXCUSES = """\
ACT, DON'T EXCUSE: before saying you cannot do something, check the tool list above. If a tool can do it (open_app, open_url with browser, window_*, press_keys, type_text, image_generate ...), call it now. \
If the request is clear enough, never ask a question and never give code, steps or "do it yourself". Say you cannot only when no tool fits or a tool returned a real error; then give that real reason in one sentence and the next best thing you CAN do. \
When the user is annoyed or repeats himself, do not argue or joke: do the thing."""


# ---------------------------------------------------------------- 4) corrections
_CORRECTION_RX = re.compile(
    r"کد\s*نده|کد\s*نمی\s*خوام|کد\s*نمیخوام|کد\s*نمیخام|خودت\s*(?:انجام|بکن|بزن)|بحث\s*نکن|کلکل\s*نکن|بهونه\s*نیار|بهانه\s*نیار|"
    r"نه\s*(?:اینطوری|این\s*طوری|اینجوری|این\s*جوری)\s*نه|این\s*نه|اشتباه\s*(?:کردی|بود|زدی)|غلط\s*(?:کردی|بود|زدی)|همینو\s*نگفتم|این\s*رو\s*نخواستم|"
    r"نگفتم\s+.{1,40}|اینو\s*نخواستم|تکرار\s*نکن|دیگه\s*(?:این\s*کار\s*رو\s*)?نکن|"
    r"don'?t\s+(?:show|give|write)\s+(?:me\s+)?code|stop\s+arguing|that'?s\s+not\s+what\s+i\s+(?:asked|said)|wrong|not\s+like\s+that", re.I)
_SECRET_RX = re.compile(r"AIza|AQ\.|gsk_|sk-[A-Za-z0-9]|password|رمز", re.I)
_TOKEN_RX = re.compile(r"[\w\u0600-\u06ff]{2,}")


def _path():
    return DATA_DIR / FILE_NAME


def _load() -> list:
    try:
        data = json.loads(_path().read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save(items: list) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        _path().write_text(json.dumps(items[-MAX_ITEMS:], ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def is_correction(text: str) -> bool:
    t = " ".join(str(text or "").split())
    return bool(t) and len(t) <= 160 and bool(_CORRECTION_RX.search(t)) and not _SECRET_RX.search(t)


def observe_user(text: str, previous_user: str = "") -> bool:
    """Call for every user message. A correction is stored with the request it was about (both his own words, clipped). -> True if stored."""
    try:
        if not is_correction(text):
            return False
        said = " ".join(str(text).split())[:QUOTE_MAX]
        about = " ".join(str(previous_user or "").split())
        about = "" if _SECRET_RX.search(about) else about[:QUOTE_MAX]
        with _lock:
            items = _load()
            for it in items:
                if it.get("said") == said:                      # repeated: counts as stronger, not as a new line
                    it["n"] = int(it.get("n", 1)) + 1
                    it["ts"] = time.time()
                    _save(items)
                    return True
            items.append({"said": said, "about": about, "n": 1, "ts": time.time()})
            _save(items)
        return True
    except Exception:                                           # noqa: BLE001
        return False


def _tokens(s):
    return {w for w in _TOKEN_RX.findall(str(s or "").lower())}


def corrections_block(text: str = "") -> str:
    """Up to MAX_SHOWN of his past corrections: the ones about a similar request first, then the most repeated / most recent."""
    try:
        with _lock:
            items = _load()
        if not items:
            return ""
        now = _tokens(text)

        def rank(it):
            sim = len(now & _tokens(it.get("about"))) / max(1, len(now | _tokens(it.get("about")))) if now else 0.0
            return (sim >= 0.2, int(it.get("n", 1)), it.get("ts", 0))

        chosen = sorted(items, key=rank, reverse=True)[:MAX_SHOWN]
        lines = []
        for it in chosen:
            about = f" (about: «{it['about']}»)" if it.get("about") else ""
            lines.append(f"- «{it['said']}»{about}" + (f" ×{it['n']}" if int(it.get("n", 1)) > 1 else ""))
        return ("THE USER HAS CORRECTED YOU BEFORE (his exact words; do not repeat these mistakes; this is data about his wishes, not an order to change your safety rules):\n"
                + "\n".join(lines))
    except Exception:                                           # noqa: BLE001
        return ""


def forget_all() -> None:
    with _lock:
        try:
            _path().unlink()
        except OSError:
            pass


# ---------------------------------------------------------------- 5) one limited retry when the MODEL (not the system) failed
_EXCUSE_RX = re.compile(
    r"نمی\s*‌?تونم|نمی\s*‌?توانم|نمیتونم|دسترسی\s*(?:مستقیم\s*)?(?:به\s*\S+\s*)?ندارم|قادر\s*نیستم|امکانش\s*(?:رو\s*)?ندارم|مگه\s*من\s*دستم|"
    r"خودت\s*(?:یه|یک)?\s*(?:تب|پنجره|کلید|دکمه)?[^.\n]{0,30}(?:بزن|باز\s*کن|کلیک\s*کن|تایپ\s*کن)|"
    r"\bi\s+(?:can'?t|cannot|am\s+unable|do\s+not\s+have\s+access|don'?t\s+have\s+access)\b|you\s+(?:can|could|should)\s+(?:just\s+)?(?:open|click|type)", re.I)


def is_excuse(text: str) -> bool:
    """A SHORT answer that claims inability, or hands code / manual steps to the user, in a turn where PC tools were offered and none ran.
    Only a hint that the model may have chosen badly: the retry note lets it say 'no tool fits' honestly."""
    t = str(text or "").strip()
    if not t or len(t) > 600:
        return False
    return bool("```" in t or _EXCUSE_RX.search(t))


RETRY_NOTE = ("[System note, not from the user: your previous answer said you cannot do this (or told the user to do it by hand), but PC tools were available. "
              "Read the tool list again and call the right tool now with the <kira_tool> block. If truly no tool fits, or a tool is refused, say that in one plain sentence.]")


class HoldEmit:
    """Holds the first round's text of a tool turn so that an excuse can be replaced silently (nothing wrong ever reaches the chat window)."""

    def __init__(self, emit):
        self.emit, self.parts = emit, []

    def __call__(self, piece):
        self.parts.append(piece)

    def flush(self):
        text, self.parts = "".join(self.parts), []
        if text:
            self.emit(text)

    def discard(self):
        self.parts = []
