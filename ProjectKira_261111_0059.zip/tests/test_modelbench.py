import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tests import helpers  # noqa: F401
from kira import modelbench as mb
from kira import smart

GOOD = '<kira_tool>{"tool":"open_url","args":{"url":"https://claude.ai","browser":"edge"}}</kira_tool>'


class Scoring(unittest.TestCase):
    def test_tool_scores(self):
        self.assertEqual(mb.score_tool_call(GOOD), 100)
        self.assertEqual(mb.score_tool_call('<kira_tool>{"tool":"open_app","args":{"name":"msedge","url":"claude.ai"}}</kira_tool>'), 100)
        self.assertEqual(mb.score_tool_call('<kira_tool>{"tool":"open_url","args":{"url":"claude.ai"}}</kira_tool>'), 70)
        self.assertEqual(mb.score_tool_call('[open_app: name="msedge", url="claude.ai"]'), 50)
        self.assertEqual(mb.score_tool_call("نمی‌تونم، خودت باز کن"), 0)
        self.assertEqual(mb.score_tool_call("<think>hmm</think>" + GOOD), 100)

    def test_other_scores(self):
        self.assertEqual(mb.score_chat("سلام! خوبم، تو چطوری؟"), 100)
        self.assertEqual(mb.score_chat(GOOD), 0)
        self.assertEqual(mb.score_persian("من یک کتاب جالب خواندم."), 100)
        self.assertEqual(mb.score_persian("I read a good book today."), 0)
        self.assertEqual(mb.score_reasoning("۴"), 100)
        self.assertEqual(mb.score_reasoning("12 - 6 - 2 = 4"), 100)
        self.assertEqual(mb.score_reasoning("می‌شه 6"), 0)
        self.assertGreater(mb.score_speed(1200), mb.score_speed(9000))

    def test_profile_needs_three_answers(self):
        self.assertIsNone(mb.build_profile({"chat": "سلام"}, [900]))
        p = mb.build_profile({"tool_format": GOOD, "followup": GOOD, "chat": "سلام", "persian": "یک کتاب", "reasoning": "4"}, [1000] * 5)
        self.assertEqual(p["overall"], 100)


class Routing(unittest.TestCase):
    def test_measured_profile_beats_the_name_guess(self):
        weak_name = {"id": "a", "provider": "groq", "model": "llama-3.1-8b-instant"}
        strong_name = {"id": "b", "provider": "google", "model": "gemini-2.5-flash"}
        profiles = {"groq/llama-3.1-8b-instant": {"ts": 9e9, "scores": {"tool_format": 100, "followup": 100, "persian": 100, "speed": 100, "chat": 100}},
                    "google/gemini-2.5-flash": {"ts": 9e9, "scores": {"tool_format": 0, "followup": 0, "persian": 40, "speed": 55, "chat": 100}}}
        self.assertGreater(smart.route_score(weak_name, "tools", profiles, now=1.0), smart.route_score(strong_name, "tools", profiles, now=1.0))
        self.assertGreater(smart.route_score(strong_name, "tools", {}), smart.route_score(weak_name, "tools", {}))
        old = {"groq/llama-3.1-8b-instant": {"ts": 1.0, "scores": {"tool_format": 100}}}
        self.assertEqual(smart.route_score(weak_name, "tools", old, now=9e9), smart.route_score(weak_name, "tools", {}))

    def test_run_stores_profile_with_a_fake_provider(self):
        import threading, time
        from kira import smart as s
        replies = {"tool": GOOD, "chat": "سلام! خوبم.", "persian": "این یک کتاب است.", "reasoning": "4"}

        class Prov:
            def stream(self_, messages, system, temp, on_connect=None, max_tokens=None):
                last = messages[-1]["content"]
                if "سلام، حالت" in last:
                    yield replies["chat"]
                elif "کتاب" in last:
                    yield replies["persian"]
                elif "سیب" in last:
                    yield replies["reasoning"]
                else:
                    yield replies["tool"]

        class R:
            _lock = threading.Lock()
            _cancel = threading.Event()
            def routes(self_): return [{"id": "r1", "provider": "groq", "model": "m1"}]
            def route_info(self_, r): return {"route_id": "r1", "provider": "groq", "label": "Groq", "model": "m1", "kind": "cloud"}
            def _make_provider(self_, r): return Prov()

        with tempfile.TemporaryDirectory() as d, mock.patch.object(s, "DATA_DIR", Path(d)):
            rows = mb.run(R(), ["r1"], sleep=lambda x: None)
            self.assertTrue(rows[0]["ok"])
            self.assertEqual(rows[0]["profile"]["overall"], 100)
            self.assertIn("groq/m1", s.load_profiles())
            self.assertIn("امتیاز کل 100", mb.format_row(rows[0]))


if __name__ == "__main__":
    unittest.main()
