import tempfile
import unittest
from types import SimpleNamespace as NS

from tests import helpers  # noqa: F401
from kira import experience as ex
from kira import smart


def tool(name):
    return NS(name=name, categories=("apps",))


def res(status="ok", args=None):
    return NS(status=status, kind="", args=args or {})


class FewShot(unittest.TestCase):
    def setUp(self):
        ex.configure(tempfile.mkdtemp(prefix="kira_fs_"), {"experience_memory": "auto"})
        ex._ready = None
        ex._buffer.clear()

    def run_turn(self, request, name, status, args, verifies):
        ex.observe(tool(name), res(status, args), verifies=verifies)
        ex.flush(request)

    def test_verified_example_is_shown_and_private_args_are_not_kept(self):
        self.run_turn("اج رو باز کن و claude.ai رو بیار", "open_app", "ok",
                      {"name": "msedge", "url": "claude.ai", "text": "SECRET-TEXT", "path": "C:\\Users\\me\\x"}, True)
        lines = ex.example_lines("کلاود رو توی اج باز کن claude.ai")
        self.assertEqual(len(lines), 1)
        self.assertIn('"name": "msedge"', lines[0])
        self.assertNotIn("SECRET", lines[0])
        self.assertNotIn("Users", lines[0])

    def test_unverified_example_waits_for_second_run(self):
        self.run_turn("ولوم رو بیار پایین", "set_volume", "ok", {"percent": 30}, False)
        self.assertEqual(ex.example_lines("ولوم رو بیار پایین"), [])
        with ex._db() as con:
            con.execute("UPDATE examples SET last_confirm = last_confirm - 120")
        self.run_turn("ولوم رو بیار پایین", "set_volume", "ok", {"percent": 30}, False)
        self.assertEqual(len(ex.example_lines("ولوم رو بیار پایین")), 1)

    def test_failure_or_secret_request_is_not_stored(self):
        self.run_turn("اج رو باز کن", "open_app", "error", {"name": "msedge"}, True)
        self.run_turn("AIza" + "x" * 35 + " باز کن", "open_app", "ok", {"name": "msedge"}, True)
        self.assertEqual(ex.example_lines("اج رو باز کن"), [])


class Retry(unittest.TestCase):
    def test_excuse_detection(self):
        self.assertTrue(smart.is_excuse("چون من دستم به موس و کیبوردت نمی‌رسه، خودت یه تب جدید باز کن"))
        self.assertTrue(smart.is_excuse("I can't open it, you can just click the icon."))
        self.assertTrue(smart.is_excuse("اینم کد:\n```python\nprint(1)\n```"))
        self.assertFalse(smart.is_excuse("باز کردم، Edge الان جلوته."))
        self.assertFalse(smart.is_excuse("x" * 700 + " نمی‌تونم"))

    def test_hold_emit(self):
        got = []
        h = smart.HoldEmit(got.append)
        h("a"); h("b")
        h.discard()
        h("c")
        h.flush()
        self.assertEqual(got, ["c"])


if __name__ == "__main__":
    unittest.main()


class RetryLoop(unittest.TestCase):
    """The agent loop: an excuse on a tool turn is replaced silently by one retry on the next-best route."""

    def make(self, replies):
        from pathlib import Path
        from kira.tools.agent import ToolAgent, ToolPlan
        agent = ToolAgent(helpers.fresh_settings(), Path(tempfile.mkdtemp()), helpers.ROOT)
        used = []

        class Router:
            settings = {}
            def routes(self_):
                return [{"id": "weak", "provider": "groq", "model": "llama-3.1-8b-instant"},
                        {"id": "strong", "provider": "google", "model": "gemini-2.5-flash"}]
            def eligibility(self_, r):
                return True, "ok"
            def role_scope(self_, role, rid):
                import contextlib
                used.append(rid)
                return contextlib.nullcontext()
            def chat_stream(self_, msgs, prompt, temp, on_chunk=None, on_event=None, retry_index=0):
                text = replies.pop(0)
                on_chunk(text)
                return {"text": text, "stopped": False, "interrupted": None, "route_id": "weak" if not used else used[-1]}

        return agent, Router(), ToolPlan({"time"}, True), used

    def test_excuse_is_retried_silently(self):
        call = '<kira_tool>{"tool":"get_datetime","args":{}}</kira_tool>'
        agent, router, plan, used = self.make(["نمی‌تونم این کار رو بکنم، خودت بزن", call, "الان ساعت رو گرفتم."])
        shown = []
        res = agent.run(router, [{"role": "user", "content": "ساعت چنده؟"}], "sys", 0.3, plan, on_chunk=shown.append)
        self.assertEqual(used, ["strong"])
        self.assertNotIn("نمی‌تونم", "".join(shown))
        self.assertIn("ساعت", res["text"])
        self.assertTrue(res["tools"])

    def test_normal_answer_is_not_retried_and_still_shown(self):
        agent, router, plan, used = self.make(["سلام! چطور کمکت کنم؟"])
        shown = []
        res = agent.run(router, [{"role": "user", "content": "سلام"}], "sys", 0.3, plan, on_chunk=shown.append)
        self.assertEqual(used, [])
        self.assertEqual("".join(shown), "سلام! چطور کمکت کنم؟")
        self.assertEqual(res["text"], "سلام! چطور کمکت کنم؟")

    def test_second_excuse_is_shown_honestly(self):
        agent, router, plan, used = self.make(["نمی‌تونم", "واقعاً ابزاری برای این کار نیست و نمی‌تونم انجامش بدم."])
        shown = []
        res = agent.run(router, [{"role": "user", "content": "x"}], "sys", 0.3, plan, on_chunk=shown.append)
        self.assertEqual(len(used), 1)
        self.assertIn("ابزاری", "".join(shown))
