"""T5-B Desktop Interaction: the policy layer is tested with a fake backend (the real Win32 / UI Automation calls need Windows)."""
import unittest

from kira.tools.builtin import build_registry
from kira.tools.access import PathPolicy
from kira.tools.desktop import DesktopModule, DesktopTools, parse_combo
from kira.tools.registry import OK, NEEDS_CONFIRM, DENIED, ERROR
from kira.tools.registry import ToolError


class FakeBackend:
    def __init__(self):
        self.wins = [
            {"hwnd": 1, "title": "Untitled - Notepad", "pid": 10, "process": "notepad.exe", "minimized": False, "maximized": False},
            {"hwnd": 2, "title": "Google - Chrome", "pid": 11, "process": "chrome.exe", "minimized": False, "maximized": False},
            {"hwnd": 3, "title": "Kira", "pid": 99, "process": "python.exe", "minimized": False, "maximized": False},
            {"hwnd": 4, "title": "Windows PowerShell", "pid": 12, "process": "powershell.exe", "minimized": False, "maximized": False},
            {"hwnd": 5, "title": "Sign in to your account - Edge", "pid": 13, "process": "msedge.exe", "minimized": False, "maximized": False},
            {"hwnd": 6, "title": "Docs - Chrome", "pid": 14, "process": "chrome.exe", "minimized": False, "maximized": False},
        ]
        self.fg = 3
        self.log = []
        self.steal_after = None                # switch the foreground window after N typed chunks
        self.close_works = True
        self.clip = ""
        self.uia_result = {"ok": True}
        self.refuse_focus = False

    def windows(self):
        return [dict(w) for w in self.wins]

    def foreground(self):
        return self.fg

    def is_window(self, h):
        return any(w["hwnd"] == h for w in self.wins)

    def activate(self, h):
        if self.refuse_focus:
            return False, "blocked"
        self.fg = h
        return True, "ok"

    def close(self, h):
        self.log.append(("close", h))
        if self.close_works:
            self.wins = [w for w in self.wins if w["hwnd"] != h]

    def show(self, h, state):
        for w in self.wins:
            if w["hwnd"] == h:
                w["minimized"], w["maximized"] = state == "minimize", state == "maximize"

    def type_text(self, text):
        self.log.append(("type", text))
        if self.steal_after is not None:
            self.steal_after -= 1
            if self.steal_after <= 0:
                self.fg = 2

    def press(self, vks):
        self.log.append(("press", vks))

    def click(self, x, y):
        self.log.append(("click", x, y))

    def window_rect(self, h):
        return 100, 100, 900, 700

    def clipboard_get(self):
        return self.clip

    def clipboard_set(self, text):
        self.clip = text

    def uia(self, args):
        self.log.append(("uia", args["mode"], args.get("name")))
        return self.uia_result


class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.be = FakeBackend()
        self.tools = DesktopTools(self.be, own_pid=99, sleep=lambda s: None)
        from kira.tools.registry import ToolRegistry
        self.reg = ToolRegistry()
        from kira.tools.wincontrol import WindowsControlLayer
        self.layer = WindowsControlLayer(self.reg)
        self.layer.register_module(DesktopModule(self.tools))
        self.reg.user_text = "type close click press"

    def run_tool(self, name, args, text=None, confirmed=False):
        if text is not None:
            self.reg.user_text = text
        return self.reg.execute(name, args, confirmed=confirmed)

    def test_window_list_hides_kira_and_resolves_aliases_and_ambiguity(self):
        self.assertNotIn("Kira", self.run_tool("window_list", {}).text.replace("hwnd", ""))
        self.assertEqual(self.tools.resolve("notepad")["hwnd"], 1)
        self.assertEqual(self.tools.resolve("نوت پد")["hwnd"], 1)
        self.assertEqual(self.tools.resolve("hwnd:6")["hwnd"], 6)
        with self.assertRaises(ToolError) as cm:
            self.tools.resolve("مرورگر")                                                  # two Chrome windows (and Edge)
        self.assertIn("hwnd:2", str(cm.exception))
        with self.assertRaises(ToolError):
            self.tools.resolve("nothing like this")

    def test_type_text_focuses_verifies_and_reports_honestly(self):
        res = self.run_tool("type_text", {"window": "notepad", "text": "سلام دنیا"}, "لطفا تایپ کن")
        self.assertEqual(res.status, OK, res.text)
        self.assertEqual(self.be.fg, 1)
        self.assertIn(("type", "سلام دنیا"), self.be.log)
        self.assertIn("قابل بررسی نیست", res.text)

    def test_never_types_into_shells_security_windows_kira_or_secret_text(self):
        for target in ("hwnd:4", "powershell", "hwnd:5", "hwnd:3"):
            res = self.run_tool("type_text", {"window": target, "text": "hello"}, "type it")
            self.assertEqual(res.status, DENIED, target)
        self.assertEqual(self.run_tool("type_text", {"window": "notepad", "text": "sk-" + "a" * 30}, "type it").status, DENIED)
        self.assertEqual([x for x in self.be.log if x[0] == "type"], [])

    def test_typing_stops_when_the_foreground_window_changes(self):
        self.be.steal_after = 1
        res = self.run_tool("type_text", {"window": "notepad", "text": "x" * 120}, "type it")
        self.assertEqual(res.status, ERROR)
        self.assertEqual(len([x for x in self.be.log if x[0] == "type"]), 1)             # only the first chunk went out

    def test_focus_failure_means_nothing_is_typed(self):
        self.be.refuse_focus = True
        self.assertEqual(self.run_tool("type_text", {"window": "notepad", "text": "hi"}, "type it").status, ERROR)
        self.assertEqual(self.be.log, [])

    def test_intent_guard(self):
        self.assertEqual(self.run_tool("window_close", {"window": "notepad"}, "what is the weather").status, DENIED)
        self.assertEqual(self.run_tool("type_text", {"window": "notepad", "text": "hi"}, "what is the weather").status, DENIED)
        self.assertEqual(self.be.log, [])

    def test_close_verifies_and_does_not_lie_when_window_stays(self):
        self.assertIn("بسته شد", self.run_tool("window_close", {"window": "notepad"}, "ببند").text)
        self.be.close_works = False
        res = self.run_tool("window_close", {"window": "hwnd:6"}, "close it")
        self.assertIn("هنوز باز است", res.text)
        self.assertEqual(self.run_tool("window_close", {"window": "hwnd:3"}, "close it").status, DENIED)   # Kira itself is never closed

    def test_key_whitelist(self):
        self.assertEqual(parse_combo("ctrl+s")[1], "ctrl+s")
        self.assertEqual(parse_combo("Enter")[1], "enter")
        for bad in ("win+r", "alt+f4", "ctrl+alt+delete", "ctrl+shift+esc", "ctrl+alt+t", "f13", "ctrl+q", ""):
            with self.assertRaises(ToolError, msg=bad):
                parse_combo(bad)
        self.assertEqual(self.run_tool("press_keys", {"window": "notepad", "keys": "ctrl+s"}, "press ctrl+s").status, OK)
        self.assertEqual(self.run_tool("press_keys", {"window": "powershell", "keys": "enter"}, "press enter").status, DENIED)

    def test_clipboard_read_needs_confirmation_and_masks_secrets(self):
        self.be.clip = "note sk-" + "b" * 30
        self.assertEqual(self.run_tool("clipboard_get", {}).status, NEEDS_CONFIRM)
        out = self.run_tool("clipboard_get", {}, confirmed=True).text
        self.assertNotIn("b" * 30, out)
        self.assertEqual(self.run_tool("clipboard_set", {"text": "hello"}, "copy hello").status, OK)
        self.assertEqual(self.be.clip, "hello")

    def test_dangerous_controls_only_through_the_confirmed_twin(self):
        self.be.uia_result = {"ok": True, "how": "invoke", "target": {"name": "Delete all"}}
        self.assertEqual(self.run_tool("ui_click", {"window": "notepad", "control": "Delete all"}, "click delete all").status, DENIED)
        self.assertEqual(self.run_tool("ui_click", {"window": "notepad", "control": "حذف همه"}, "click it").status, DENIED)
        self.assertEqual(self.run_tool("ui_click_confirmed", {"window": "notepad", "control": "Delete all"}).status, NEEDS_CONFIRM)
        self.assertEqual(self.run_tool("ui_click_confirmed", {"window": "notepad", "control": "Delete all"}, confirmed=True).status, OK)
        self.be.uia_result = {"ok": True, "how": "invoke", "target": {"name": "Bold"}}
        self.assertEqual(self.run_tool("ui_click", {"window": "notepad", "control": "Bold"}, "click bold").status, OK)

    def test_uia_errors_are_reported_and_password_fields_are_refused(self):
        for err in ("not_found", "password", "disabled", "no_pattern"):
            self.be.uia_result = {"ok": False, "error": err}
            self.assertEqual(self.run_tool("ui_click", {"window": "notepad", "control": "Name"}, "click it").status in (ERROR, DENIED), True, err)
        self.be.uia_result = {"ok": True, "how": "value", "value_after": "different", "target": {"name": "Search"}}
        self.assertEqual(self.run_tool("ui_set_text", {"window": "notepad", "control": "Search", "text": "abc"}, "type abc").status, ERROR)   # read-back mismatch
        self.be.uia_result = {"ok": True, "how": "value", "value_after": "abc", "target": {"name": "Search"}}
        self.assertEqual(self.run_tool("ui_set_text", {"window": "notepad", "control": "Search", "text": "abc"}, "type abc").status, OK)

    def test_mouse_click_is_confirmed_and_bounds_checked(self):
        self.assertEqual(self.run_tool("mouse_click", {"window": "notepad", "x": 10, "y": 10}).status, NEEDS_CONFIRM)
        self.assertEqual(self.run_tool("mouse_click", {"window": "notepad", "x": 5000, "y": 10}, confirmed=True).status, ERROR)
        self.assertEqual(self.run_tool("mouse_click", {"window": "notepad", "x": 10, "y": 20}, confirmed=True).status, OK)
        self.assertIn(("click", 110, 120), self.be.log)

    def test_set_state_is_verified(self):
        self.assertEqual(self.run_tool("window_set_state", {"window": "notepad", "state": "minimize"}, "minimize it").status, OK)

    def test_gate_words_and_layer_registration(self):
        from kira.tools import protocol
        self.assertIn("desktop", protocol.detect_categories("پنجره مرورگر را ببند"))
        self.assertIn("desktop", protocol.detect_categories("متن را تایپ کن"))
        self.assertIn("type_text", {c.name for c in self.layer.capabilities()})
        real = build_registry(PathPolicy({}, None, None))                                      # the real module is registered with the Win32 backend
        for name in ("window_list", "type_text", "ui_click", "clipboard_get", "mouse_click"):
            self.assertIsNotNone(real.get(name), name)


if __name__ == "__main__":
    unittest.main()
