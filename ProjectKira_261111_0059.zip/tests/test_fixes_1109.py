import unittest
from kira import api_manager as am
from kira.tools import protocol
from kira.tools.imagetool import saved_path
from kira.tools.apps import browser_key


class Fixes1109(unittest.TestCase):
    def test_new_google_auth_key_is_google(self):
        self.assertEqual(am.candidate_services("AQ.Ab8RN6" + "x" * 40), ["google"])
        self.assertEqual(am.candidate_services("AIza" + "x" * 35), ["google"])

    def test_pseudo_call_becomes_real_call(self):
        calls, errs = protocol.parse_calls('<teasing:70>\n[open_app: name="msedge", url="claude.ai"]')
        self.assertEqual(calls[0]["tool"], "open_app")
        self.assertEqual(calls[0]["args"], {"name": "msedge", "url": "claude.ai"})
        g = protocol.ToolGate(lambda s: None)
        for ch in '<teasing:70>\n[open_app: name="msedge", url="claude.ai"]':
            g.feed(ch)
        g.finish()
        self.assertTrue(g.is_call)
        self.assertEqual(g.visible, "")

    def test_emotion_tag_text_is_not_a_call(self):
        g = protocol.ToolGate(lambda s: None)
        for ch in "[happy] سلام":
            g.feed(ch)
        g.finish()
        self.assertFalse(g.is_call)

    def test_saved_path(self):
        self.assertEqual(saved_path("ok (VERIFIED: PNG، 3 KB): C:\\P\\a.png\nx"), "C:\\P\\a.png")

    def test_browser_names(self):
        self.assertEqual(browser_key("msedge"), "edge")
        self.assertEqual(browser_key("اج"), "edge")
        self.assertEqual(browser_key("بریو"), "brave")
        self.assertIsNone(browser_key("notepad"))

    def test_edge_gate(self):
        self.assertIn("apps", protocol.detect_categories("کلاد رو توی اج بیار بالا"))


if __name__ == "__main__":
    unittest.main()
