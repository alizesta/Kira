import hashlib
import io
import json
import re
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from tests import helpers
from tests.helpers import ROOT, CANARY
import install_deps
from kira import memory, config

KEY_PATTERNS = [r"gsk_[A-Za-z0-9]{20,}", r"sk-or-v1-[A-Za-z0-9]{20,}", r"AIza[0-9A-Za-z_\-]{30,}",
                r"sk-[A-Za-z0-9]{32,}", r"Bearer\s+[A-Za-z0-9_\-]{30,}", re.escape(CANARY)]
# Local-only folders that exist on a machine where the program was installed or tested (install.bat creates .venv and .uvboot, Python
# writes __pycache__, ruff writes .ruff_cache). They belong to a working folder, never to a release.
SKIP_DIRS = {".venv", "__pycache__", "data", ".git", ".uvboot", ".ruff_cache", ".pytest_cache", ".mypy_cache"}


def project_files(root=ROOT):
    for p in root.rglob("*"):
        if p.is_file() and not (set(p.relative_to(root).parts) & SKIP_DIRS):
            yield p


class ReleaseTests(unittest.TestCase):
    # 4) no secrets in the shipped tree (the release script runs the same scan on the final ZIP)
    def test_04_no_api_keys_in_sources(self):
        hits = []
        for p in project_files():
            if p.suffix.lower() in (".png", ".pyc") or p.name.startswith("test_release"):
                continue
            text = p.read_text(encoding="utf-8", errors="ignore")
            in_tests = p.relative_to(ROOT).parts[0] == "tests"
            for pat in KEY_PATTERNS:
                if in_tests and pat == re.escape(CANARY):
                    continue                      # the canary constant legitimately lives in the tests themselves
                if re.search(pat, text):
                    hits.append((str(p.relative_to(ROOT)), pat))
        self.assertEqual(hits, [])

    def test_04b_no_user_data_shipped(self):
        """No user data inside the program folder. (`.venv` is NOT checked here: install.bat creates it right next to this file and
        run_tests.bat refuses to run without it, so on a real Windows install it always exists. That it never ships is checked on the
        release file set in the next test.)"""
        data = ROOT / "data"
        in_use = data.exists() and data.samefile(config.DATA_DIR)           # the non-Windows dev fallback uses ./data on purpose
        for forbidden in ("settings.json", "kira_memory.sqlite3", "kira_evidence.sqlite3", "cloud_voice.json"):
            if (data / forbidden).exists() and not in_use:
                self.fail(f"user data inside the program folder: data/{forbidden}")
        for stray in ROOT.glob("*.sqlite3"):
            self.fail(f"database inside the program folder: {stray.name}")

    def test_04c_release_file_set_never_contains_the_virtualenv_or_local_caches(self):
        """The set of files that goes into a release (project_files) must skip .venv / .uvboot / caches / data - even when they exist."""
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            for p in project_files():
                z.write(p, p.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as z:
            names = z.namelist()
        self.assertTrue(names, "release file set is empty")
        bad = [n for n in names if set(n.split("/")[:-1]) & SKIP_DIRS]
        self.assertEqual(bad, [])
        for must in ("README.md", "run_tests.bat", "kira/config.py"):
            self.assertIn(must, names)

    def test_04d_skip_rules_really_skip_a_virtualenv(self):
        """Self-check of the filter on a throw-away tree shaped like an installed folder, so test_04c cannot pass merely because this
        machine has no .venv. Nothing is written into the program folder."""
        import tempfile
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root = Path(tmp)
            for rel in (".venv/Scripts/python.exe", ".uvboot/Scripts/uv.exe", "kira/__pycache__/x.pyc", "data/settings.json",
                        "kira/config.py", "README.md"):
                f = root / rel
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_bytes(b"x")
            names = sorted(p.relative_to(root).as_posix() for p in project_files(root))
        self.assertEqual(names, ["README.md", "kira/config.py"])

    def test_version(self):
        self.assertEqual(config.VERSION, "1 stable")

    # 15) real SQLite history is provider-neutral and ordered
    def test_15_memory_context_is_ordered_and_bounded(self):
        memory.init_db()
        memory.clear_memory()
        for i in range(30):
            memory.add_message("user" if i % 2 == 0 else "assistant", f"m{i}")
        ctx = memory.conversation_context(limit=12)
        self.assertEqual([m["content"] for m in ctx], [f"m{i}" for i in range(18, 30)])
        memory.clear_memory()
        memory.add_message("user", "x" * 9000)
        memory.add_message("assistant", "y" * 9000)
        self.assertLessEqual(sum(len(m["content"]) for m in memory.conversation_context(12, max_chars=12000)), 12000)

    # dependency installer: names the failing package, never reports success on failure
    def test_install_deps_reports_failed_package_and_dns_hint(self):
        req = config.DATA_DIR / "req_test.txt"
        req.write_text("# comment\nPySide6>=6.7,<7\nrequests>=2.31,<3\nnumpy>=1.26\n", encoding="utf-8")
        log = []

        def runner(args):
            joined = " ".join(args)
            if args[0] == "-r":
                return 1, "ERROR: bulk failed"
            if "numpy" in joined:
                return 1, "NameResolutionError: Failed to resolve 'files.pythonhosted.org'"
            return 0, "ok"
        code = install_deps.install(str(req), runner=runner, out=log.append)
        text = "\n".join(log)
        self.assertEqual(code, 1)
        self.assertIn("FAILED PACKAGES: numpy>=1.26", text)
        self.assertIn("DNS", text)
        self.assertNotIn("PySide6", text.split("FAILED PACKAGES:")[1].splitlines()[0])

    def test_install_deps_success_and_empty(self):
        req = config.DATA_DIR / "req_ok.txt"
        req.write_text("requests>=2.31,<3\n", encoding="utf-8")
        self.assertEqual(install_deps.install(str(req), runner=lambda a: (0, "ok"), out=lambda s: None), 0)
        empty = config.DATA_DIR / "req_empty.txt"
        empty.write_text("# nothing\n", encoding="utf-8")
        self.assertEqual(install_deps.install(str(empty), runner=lambda a: (0, "ok"), out=lambda s: None), 1)

    def test_requirements_contain_no_unneeded_packages(self):
        names = {re.split(r"[<>=]", l)[0].strip().lower() for l in (ROOT / "requirements.txt").read_text().splitlines() if l.strip()}
        self.assertEqual(names, {"pyside6", "requests", "numpy", "psutil"})  # psutil is optional (Kira works without it) but is listed on purpose

    def test_bat_files_keep_crlf_and_call_installer(self):
        for name in ("install.bat", "download_model.bat", "start_kira.bat", "run_tests.bat"):
            raw = (ROOT / name).read_bytes()
            self.assertEqual(raw.count(b"\n"), raw.count(b"\r\n"), name)
            self.assertTrue(all(b < 128 for b in raw), name + " must stay ASCII for CMD")
        self.assertIn(b"install_deps.py", (ROOT / "install.bat").read_bytes())
        self.assertIn(b"qwen3.5:4b", (ROOT / "download_model.bat").read_bytes())


if __name__ == "__main__":
    unittest.main()
