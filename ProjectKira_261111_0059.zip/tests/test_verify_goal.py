import tempfile
import unittest
from pathlib import Path

from tests import helpers  # noqa: F401
from kira.tools import apps, tasks


def win(hwnd, title, process="msedge.exe"):
    return {"hwnd": hwnd, "title": title, "pid": hwnd, "process": process}


class Clock:
    def __init__(self):
        self.t = 0.0
    def now(self):
        return self.t
    def sleep(self, s):
        self.t += s


class BrowserCheck(unittest.TestCase):
    def run_check(self, before, timeline, key="edge", url="https://claude.ai"):
        clk, step = Clock(), {"i": 0}

        def windows():
            i = min(int(clk.t / 0.5), len(timeline) - 1)
            return timeline[i]
        return apps.browser_check(key, url, apps.browser_windows(before, key), windows, sleep=clk.sleep, seconds=8.0, clock=clk.now)

    def test_site_named_in_new_title_is_matched(self):
        state, w = self.run_check([win(1, "Google - Microsoft Edge")], [[win(1, "Google - Microsoft Edge")], [win(1, "Claude - Microsoft Edge")]])
        self.assertEqual(state, "matched")
        self.assertIn("بازخوانی شد", apps.browser_report(state, w, "edge", "https://claude.ai"))

    def test_other_browser_windows_are_ignored(self):
        state, _ = self.run_check([], [[win(5, "Claude - Brave", "brave.exe")]])
        self.assertEqual(state, "none")

    def test_new_window_with_unrelated_title_is_not_confirmed(self):
        state, w = self.run_check([], [[win(7, "New tab - Microsoft Edge")]])
        self.assertEqual(state, "changed")
        rep = apps.browser_report(state, w, "edge", "https://claude.ai")
        self.assertIn("تأیید نشد", rep)

    def test_nothing_changed_is_unverified_and_site_already_open_is_said_so(self):
        same = [win(1, "Docs - Microsoft Edge")]
        state, w = self.run_check(same, [same])
        self.assertEqual(state, "none")
        self.assertIn("پنجره‌ی جدیدی دیده نشد", apps.browser_report(state, w, "edge", "https://claude.ai"))
        open_already = [win(1, "Claude - Microsoft Edge")]
        state, w = self.run_check(open_already, [open_already])
        self.assertEqual(state, "already")
        self.assertNotIn("تأیید نشد", apps.browser_report(state, w, "edge", "https://claude.ai").split("؛")[0])

    def test_verdicts(self):
        unver = apps.browser_report("none", None, "edge", "https://claude.ai")
        self.assertEqual(tasks.verify("open_url", {}, "ok", unver, level=2, verifies=False)[0], "unverified")
        ok = apps.browser_report("matched", win(1, "Claude - Microsoft Edge"), "edge", "https://claude.ai")
        self.assertEqual(tasks.verify("open_url", {}, "ok", ok, level=2, verifies=False)[0], "ok")


class HonestyGuard(unittest.TestCase):
    def agent(self):
        from kira.tools.agent import ToolAgent
        return ToolAgent(helpers.fresh_settings(), Path(tempfile.mkdtemp()), helpers.ROOT)

    def result(self, text):
        from kira.tools.registry import ToolResult, OK
        return ToolResult(tool="open_url", status=OK, text=text, args={"url": "claude.ai"}, level=2)

    def test_false_success_gets_a_footnote_but_honest_answers_do_not(self):
        a = self.agent()
        bad = self.result(apps.browser_report("none", None, "edge", "https://claude.ai"))
        shown = []
        out = a._honesty_footer("باز کردم، Edge الان جلوته.", [bad], shown.append)
        self.assertIn("⚠️", out)
        self.assertEqual(len(shown), 1)
        honest = a._honesty_footer("دستور رو فرستادم ولی تأیید نشد که باز شده.", [bad], shown.append)
        self.assertNotIn("⚠️", honest)
        good = self.result(apps.browser_report("matched", win(1, "Claude - Microsoft Edge"), "edge", "https://claude.ai"))
        self.assertNotIn("⚠️", a._honesty_footer("باز کردم.", [good], shown.append))

    def test_results_message_carries_the_code_verdict(self):
        a = self.agent()
        msg = a._results_message([self.result(apps.browser_report("none", None, "edge", "https://claude.ai"))])
        self.assertIn("VERIFICATION by code", msg)
        self.assertIn("UNVERIFIED", msg)


if __name__ == "__main__":
    unittest.main()
