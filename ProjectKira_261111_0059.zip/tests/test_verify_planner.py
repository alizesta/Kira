"""Verification upgrade (tasks.verify) and plan review (planner.lint). No network, no model."""
import tempfile
import unittest
from types import SimpleNamespace as NS

from tests import helpers  # noqa: F401
from kira import experience as ex
from kira.tools import planner, tasks
from kira.tools.tasks import TaskPlan, Step, verify, SKIPPED


class FakeAccess:
    def policy_for(self, tool):
        return NS(verifies=bool(getattr(tool, "verifies_result", False)))


class FakeRegistry:
    def __init__(self, *tools):
        self._t = {t.name: t for t in tools}
        self.access = FakeAccess()

    def get(self, name):
        return self._t.get(name)


def T(name, level, verifies=False):
    return NS(name=name, level=level, verifies_result=verifies)


class VerifyTests(unittest.TestCase):
    def test_tool_saying_unverified_is_unverified(self):
        v, _ = verify("x", {}, "ok", "ذخیره شد ولی بررسی نشد (UNVERIFIED)")
        self.assertEqual(v, "unverified")

    def test_verified_marker_is_ok(self):
        v, _ = verify("x", {}, "ok", "ساخته شد (VERIFIED: فایل معتبر)", level=2, verifies=False)
        self.assertEqual(v, "ok")

    def test_action_without_reread_is_unverified(self):
        v, note = verify("x", {}, "ok", "انجام شد.", level=2, verifies=False)
        self.assertEqual(v, "unverified")
        self.assertIn("not confirmed", note)

    def test_action_that_rereads_is_ok(self):
        self.assertEqual(verify("x", {}, "ok", "انجام شد.", level=2, verifies=True)[0], "ok")

    def test_read_zero_results_is_flagged_but_ok(self):
        v, note = verify("x", {}, "ok", "0 مورد", level=1, verifies=False)
        self.assertEqual(v, "ok")
        self.assertIn("nothing", note)

    def test_old_call_style_unchanged(self):
        self.assertEqual(verify("x", {}, "ok", "ok body")[0], "ok")
        self.assertEqual(verify("search_files", {}, "ok", "فایلی با این مشخصات پیدا نشد")[0], "unmet")
        self.assertEqual(verify("x", {}, "error", "bad")[0], "unmet")


class LintTests(unittest.TestCase):
    def setUp(self):
        self.reg = FakeRegistry(T("read_a", 1), T("act_b", 2), T("act_ok", 2, True), T("sens_c", 3))

    def steps(self, *tools):
        return [Step(i, f"s{i}", t) for i, t in enumerate(tools, 1)]

    def test_action_without_recheck_warns(self):
        notes = planner.lint(self.steps("act_b"), self.reg)
        self.assertEqual(len(notes), 1)
        self.assertIn("act_b", notes[0])

    def test_later_read_step_silences_it(self):
        self.assertEqual(planner.lint(self.steps("act_b", "read_a"), self.reg), [])

    def test_self_verifying_action_is_fine(self):
        self.assertEqual(planner.lint(self.steps("act_ok"), self.reg), [])

    def test_avoid_tool_warns(self):
        notes = planner.lint(self.steps("read_a"), self.reg, avoid={"read_a": "missing_component"})
        self.assertTrue(any("read_a" in n and "permanent" in n for n in notes))

    def test_skill_gap_warns_and_full_match_does_not(self):
        reg = FakeRegistry(T("a", 1), T("b", 1), T("c", 1))
        self.assertTrue(planner.lint(self.steps("a", "b"), reg, skills=[["a", "b", "c"]]))
        self.assertEqual(planner.lint(self.steps("a", "b", "c"), reg, skills=[["a", "b", "c"]]), [])

    def test_skipped_steps_ignored_and_cap(self):
        st = self.steps("act_b")
        st[0].status = SKIPPED
        self.assertEqual(planner.lint(st, self.reg), [])
        many = self.steps(*["act_b"] * 9)
        self.assertLessEqual(len(planner.lint(many, self.reg)), planner.MAX_CHECKS)

    def test_checks_persist_and_render(self):
        p = TaskPlan("1", "g")
        p.checks = ["note one"]
        self.assertIn("PLAN CHECKS", p.render_state())
        self.assertEqual(TaskPlan.from_dict(p.to_dict()).checks, ["note one"])
        self.assertEqual(TaskPlan.from_dict({"id": "2", "goal": "g"}).checks, [])      # a task file from the previous version still loads


class ExperienceHelperTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="kira_vp_")
        ex.configure(self.dir, {"experience_memory": "auto"})
        ex._ready = None
        ex._buffer.clear()

    def test_empty_store_returns_nothing(self):
        self.assertEqual(ex.avoid_tools(), {})
        self.assertEqual(ex.matching_skills("wifi fix please"), [])

    def test_permanent_failures_surface_only_without_success(self):
        for _ in range(ex.PERSISTENT_MIN):
            ex.observe(NS(name="bt_on", categories=("devices",)), NS(status="error", kind="unsupported_hardware", args={}), verifies=True, tainted=False)
            ex.flush("turn bluetooth on", False)
        self.assertEqual(ex.avoid_tools(), {"bt_on": "unsupported_hardware"})
        self.assertEqual(ex.avoid_tools(lambda n: False), {})


if __name__ == "__main__":
    unittest.main()
