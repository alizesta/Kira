import tempfile
import unittest
from pathlib import Path

from tests import helpers  # noqa: F401
from kira import hybrid_ai as h
from kira.tools import protocol

SCHEMAS = [{"name": "open_url", "description": "open", "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}}]


def make(objs, name="groq", fail=None):
    """A Groq-style provider whose network layer is replaced by scripted SSE objects (they still go through the real `extract`)."""
    p = h.GroqProvider({"api_key": "k", "model": "m"}, name=name)
    seen = {}

    def fake_sse(url, headers, payload, extract, on_connect=None):
        seen.setdefault("payloads", []).append(payload)
        if fail and "tools" in payload:
            raise h.ProviderError(name, "bad request: tools not supported", False, status_code=400, kind="request")
        for o in objs:
            piece = extract(o)
            if piece:
                yield piece

    p._stream_sse = fake_sse
    p.native_tools = SCHEMAS
    return p, seen


def delta(**kw):
    return {"choices": [{"delta": kw}]}


class NativeTools(unittest.TestCase):
    def run_stream(self, p):
        return "".join(p.stream([{"role": "user", "content": "x"}], "sys", 0.2))

    def test_fragmented_tool_call_becomes_the_text_protocol_block(self):
        p, seen = make([delta(tool_calls=[{"index": 0, "id": "c1", "function": {"name": "open_url", "arguments": ""}}]),
                        delta(tool_calls=[{"index": 0, "function": {"arguments": '{"url": "https://cla'}}]),
                        delta(tool_calls=[{"index": 0, "function": {"arguments": 'ude.ai", "browser": "edge"}'}}])])
        out = self.run_stream(p)
        calls, errs = protocol.parse_calls(out)
        self.assertEqual(calls[0]["tool"], "open_url")
        self.assertEqual(calls[0]["args"], {"url": "https://claude.ai", "browser": "edge"})
        self.assertEqual(seen["payloads"][0]["tool_choice"], "auto")
        self.assertEqual(seen["payloads"][0]["tools"][0]["function"]["name"], "open_url")
        self.assertFalse(p.native_rejected)

    def test_whole_call_without_index_and_chatter_before_it(self):
        p, _ = make([delta(content="باشه، "), delta(tool_calls=[{"id": "c", "function": {"name": "open_url", "arguments": {"url": "claude.ai"}}}])])
        calls, _e = protocol.parse_calls(self.run_stream(p))
        self.assertEqual(calls[0]["args"], {"url": "claude.ai"})

    def test_normal_answer_streams_and_is_not_a_call(self):
        text = "سلام! من کیرا هستم و خوشحالم که می‌تونم بهت کمک کنم، هر چی لازم داشتی بگو."
        p, _ = make([delta(content=text[:30]), delta(content=text[30:])])
        out = self.run_stream(p)
        self.assertEqual(out, text)
        self.assertNotIn(protocol.OPEN, out)

    def test_service_refusing_tools_falls_back_to_plain_request(self):
        p, seen = make([delta(content="جواب عادی")], fail=True)
        out = self.run_stream(p)
        self.assertEqual(out, "جواب عادی")
        self.assertTrue(p.native_rejected)
        self.assertNotIn("tools", seen["payloads"][-1])

    def test_broken_arguments_are_never_executed(self):
        p, _ = make([delta(tool_calls=[{"index": 0, "id": "c", "function": {"name": "open_url", "arguments": '{"url": "x'}}])])
        with self.assertRaises(h.ProviderError):
            self.run_stream(p)
        self.assertTrue(p.native_rejected)

    def test_unsupported_provider_never_gets_tools(self):
        p, seen = make([delta(content="hi there")], name="openrouter")
        self.run_stream(p)
        self.assertNotIn("tools", seen["payloads"][0])


class Wiring(unittest.TestCase):
    def test_setting_off_and_schemas(self):
        from kira.tools.agent import ToolAgent, ToolPlan
        r = h.HybridRouter(helpers.fresh_settings())
        self.assertEqual(r.native_tools_for(SCHEMAS), SCHEMAS)
        self.assertIsNone(r.native_tools_for([]))
        r.settings["native_tools"] = "off"
        self.assertIsNone(r.native_tools_for(SCHEMAS))
        agent = ToolAgent(helpers.fresh_settings(), Path(tempfile.mkdtemp()), helpers.ROOT)
        names = [s["name"] for s in agent.native_schemas(ToolPlan({"apps", "time"}))]
        self.assertIn("open_app", names)
        self.assertIn("get_datetime", names)


if __name__ == "__main__":
    unittest.main()
