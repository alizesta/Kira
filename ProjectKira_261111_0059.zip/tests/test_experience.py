"""Experience memory, cautious lessons and the data-only Skill Library (kira/experience.py). Runs on a temp folder; no network."""
import tempfile
import time
import unittest
from types import SimpleNamespace as NS

from tests import helpers  # noqa: F401  (redirects the data dir to a temp folder)
from kira import experience as ex


def tool(name, cats=("network",)):
    return NS(name=name, categories=cats)


def res(status="ok", kind="", args=None):
    return NS(status=status, kind=kind, args=args or {})


class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="kira_exp_")
        ex.configure(self.dir, {"experience_memory": "auto"})
        ex._ready = None
        ex._buffer.clear()

    def turn(self, request, calls, tainted=False, gap=True):
        for name, status, kind in calls:
            ex.observe(tool(name), res(status, kind), verifies=True, tainted=tainted)
        out = ex.flush(request, tainted)
        if gap:                                                  # make the next turn a separate one (CONFIRM_GAP)
            self._age()
        return out

    def _age(self):
        if not ex.enabled() or not ex._path().is_file():
            return
        with ex._db() as con:
            for t in ("lessons", "skills"):
                con.execute(f"UPDATE {t} SET last_confirm = last_confirm - 120")


class LessonTests(Base):
    def test_lesson_needs_two_separate_turns(self):
        seq = [("wifi_a", "error", "api_failure"), ("wifi_b", "ok", "")]
        self.turn("wifi connect problem fix", seq)
        self.assertEqual(ex.hints("wifi connect problem fix"), "")           # candidate only
        self.turn("wifi connect problem fix", seq)
        self.assertIn("wifi_b", ex.hints("wifi connect problem fix"))

    def test_burst_does_not_confirm(self):
        seq = [("wifi_a", "error", "api_failure"), ("wifi_b", "ok", "")]
        self.turn("wifi connect problem fix", seq, gap=False)
        self.turn("wifi connect problem fix", seq, gap=False)
        self.assertEqual(ex.hints("wifi connect problem fix"), "")

    def test_tainted_turn_learns_nothing(self):
        seq = [("wifi_a", "error", "api_failure"), ("wifi_b", "ok", "")]
        for _ in range(3):
            self.turn("wifi connect problem fix", seq, tainted=True)
        self.assertEqual(ex.hints("wifi connect problem fix"), "")
        self.assertEqual(ex.stats()["lessons_candidate"], 0)

    def test_off_is_noop(self):
        ex.configure(self.dir, {"experience_memory": "off"})
        self.assertIsNone(self.turn("anything here now", [("a", "ok", "")]))
        self.assertEqual(ex.stats(), {})


class SkillTests(Base):
    REQ = "fix the internet connection please"
    SEQ = [("net_adapter", "ok", ""), ("net_gateway", "ok", ""), ("net_dns", "ok", "")]

    def test_candidate_then_verified_after_two_turns(self):
        self.turn(self.REQ, self.SEQ)
        self.assertEqual(ex.stats()["skills_candidate"], 1)
        self.assertEqual(ex.hints(self.REQ), "")                              # not trusted yet
        self.turn(self.REQ, self.SEQ)
        self.assertEqual(ex.stats()["skills_verified"], 1)
        h = ex.hints("please fix internet connection")
        self.assertIn("«net_adapter» -> «net_gateway» -> «net_dns»", h)

    def test_burst_does_not_verify(self):
        self.turn(self.REQ, self.SEQ, gap=False)
        self.turn(self.REQ, self.SEQ, gap=False)
        self.assertEqual(ex.stats()["skills_verified"], 0)

    def test_failed_or_single_tool_turn_is_not_a_skill(self):
        self.turn(self.REQ, [("net_adapter", "ok", ""), ("net_dns", "error", "timeout")])
        self.turn(self.REQ, [("net_adapter", "ok", "")])
        self.turn(self.REQ, [("a", "ok", ""), ("b", "ok", ""), ("a", "ok", "")])      # loop
        self.turn(self.REQ, [("a", "ok", ""), ("b", "needs_confirmation", "")])
        st = ex.stats()
        self.assertEqual(st["skills_candidate"] + st["skills_verified"], 0)

    def test_tainted_turn_makes_no_skill(self):
        for _ in range(3):
            self.turn(self.REQ, self.SEQ, tainted=True)
        self.assertEqual(ex.stats()["skills_candidate"] + ex.stats()["skills_verified"], 0)

    def test_contradiction_demotes(self):
        self.turn(self.REQ, self.SEQ)
        self.turn(self.REQ, self.SEQ)
        self.assertIn("net_dns", ex.hints(self.REQ))
        self.turn(self.REQ, [("net_adapter", "ok", ""), ("net_dns", "error", "timeout")])
        self.turn(self.REQ, [("net_adapter", "ok", ""), ("net_dns", "error", "timeout")])
        self.assertNotIn("Skill:", ex.hints(self.REQ))

    def test_removed_tool_skips_skill(self):
        self.turn(self.REQ, self.SEQ)
        self.turn(self.REQ, self.SEQ)
        self.assertEqual(ex.hints(self.REQ, lambda n: n != "net_dns"), "")

    def test_skill_holds_only_tool_names(self):
        ex.observe(tool("a"), res("ok", args={"text": "SECRET-PASSWORD-123", "path": "C:/x"}), verifies=True)
        ex.observe(tool("b"), res("ok"), verifies=True)
        ex.flush("do something with secret", False)
        with ex._db() as con:
            dump = " ".join(str(tuple(r)) for t in ("skills", "calls", "episodes") for r in con.execute(f"SELECT * FROM {t}"))
        self.assertNotIn("SECRET-PASSWORD", dump)

    def test_caps_and_forget(self):
        for i in range(ex.MAX_SKILLS + 15):
            self.turn(f"unique{i} topic{i} word{i}", [(f"t{i}a", "ok", ""), (f"t{i}b", "ok", "")])
        self.assertLessEqual(ex.stats()["skills_candidate"] + ex.stats()["skills_verified"], ex.MAX_SKILLS)
        ex.forget_all()
        self.assertEqual(ex.stats()["skills_candidate"] + ex.stats()["skills_verified"], 0)

    def test_old_skill_expires(self):
        self.turn(self.REQ, self.SEQ)
        self.turn(self.REQ, self.SEQ)
        with ex._db() as con:
            con.execute("UPDATE skills SET updated = ?", (time.time() - ex.SKILL_TTL - 10,))
        self.turn("other words entirely different", [("x1", "ok", ""), ("x2", "ok", "")])
        self.assertEqual(ex.stats()["skills_verified"], 0)


if __name__ == "__main__":
    unittest.main()
