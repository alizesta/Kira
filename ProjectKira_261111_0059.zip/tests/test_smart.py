import json, tempfile, unittest
from pathlib import Path
from unittest import mock
from kira import smart


class FakeRouter:
    def __init__(self, routes, bad=()):
        self._r, self.bad = routes, set(bad)
    def routes(self):
        return self._r
    def eligibility(self, r):
        return (r["id"] not in self.bad, "ok")


class SmartTests(unittest.TestCase):
    def test_score_order(self):
        self.assertGreater(smart.model_score("openai/gpt-oss-120b"), smart.model_score("llama-3.1-8b-instant"))
        self.assertGreater(smart.model_score("gemini-2.5-flash"), smart.model_score("gemini-2.5-flash-lite"))

    def test_best_route_for_tools_only(self):
        rs = [{"id": "a", "provider": "groq", "model": "llama-3.1-8b-instant"}, {"id": "b", "provider": "google", "model": "gemini-2.5-flash"},
              {"id": "c", "provider": "mistral", "model": "mistral-large-latest"}]
        r = FakeRouter(rs)
        self.assertEqual(smart.best_route_id(r, {}, "surface", True), "c")
        self.assertEqual(smart.best_route_id(r, {}, "surface", False), "")
        self.assertEqual(smart.best_route_id(FakeRouter(rs, bad=["c"]), {}, "deep", False), "b")
        self.assertEqual(smart.best_route_id(r, {"smart_routing": False}, "deep", True), "")

    def test_followup(self):
        h = smart.followup_hint("خودت انجامش بده", ["کیرا اج رو باز کن و کلود رو بیار بالا"])
        self.assertIn("اج رو باز کن", h)
        self.assertEqual(smart.followup_hint("سلام چطوری", ["x" * 20]), "")

    def test_corrections_roundtrip(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(smart, "DATA_DIR", Path(d)):
            self.assertTrue(smart.observe_user("کد نده خودت انجامش بده", "اج رو باز کن"))
            self.assertTrue(smart.observe_user("کد نده خودت انجامش بده", "x"))
            self.assertFalse(smart.observe_user("سلام", ""))
            self.assertFalse(smart.observe_user("اشتباه کردی AIza" + "x" * 30, ""))
            blk = smart.corrections_block("اج رو باز کن")
            self.assertIn("کد نده", blk)
            self.assertIn("×2", blk)
            self.assertEqual(len(json.loads((Path(d) / smart.FILE_NAME).read_text(encoding="utf-8"))), 1)


if __name__ == "__main__":
    unittest.main()
