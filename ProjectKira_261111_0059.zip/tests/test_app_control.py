"""T6-AppControl: launching apps whose shortcut is dead, remembering the REAL executable, ending tray-only programs honestly,
local commands never becoming web searches, and replies that must not claim what no tool did.

HONEST SCOPE: these tests use real files in a temp folder (fake "AppData\\Local\\Programs\\Opera GX\\opera.exe") but the Windows parts - process
list, windows, ShellExecute, TerminateProcess, the .lnk parser on a real shortcut - are replaced by small fakes, so they run on any OS.
They prove Kira's decisions (which path is tried, what is stored, what is claimed); they do NOT prove Windows behaviour. The real-Windows
checklist is in CHANGELOG.md (T6-AppControl)."""
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import psutil

from kira import brain, modes, websearch
from kira.tools import apps, appclose, appcatalog, appindex, processes
from kira.tools.registry import ToolError, DENIED, ERROR


def touch_exe(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"MZ")
    return path


class Sandbox(unittest.TestCase):
    """A fake Windows profile: <tmp>/Users/Alize/AppData/Local/Programs/Opera GX/opera.exe is the real install; the shortcut points elsewhere."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.profile = self.root / "Users" / "Alize"
        self.local = self.profile / "AppData" / "Local"
        self.install = self.local / "Programs" / "Opera GX"
        self.real_exe = touch_exe(self.install / "opera.exe")
        touch_exe(self.install / "opera_crashreporter.exe")                   # helpers sit next to the real program
        touch_exe(self.install / "installer.exe")
        env = {"LOCALAPPDATA": str(self.local), "APPDATA": str(self.profile / "AppData" / "Roaming"), "USERPROFILE": str(self.profile),
               "PROGRAMFILES": str(self.root / "PF"), "PROGRAMFILES(X86)": str(self.root / "PF86"), "PROGRAMW6432": str(self.root / "PF"),
               "PROGRAMDATA": str(self.root / "PD")}
        patcher = mock.patch.dict(os.environ, env)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.store = appindex.PathStore(str(self.root / "app_paths.json"))
        patcher = mock.patch.object(appindex, "PATHS", self.store)
        patcher.start()
        self.addCleanup(patcher.stop)
        # the Start Menu shortcut as the parser reports it: a target with the user-profile part lost (what the user's log showed)
        self.lnk = str(self.root / "Start Menu" / "Opera GX.lnk")
        self.dead_target = str(self.root / "Users" / "Programs" / "Opera GX" / "opera.exe")
        self.lnk_targets = {self.lnk: [self.dead_target]}
        patcher = mock.patch.object(appcatalog, "lnk_exes", lambda p: list(self.lnk_targets.get(p, [])))
        patcher.start()
        self.addCleanup(patcher.stop)
        self.entry = appcatalog.AppEntry("Opera GX")
        self.entry.add("startmenu", "lnk", self.lnk)


class LaunchPlanTests(Sandbox):
    def kinds(self, entry=None):
        return [(k, t) for k, t, _ in apps._launch_plan(entry or self.entry)]

    def test_a_dead_shortcut_is_not_a_launch_method_and_its_target_is_repaired(self):
        self.assertEqual(apps.broken_shortcut_targets(self.lnk), [self.dead_target])
        plan = self.kinds()
        self.assertNotIn("lnk", [k for k, _ in plan])                          # the broken shortcut can only fail: not tried first any more
        self.assertEqual(plan, [("exe", str(self.real_exe))])                  # Programs\Opera GX\opera.exe found under %LOCALAPPDATA%

    def test_repair_only_looks_under_the_usual_roots_and_for_the_same_file_name(self):
        self.assertEqual(appcatalog.repair_missing_exe(self.dead_target), str(self.real_exe))
        self.assertEqual(appcatalog.repair_missing_exe(str(self.root / "Users" / "Programs" / "Opera GX" / "other.exe")), "")
        self.assertEqual(appcatalog.repair_missing_exe(str(self.root / "x" / "opera.exe")), "")            # file name alone is never enough
        self.assertEqual(appcatalog.repair_missing_exe(str(self.root / "Users" / "Programs" / "Opera GX")), "")      # not an .exe

    def test_a_working_shortcut_stays_first(self):
        self.lnk_targets[self.lnk] = [str(self.real_exe)]
        self.assertEqual(apps.broken_shortcut_targets(self.lnk), [])
        self.assertEqual(self.kinds()[0], ("lnk", self.lnk))

    def test_when_nothing_repairs_the_target_the_install_folder_is_searched_but_never_launched_itself(self):
        self.lnk_targets[self.lnk] = [str(self.root / "gone" / "elsewhere" / "nothing.exe")]
        self.entry.add("installed-apps", install_dir=str(self.install))
        plan = apps._launch_plan(self.entry)
        self.assertEqual([(k, t) for k, t, _ in plan], [("exe", str(self.real_exe))])      # main program found inside; helpers / installer skipped
        self.assertFalse(plan[0][2])                                                       # it is a guess from folder contents: not "certain"
        self.assertNotEqual(plan[0][1], str(self.install))                                 # the FOLDER is never the launch target

    def test_a_folder_is_not_an_executable(self):
        self.assertFalse(appcatalog.is_safe_exe(str(self.install)))
        with mock.patch.object(apps.os, "startfile", create=True) as start:
            with self.assertRaises(ToolError) as ctx:
                apps._start("exe", str(self.install))
        self.assertEqual(ctx.exception.status, DENIED)
        start.assert_not_called()
        self.assertEqual(appcatalog.exe_from_path("Opera GX", str(self.install)), str(self.real_exe))
        self.assertEqual(appcatalog.exe_from_path("Opera GX", str(self.real_exe)), str(self.real_exe))
        self.assertEqual(appcatalog.exe_from_path("Opera GX", str(self.root / "nowhere")), "")

    def test_an_app_that_is_not_in_any_internal_list_is_launched_from_the_discovered_entry(self):
        """An app Kira has never heard of (no alias, no built-in): only the discovered entry decides how it starts."""
        self.assertNotIn("operagx", {k for k in apps.BUILTIN_APPS})
        stranger = appcatalog.AppEntry("Totally Unknown Tool")
        exe = touch_exe(self.local / "Programs" / "Unknown Tool" / "unknowntool.exe")
        stranger.add("app-paths", "exe", str(exe))
        self.assertEqual(self.kinds(stranger), [("exe", str(exe))])

    def test_learned_path_beats_everything_and_is_checked_again_each_time(self):
        self.lnk_targets[self.lnk] = [str(self.real_exe)]                                 # even a WORKING shortcut comes after a confirmed path
        self.store.add("Opera GX", str(self.real_exe))
        self.assertEqual(self.kinds()[0], ("exe", str(self.real_exe)))
        self.real_exe.unlink()                                                            # uninstalled / moved: the stored path silently stops being used
        self.assertEqual(self.store.get("Opera GX"), "")
        self.assertNotIn(str(self.real_exe), [t for _, t in self.kinds()])

    def test_the_store_refuses_non_programs_and_never_holds_a_pid(self):
        with self.assertRaises(ValueError):
            self.store.add("Opera GX", str(self.install))                                 # a folder
        with self.assertRaises(ValueError):
            self.store.add("Opera GX", str(self.root / "missing.exe"))
        self.store.add("Opera GX", str(self.real_exe))
        data = json.loads((self.root / "app_paths.json").read_text(encoding="utf-8"))
        self.assertEqual(data, {"operagx": str(self.real_exe)})                           # name -> path, nothing else (no pid / time)


class RunningProcessTests(Sandbox):
    def state(self, *procs):
        return SimpleNamespace(matched=list(procs), pids={p["pid"] for p in procs}, visible=[], hidden=[])

    def ident(self):
        return apps._identity(self.entry)

    def test_the_real_exe_is_read_from_the_running_process_and_helpers_are_ignored(self):
        helper = {"pid": 5, "name": "opera_crashreporter.exe", "exe": str(self.install / "opera_crashreporter.exe")}
        main = {"pid": 7, "name": "opera.exe", "exe": str(self.real_exe)}
        self.assertEqual(apps._running_exe(self.state(helper, main), self.ident()), str(self.real_exe))
        self.assertEqual(apps._running_exe(self.state(helper), self.ident()), "")
        self.assertEqual(apps._running_exe(self.state({"pid": 9, "name": "opera.exe", "exe": ""}), self.ident()), "")      # path unreadable: nothing invented

    def test_full_story_found_running_closed_then_reopened_from_the_discovered_path(self):
        """The user's log: Opera found running -> 'remember the path' -> closed -> 'open it' must NOT go back to the dead shortcut."""
        started, windows = [], {"running": True, "pid": 21116}

        class FakeState:
            def __init__(inner, ident, with_hidden):
                inner.ident = ident
                inner.visible, inner.hidden = [], []
                inner.matched = [{"pid": windows["pid"], "name": "opera.exe", "exe": str(self.real_exe)}] if windows["running"] else []
                inner.pids = {p["pid"] for p in inner.matched}

        tools = apps.AppTools(None)
        with mock.patch.object(apps, "IS_WIN", True), mock.patch.object(apps, "_State", FakeState), \
                mock.patch.object(apps, "_start", lambda kind, target: started.append((kind, target))), \
                mock.patch.object(apps.AppTools, "_verify", lambda self_, label, ident, before, seconds: "تأیید شد (VERIFIED)."), \
                mock.patch.object(apps, "resolve_app", lambda name, _retry=True: ("app", self.entry)):
            tools.open_app({"name": "Opera GX"})                                          # app is running without window: learns the REAL path
            self.assertEqual(self.store.get("Opera GX"), str(self.real_exe))
            started.clear()
            windows["running"] = False                                                    # user said «ببندش»
            tools.open_app({"name": "Opera GX"})                                          # user said «بازش کن»
        self.assertEqual(started, [("exe", str(self.real_exe))])                          # dead shortcut never attempted again

    def test_each_run_gets_its_own_pid_and_none_is_kept(self):
        tools = apps.AppTools(None)
        for pid in (111, 222):
            fake = SimpleNamespace(matched=[{"pid": pid, "name": "opera.exe", "exe": str(self.real_exe)}])
            self.store.add("Opera GX", apps._running_exe(fake, self.ident()))
        self.assertNotIn("111", (self.root / "app_paths.json").read_text(encoding="utf-8"))
        self.assertNotIn("222", (self.root / "app_paths.json").read_text(encoding="utf-8"))

    def test_when_every_method_fails_the_real_reasons_are_reported_not_a_claim(self):
        tools = apps.AppTools(None)
        self.lnk_targets[self.lnk] = [str(self.root / "gone" / "x.exe")]
        self.entry.add("installed-apps", install_dir=str(self.install))
        calls = []

        def boom(kind, target):
            calls.append((kind, target))
            raise OSError(740, "elevation required")
        empty = SimpleNamespace(visible=[], hidden=[], matched=[], pids=set())
        with mock.patch.object(apps, "IS_WIN", True), mock.patch.object(apps, "_State", lambda ident, with_hidden: empty), mock.patch.object(apps, "_start", boom), \
                mock.patch.object(apps, "resolve_app", lambda name, _retry=True: ("app", self.entry)):
            with self.assertRaises(ToolError) as ctx:
                tools.open_app({"name": "Opera GX"})
        self.assertIn("ناموفق", str(ctx.exception))
        self.assertIn("elevation required", str(ctx.exception))                           # the real OS error text, not "I tried"
        self.assertEqual(len(calls), len(set(calls)))                                     # the same method is never tried twice in one call


class RememberAppPathTests(Sandbox):
    def tools(self):
        return apps.AppTools(None)

    def call(self, **args):
        with mock.patch.object(apps, "IS_WIN", True), mock.patch.object(apps, "resolve_app", lambda name, _retry=True: ("app", self.entry)):
            return self.tools().remember_app_path(args)

    def test_a_folder_from_the_user_is_resolved_to_the_main_program_inside_it(self):
        text = self.call(app="Opera GX", path=str(self.install))
        self.assertIn(str(self.real_exe), text)
        self.assertEqual(self.store.get("Opera GX"), str(self.real_exe))

    def test_an_exe_path_is_saved_and_read_back(self):
        self.call(app="Opera GX", path=str(self.real_exe))
        self.assertEqual(self.store.get("Opera GX"), str(self.real_exe))

    def test_a_start_menu_folder_or_a_missing_path_saves_nothing(self):
        for bad in (str(self.profile / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs"), str(self.root / "nowhere" / "opera.exe")):
            with self.assertRaises(ToolError):
                self.call(app="Opera GX", path=bad)
        self.assertEqual(self.store.get("Opera GX"), "")

    def test_an_unrelated_program_outside_the_install_roots_is_not_stored_for_this_app(self):
        evil = touch_exe(self.root / "downloads" / "totally_other.exe")
        with self.assertRaises(ToolError) as ctx:
            self.call(app="Opera GX", path=str(evil))
        self.assertEqual(ctx.exception.status, DENIED)
        self.assertEqual(self.store.get("Opera GX"), "")

    def test_without_a_path_it_needs_a_running_process_and_otherwise_says_so(self):
        empty = SimpleNamespace(visible=[], hidden=[], matched=[], pids=set())
        with mock.patch.object(apps, "_State", lambda ident, with_hidden: empty):
            with self.assertRaises(ToolError) as ctx:
                self.call(app="Opera GX")
        self.assertIn("اجرا نیست", str(ctx.exception))
        running = SimpleNamespace(visible=[], hidden=[], pids={7}, matched=[{"pid": 7, "name": "opera.exe", "exe": str(self.real_exe)}])
        with mock.patch.object(apps, "_State", lambda ident, with_hidden: running):
            text = self.call(app="Opera GX")
        self.assertIn("PID", text)
        self.assertIn("ذخیره نمی‌شود", text)
        self.assertEqual(self.store.get("Opera GX"), str(self.real_exe))

    def test_find_app_explains_a_dead_shortcut(self):
        with mock.patch.object(apps, "IS_WIN", False):
            text = apps.AppTools._describe(self.entry)
        self.assertIn("خراب", text)
        self.assertIn(self.dead_target, text)


class TrayAndProcessTests(unittest.TestCase):
    def test_persian_end_task_and_kill_phrases_open_the_explicit_request_gate(self):
        for text in ("اند تسکش کن", "از توی تسک منیجر پروسسشو اند تسک کن", "زور بزن کیل تسکش کن", "end task it", "kill it"):
            self.assertTrue(processes.KILL_RX.search(text), text)
        for text in ("تایید", "ببندش", "بازش کن", "کیلومتر", "الان بازه؟"):
            self.assertFalse(processes.KILL_RX.search(text), text)

    def test_closing_a_tray_only_app_says_so_and_hands_over_the_exact_pid_and_name(self):
        target = SimpleNamespace(stems={"windscribe"}, key="windscribe", label="Windscribe", console=False)
        procs = [{"pid": 21116, "name": "Windscribe.exe"}]
        with mock.patch.object(appclose, "IS_WIN", True), mock.patch.object(appclose, "_build_target", lambda name: (target, [])), \
                mock.patch.object(appclose, "_protected_pids", lambda: set()), mock.patch.object(appclose, "_own_console", lambda: None), \
                mock.patch.object(appclose, "_windows", lambda t, p, o: []), mock.patch.object(appclose, "_processes", lambda t, p: procs):
            with self.assertRaises(ToolError) as ctx:
                appclose.CloseTools().close_app({"name": "Windscribe"})
        text = str(ctx.exception)
        self.assertIn("process_kill", text)
        self.assertIn("pid 21116", text)
        self.assertIn("Tray", text)

    def fake_psutil(self, kill_raises=None, stays=False):
        class Proc:
            def __init__(inner, pid):
                inner.pid = pid

            def name(inner):
                return "Windscribe.exe"

            def username(inner):
                return "PC\\Alize"

            def parents(inner):
                return []

            def kill(inner):
                if kill_raises:
                    raise kill_raises

            def wait(inner, timeout=None):
                if stays:
                    raise psutil.TimeoutExpired(timeout)
        return SimpleNamespace(Process=Proc, NoSuchProcess=psutil.NoSuchProcess, AccessDenied=psutil.AccessDenied, Error=psutil.Error,
                               TimeoutExpired=psutil.TimeoutExpired)

    def kill(self, **kw):
        with mock.patch.object(processes, "IS_WIN", True), mock.patch.object(processes, "psutil", self.fake_psutil(**kw)):
            return processes.ProcessTools(None).process_kill({"pid": 21116, "name": "Windscribe.exe"})

    def test_a_refused_kill_is_reported_as_permission_denied_never_retried_with_admin(self):
        with self.assertRaises(ToolError) as ctx:
            self.kill(kill_raises=psutil.AccessDenied(21116))
        self.assertEqual(ctx.exception.status, DENIED)
        self.assertEqual(getattr(ctx.exception, "kind", ""), "permission_denied")
        self.assertIn("Administrator", str(ctx.exception))
        self.assertIn("دور نمی", str(ctx.exception))                                      # states that nothing was bypassed

    def test_a_process_that_survives_the_kill_is_never_called_done(self):
        text = self.kill(stays=True)
        self.assertIn("UNVERIFIED", text)
        self.assertNotIn("VERIFIED)", text.replace("UNVERIFIED", ""))

    def test_a_kill_is_verified_only_when_the_process_is_really_gone(self):
        self.assertIn("(VERIFIED)", self.kill())


class LocalCommandsAreNotWebSearches(unittest.TestCase):
    def test_commands_about_this_pc_never_trigger_an_automatic_search(self):
        for text in ("ببندش", "بازش کن الان", "الان بازه؟", "مسیرشو می‌بینی؟", "اند تسکش کن", "اپرا جی ایکس رو باز کن", "ببندش الان", "بازش کن",
                     "از توی تسک منیجر پروسسشو اند تسک کن", "ویندسکرایب توی تری سیستم بازه میتونی ببندیش؟"):
            self.assertEqual(websearch.plan(text), (None, False), text)

    def test_real_web_questions_and_explicit_search_requests_still_search(self):
        for text in ("اخبار امروز", "قیمت دلار الان", "آخرین نسخه اپرا چیه", "هوای تهران امروز"):
            self.assertIsNotNone(websearch.plan(text)[0], text)
        self.assertEqual(websearch.plan("/web اپرا جی ایکس"), ("اپرا جی ایکس", True))
        self.assertIsNotNone(websearch.plan("سرچ کن ببندش یعنی چی")[0])                       # an explicit search verb wins


class HonestClaimsTests(unittest.TestCase):
    def check(self, reply, tools):
        return {sig for sig, _ in brain.check_reply(reply, tools, mode_name=modes.TASK, tool_expected=True)}

    def test_closing_claim_needs_a_close_tool_not_just_any_successful_tool(self):
        listed = [{"tool": "process_list", "status": "ok"}]
        self.assertIn("claim_close_without_tool", self.check("بستمش، پروندم رفت!", listed))
        self.assertNotIn("claim_close_without_tool", self.check("بستمش.", [{"tool": "close_app", "status": "ok"}]))

    def test_opening_claim_needs_an_open_tool(self):
        self.assertIn("claim_open_without_tool", self.check("بازش کردم، الان روی میز کارته.", [{"tool": "find_app", "status": "ok"}]))
        self.assertNotIn("claim_open_without_tool", self.check("بازش کردم.", [{"tool": "open_app", "status": "ok"}]))

    def test_powershell_or_admin_claims_are_flagged_because_no_such_tool_exists(self):
        for reply in ("دستور پاورشل با دسترسی ادمین فرستاده شد؛ کارش ساخته شد.", "با ادمین زدم و بستمش."):
            self.assertIn("claim_admin_without_tool", self.check(reply, [{"tool": "process_kill", "status": "denied"}]), reply)


if __name__ == "__main__":
    unittest.main()
