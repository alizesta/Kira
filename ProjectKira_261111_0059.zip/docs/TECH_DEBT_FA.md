# ثبت بدهی فنی — وابستگی به PowerShell ثابت

| حوزه | ابزارها | چرا PowerShell | ریسک | مسیر مهاجرت پیشنهادی |
|---|---|---|---|---|
| UI Automation | `ui_list_controls`, `ui_click`, `ui_click_confirmed`, `ui_set_text` | یک اسکریپت ثابت با `Add-Type` و UIAutomationClient | کندی راه‌اندازی، Constrained Language Mode، آنتی‌ویروس | `comtypes` + `IUIAutomation` یا `uiautomation` داخل پروسه |
| صدا | ۱۱ ابزار `audio_*` | Core Audio COM از داخل C# با `Add-Type` | همان‌ها؛ هر عملیات یک پروسه‌ی جدید | `pycaw` / `comtypes` مستقیم |
| بلوتوث | `bluetooth_status/on/off` | WinRT Radio API | WinRT از Python سخت‌تر است | `winrt` یا Helper کوچک C# |

## قاعده
- فهرست بالا منجمد است (`POWERSHELL_FROZEN` در `kira/tools/registry.py`، اعمال‌شده در `ToolRegistry.register()` و `WindowsControlLayer._validate()`). قابلیت جدید با Backend ‎`powershell-fixed`‎ یا ‎`uia`‎ ثبت نمی‌شود.
- **پیش از گسترش** قابلیت‌های وابسته (مثلاً صدای میکروفون مستقل، کنترل Office/UIA عمیق‌تر، دستگاه‌های Bluetooth جفت‌شده) ابتدا مهاجرت همان حوزه باید بررسی و در صورت امکان انجام شود.
- مهاجرت باید Fallback داشته باشد تا اگر روی ویندوز واقعی نخواند، قابلیت فعلی از بین نرود.
- وضعیت همه‌ی موارد: `IMPLEMENTED_UNTESTED`.
