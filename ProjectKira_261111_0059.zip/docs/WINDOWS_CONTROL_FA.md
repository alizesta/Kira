> **T5-Core:** تصمیم‌های Permission، تأیید و ژورنال از این لایه به «مدیر مرکزی دسترسی» منتقل شد (`docs/SYSTEM_ACCESS_FA.md`). این لایه فقط محل **اعلام** قابلیت‌هاست؛ بخش‌های «ثبت نتیجه‌ی واقعی» و «گارد» پایین طبق مدیر مرکزی اجرا می‌شوند (ژورنال مرکزی، `check_intent` مرکزی).

# Windows Control Layer (هسته‌ی کنترل ویندوز)

کد: `kira/tools/wincontrol.py` (هسته)، `kira/tools/winmodules.py` (اعلام قابلیت‌ها) و `kira/tools/winrunner.py` (اجراکننده‌ی مشترک PowerShell). روی همان Tool Registry سوار است؛ Access Control، تأییدِ سطح ۳، پروتکل متنی و Hybrid Brain بدون تغییر کار می‌کنند. به هیچ Provider/مدلی وابسته نیست.

## قرارداد هر قابلیت (`Capability`)
نام ثابت، handler ثابت، پارامترهای بسته و تایپ‌دار، دامنه (`apps | bluetooth | audio | wallpaper | tray | system`)، سطح ریسک و شرط اجرا. در زمان ثبت بررسی می‌شود (خطا = توقف هنگام شروع، نه حفره‌ی بعدی):

| سطح | معنی | شرط |
|---|---|---|
| READ | فقط می‌خواند | — |
| ACTION | تغییر کوچک و برگشت‌پذیر | یا `intent_rx` (درخواست صریح در **همان پیام** کاربر) یا `intent_optout` با دلیل مکتوب |
| SENSITIVE | حساس | `confirm_summary` اجباری؛ Registry قبل از اجرا تأیید صریح کاربر می‌گیرد |

- پارامتر شبیه دستور/اسکریپت (`command`, `script`, `shell`, `powershell`, `cmd`, `argv`, ...) رد می‌شود؛ هیچ ابزاری متن آزاد را اجرا نمی‌کند. اسکریپت‌های PowerShell فقط ثابت و داخل ماژول‌اند.
- هر قابلیت `verifies_result` (بعد از تغییر وضعیت واقعی دوباره خوانده می‌شود) و `changes_system` را اعلام می‌کند.

## ثبت نتیجه‌ی واقعی
هر اجرا در `OperationLog` (حافظه‌ی همین اجرا، ۲۰۰ مورد، بدون ذخیره روی دیسک و بدون ورود به تاریخچه‌ی گفتگو) ثبت می‌شود: دامنه، ابزار، سطح، وضعیت (ok / error / denied)، مدت، خلاصه‌ی نتیجه یا علت خطا (کلیدها پنهان). ردشدن به‌خاطر نبود درخواست صریح هم ثبت می‌شود. ابزار خواندنی `windows_control_info` جدول قابلیت‌ها و آخرین عملیات واقعی را می‌دهد («تازه چه کاری کردی؟»).

## یکپارچه‌سازی موجود
بدون بازنویسی منطق: `AppsModule` (`find_app`, `open_app`) و `BluetoothModule` (`bluetooth_status/on/off`) فقط قابلیت‌ها را اعلام می‌کنند؛ کد در `apps.py`، `appcatalog.py`، `bluetooth.py` همان است. نام ابزارها، پارامترها و رفتار مدل تغییری نکرد. `open_path` و `open_url` فعلاً در `builtin.py` مانده‌اند (به دامنه‌ی فایل/وب نزدیک‌ترند).

یک جابه‌جایی: گارد «درخواست صریح بلوتوث» از Registry به همین لایه آمد (و ردشدن‌ها ثبت می‌شوند). فیلد `intent_rx` در Registry برای ابزارهای دیگر باقی است.

## ماژول صدا (Audio Manager) و اجراکننده‌ی مشترک
`AudioModule` (در `winmodules.py`) ۱۱ قابلیت صدا را اعلام می‌کند؛ کد در `kira/tools/audio.py` است. راهنمای کامل: `docs/AUDIO_MANAGER_FA.md`.

**اجراکننده‌ی مشترک (`winrunner.py`):** تنها نقطه‌ای که PowerShell را اجرا می‌کند. فقط `FixedScript` (اسکریپت ثابتِ نوشته‌شده در کد، ساخته‌شده هنگام import) را می‌پذیرد؛ `str` معمولی با `TypeError` رد می‌شود. داده‌ی متغیر هرگز داخل اسکریپت نمی‌رود و فقط با متغیر محیطی `KIRA_*` می‌رسد (اسکریپت آن را به‌عنوان داده می‌خواند). اسکریپت با `-EncodedCommand` و بدون shell اجرا می‌شود و `powershell.exe` از پوشه‌ی System32 برداشته می‌شود. ماژول بلوتوث فقط اجراکننده‌اش را به این فایل سپرد (`bluetooth._run` همان خروجی و همان پیام‌های خطا را می‌دهد)؛ منطق بلوتوث و اجرای برنامه‌ها بازنویسی نشد.

## افزودن قابلیت جدید (Wallpaper / Tray / System)
1. دامنه از قبل در `DOMAINS` هست (دامنه‌ی تازه = یک خط).
2. کلاس `WinModule` با `domain` و `capabilities()` بنویس؛ handler باید متن نتیجه‌ی واقعی بدهد یا `ToolError` با علت واقعی. اگر PowerShell لازم است از `winrunner.run_fixed` با یک `FixedScript` استفاده کن.
3. در `builtin.py`: `layer.register_module(WallpaperModule(...))`.
4. اگر دسته‌ی نمایش تازه‌ای می‌خواهی، یک خط به `protocol.GATES` اضافه کن.
هیچ تغییری در Registry، Agent یا Hybrid Brain لازم نیست.

## محدودیت‌ها
- روی ویندوز واقعی آزموده نشده؛ فقط بررسی نحو (ماژول صدا هم همین‌طور؛ جزئیات در `docs/AUDIO_MANAGER_FA.md`).
- Journal فقط در حافظه است و با بستن برنامه پاک می‌شود (عمدی).
- ردکردن «درخواست صریح» بر اساس regex پیام فعلی است؛ پیام کوتاه بدون ذکر موضوع («بکنش») رد می‌شود.
- اجراکننده‌ی مشترک PowerShell (`winrunner.py`) جدا شد و بلوتوث و صدا از آن استفاده می‌کنند.


---

# T6 — ممیزی معماری (فاز ۱) و پایه‌ی قابل‌اعتماد (فاز ۲)

وضعیت این بخش: **فاز ۱ (ممیزی) و فاز ۲ (قابلیت اطمینان هسته: UAC، علت خطا، ژورنال، برچسب Backend) انجام شده**. فاز ۳ (ماژول‌های تازه) هنوز شروع نشده و جدول زیر همین را صادقانه نشان می‌دهد. هیچ تست/اجرایی انجام نشد (فقط Syntax و بررسی ثبت در رجیستری).

## ماتریس قابلیت‌ها (بر اساس کد واقعی)
| حوزه | وضعیت | ابزارهای موجود | کمبود |
|---|---|---|---|
| A. برنامه‌ها | **بخشی** | `find_app`، `open_app`، `open_path`، `open_url`، `list_running_apps`، `get_active_window`، `window_*` | بستن/Kill فرایند، جزئیات فرایند، مسیر نصب، Uninstall، باز کردن فایل با برنامه‌ی دلخواه |
| B. دسکتاپ و UIA | **بخشی (قوی)** | `window_list/focus/close/set_state`، `type_text`، `press_keys`، `ui_list_controls`، `ui_click`، `ui_set_text`، `mouse_click`، `clipboard_*` | مدیریت چند مانیتور و هندسه‌ی صفحه، Scroll، Drag-and-Drop، خواندن وضعیت کنترل‌ها، لایه‌ی عمومی «Settings Navigation» |
| C. صدا | **بخشی (قوی)** | ۱۱ ابزار: ولوم/Mute/دستگاه پیش‌فرض/ولوم هر برنامه + تأیید نتیجه | Mute میکروفون به‌صورت مستقل، وضعیت Endpoint جداگانه |
| D. نمایشگر | **ندارد** | — | روشنایی، رزولوشن، Refresh Rate، جهت، مانیتورها، Scaling، Wallpaper، Screen Timeout |
| E. شبکه | **بخشی (ضعیف)** | `get_network_info` (اتصال و IPها)، `network_adapter_set` (Elevated، جدید) | Wi-Fi (وضعیت/اتصال/قطع)، DNS، تشخیص، VPN، شبکه‌های در دسترس |
| F. بلوتوث و دستگاه‌ها | **بخشی** | `bluetooth_status/on/off` | دستگاه‌های جفت‌شده، اتصال/قطع، USB، چاپگر، دوربین/میکروفون |
| G. تنظیمات ویندوز | **ندارد** | — | Theme، Wallpaper، Taskbar، Notification، Mouse/Keyboard، Language، Power plan، Startup |
| H. فایل و پوشه | **قوی** | File Agent کامل + `search_files`، `file_info`، `delete_*`، `undo_file_operation` | فایل‌های بزرگ، تکراری، Restore از Recycle Bin، مصرف دیسک تفصیلی |
| I. اطلاعات سیستم | **بخشی** | `get_system_info`، `get_resource_usage`، `get_disks`، `list_running_apps` | فرایندهای پرمصرف تفصیلی، سلامت دیسک، سرویس‌ها، Event Log، نرم‌افزارهای نصب‌شده، Uptime |
| J. Power و Session | **ندارد** | — | Lock، Sign out، Restart، Shutdown، Sleep، Hibernate، لغو Shutdown |
| K. Office | **ندارد** | — | فقط معماری باید آماده شود |
| Elevated/UAC | **پایه آماده (جدید)** | `service_restart`، `network_adapter_set` | آزمایش روی ویندوز واقعی؛ Helper امضاشده |

## یافته‌های ممیزی
- **Backend گمراه‌کننده (اصلاح شد):** صدا «COM» ثبت می‌شد ولی با PowerShell ثابت اجرا می‌شود.
- **ELEVATED فقط سیاست بود** و هیچ مسیر اجرایی نداشت (حالا `elevation.py`).
- **علت خطا یکدست نبود:** بیشتر خطاها فقط `error/denied` بودند؛ `kind` اضافه شد (Audio و PowerShell Runner کامل، بقیه در فاز ۳).
- **ژورنال** وضعیت UAC، نیاز به تأیید، وضعیت بازبینی و علت خطا را نداشت؛ اضافه شد (همان ژورنال مرکزی، بدون لاگ دوم).
- `open_path` سطح FILE دارد ولی `intent_rx` ندارد (فقط Taint-gate)؛ فعلاً ثابت ماند و برای ارزیابی در فاز ۳ ثبت شد.
- `get_disks` دامنه‌ی `files` و Backend `filesystem` دارد درحالی‌که اطلاعات سیستم است (برچسب فقط نمایشی؛ در فاز ۳ اصلاح می‌شود).
- Bluetooth: وضعیت‌های `state` خودش علت‌گذاری شده ولی هنوز `kind` استاندارد را برنمی‌گرداند (فاز ۳).
- دروازه‌ی نیت (`protocol.GATES`) برای «سرویس/آداپتور» کلمه گرفت؛ دسته‌های Display/Network/Power هنوز وجود ندارند.

## چه چیزی بدون Administrator کار می‌کند
همه‌ی ابزارهای READ، CONTROL (برنامه‌ها، صدا، بلوتوث، پنجره‌ها، UIA)، FILE و PROTECTED (فقط درخواست مستقیم + تأیید کاربر؛ ربطی به Administrator ندارد).

## چه چیزی UAC می‌خواهد
فقط `service_restart` و `network_adapter_set`، و فقط پس از تأیید صریح همان عملیات. جزئیات: `docs/SYSTEM_ACCESS_FA.md`.


---

# T6 — فاز ۱: فایل‌ها، برنامه‌ها و پردازش‌ها (نسخه‌ی اصلاح‌شده‌ی تسک)

> فازبندی تسک اصلاح شد (Phase 1 = فایل و برنامه، Phase 2 = پنجره/تنظیمات، Phase 3 = دستگاه/شبکه، Phase 4 = سیستم/Office). ماتریس «حوزه‌های A–K» بالا مال پیش‌نویس قبلی بود؛ مرجع تحویل همین بخش است. زیرساخت UAC و علت‌های خطا (تحویل قبلی) بخشی از هسته‌اند و در فازهای بعد استفاده می‌شوند. **تا دستور کاربر سراغ فاز ۲ نرفتم.**

## وضعیت قابلیت‌ها (برچسب‌های تحویل)
هیچ‌چیز COMPLETED نیست: هیچ تست عملی روی ویندوز واقعی انجام نشد (فقط Syntax و ثبت در رجیستری).

| قابلیت | ابزار | وضعیت |
|---|---|---|
| جست‌وجوی فایل (نام/پسوند/تاریخ) | `search_files` | IMPLEMENTED_UNTESTED (T5) |
| ساخت پوشه/فایل، تغییر نام، کپی، افزودن متن | `make_folder` `create_file` `rename_item` `copy_item` `append_text` | IMPLEMENTED_UNTESTED (T5) |
| انتقال، حذف به سطل بازیافت (تأیید) | `move_file` `delete_file` `delete_folder` `batch_files` | IMPLEMENTED_UNTESTED (T5) |
| اطلاعات فایل/پوشه، فهرست پوشه، باز کردن | `file_info` `list_folder` `open_path` | IMPLEMENTED_UNTESTED (T5) |
| فایل‌های بزرگ / تکراری / مصرف پوشه | `find_large_files` `find_duplicate_files` `folder_usage` | IMPLEMENTED_UNTESTED (جدید، فقط خواندن) |
| بازگردانی از Recycle Bin | — | UNSUPPORTED (فقط `undo_file_operation` برای عملیات غیرحذف) |
| اجرای برنامه / جابه‌جایی / بستن پنجره | `open_app` `window_focus` `window_close` `window_set_state` | IMPLEMENTED_UNTESTED (T5) |
| فهرست و جزئیات پردازش‌ها | `process_list` `process_info` | IMPLEMENTED_UNTESTED (جدید؛ نیاز به psutil) |
| بستن مؤدبانه / اجبار به پایان پردازش | `process_close` `process_kill` | IMPLEMENTED_UNTESTED (جدید، با تأیید) |
| فهرست نرم‌افزارهای نصب‌شده | `app_list_installed` | IMPLEMENTED_UNTESTED (جدید) |
| حذف نرم‌افزار (فقط نصب کاربر) | `app_uninstall` | LIMITED |
| نصب نرم‌افزار (winget، فقط کاربر) | `app_search_online` `app_install` | LIMITED |
| حذف نرم‌افزار کل سیستم / نصب سراسری | — | UNSUPPORTED (عمداً؛ از Windows Settings) |

## معیار پذیرش هر ابزار جدید
| ابزار | سطح | تأیید | بررسی موفقیت واقعی | در شکست/توقف | بازگردانی |
|---|---|---|---|---|---|
| `process_list/info` | READ | خیر | — (خواندن) | خطای علت‌دار | — |
| `process_close` | CONTROL + تأیید | بله (pid+نام) | پایان واقعی پردازه تا ۶ ثانیه؛ وگرنه **UNVERIFIED** | برنامه ممکن است بپرسد ذخیره شود؛ «بسته شد» گفته نمی‌شود | دوباره باز کردن |
| `process_kill` | PROTECTED (درخواست مستقیم + تأیید) | بله (pid+نام) | پایان واقعی تا ۵ ثانیه؛ وگرنه **UNVERIFIED** | `permission_denied`، بدون تلاش با Administrator | ندارد |
| `app_list_installed` | READ | خیر | — | `missing_component` خارج از ویندوز | — |
| `app_uninstall` | PROTECTED (درخواست مستقیم + تأیید) | بله (نام دقیق) | ورودی از رجیستری حذف شد؟ VERIFIED؛ بعد از ۲۵ ثانیه هنوز هست: **UNVERIFIED** | HKLM/خارج از پروفایل: `admin_required` بدون هیچ تلاش؛ خطای ۷۴۰: `admin_required` | نصب دوباره |
| `app_install` | CONTROL + تأیید | بله (id بسته) | `winget list --id` بعد از نصب؛ وگرنه **UNVERIFIED**/خطا | نیاز به Administrator: `admin_required`، تلاش مجدد سراسری انجام نمی‌شود | حذف |
| `find_*` / `folder_usage` | READ | خیر | اسکن کامل/ناقص صریح گزارش می‌شود | سقف ۲۵ ثانیه/۶۰هزار فایل → «ناقص» | — |

## مرزهای امنیتی فاز ۱
- پردازه‌ی حیاتی ویندوز (lsass، csrss، svchost، explorer، dwm، Defender ...)، خود Kira و زنجیره‌ی والدش، و پردازه‌ی کاربر/سرویس دیگر **هرگز** بسته نمی‌شود. شناسه به همراه نام تأیید می‌شود تا PID بازاستفاده‌شده هدف قرار نگیرد.
- حذف نرم‌افزار فقط **حذف‌کننده‌ی خود برنامه** را اجرا می‌کند (نه بی‌صدا، با پنجره‌ی خودش، `shell=False`) و فقط اگر یک exe واقعی داخل پروفایل کاربر باشد. اجرای رشته‌ی دلخواه یک نصب‌کننده با Administrator = مسیر اجرای فرمان دلخواه است و ساخته نشد.
- نصب با winget فقط `--scope user` و شناسه‌ی دقیق (الگوی سخت‌گیرانه). پذیرش توافق‌نامه‌ی بسته در متن تأیید گفته می‌شود.
- جست‌وجو/نصب winget نتیجه‌ی اینترنتی است: `app_search_online` بخش «محتوای خارجی» (Taint) حساب می‌شود.
- هیچ ابزاری از UAC استفاده نمی‌کند؛ نصب/حذف نیازمند Administrator رد و راهنمای دستی داده می‌شود.

## ژورنال
همان ژورنال مرکزی؛ برای ابزارهای جدید `verification` می‌تواند `verified | unverified` باشد (ابزار با `access.set_verification` اعلام می‌کند که وضعیت نهایی تأیید نشد) و `kind` علت خطاست.

## ریسک‌های باقی‌مانده
- همه‌ی ابزارهای جدید فقط Syntax‌شده‌اند؛ رفتار `psutil`، `winreg`، `EnumWindows/WM_CLOSE`، `winget` و حذف‌کننده‌ها روی ویندوز واقعی نامعلوم است.
- پارس UninstallString ساده است؛ حذف‌کننده‌های عجیب (بدون exe در پروفایل) عمداً رد می‌شوند.
- `process_close` برای برنامه‌های پس‌زمینه‌ی بدون پنجره کار نمی‌کند (باید `process_kill` جداگانه تأیید شود).
- **(حل‌شده در Phase 2r2)** معنای PROTECTED با تسک هم‌خوان شد و «تأیید» جدا از «سطح» است؛ جزئیات در `docs/SYSTEM_ACCESS_FA.md`.
- ممکن است کاربر `psutil` نداشته باشد؛ ابزارهای پردازش آن را صریح گزارش می‌کنند.

## فاز بعدی پیشنهادی
Phase 2 (پنجره‌ها و تنظیمات کاربر): تکمیل UIA، چند مانیتور، تم/Wallpaper، تنظیمات ماوس/کیبورد/Power، روشنایی و رزولوشن با بررسی واقعی.


---

# T6 — فاز ۲: پنجره‌ها و تنظیمات کاربر

> بدون Administrator، بدون PowerShell برای ابزارهای جدید (فقط `ctypes` / رجیستری کاربر / `powercfg.exe` با آرگومان ثابت). همه‌ی ابزارها از `ToolRegistry.execute()` ← `SystemAccessManager` رد می‌شوند و در Journal مرکزی ثبت می‌شوند. **هیچ تستی اجرا نشد؛ فقط `py_compile`.**

## ممیزی (چه چیزی از قبل بود)
`window_list/active/focus/close/set_state`، `type_text`، `press_keys`، `clipboard_*`، `ui_list_controls`، `ui_click(_confirmed)`، `ui_set_text`، `mouse_click`، و ۱۱ ابزار صدا (فاز قبل). **کمبودها:** چیدمان پنجره، والپیپر، تم، Taskbar، اعلان، ماوس، کیبورد، Power، روشنایی. UI Automation هنوز با یک اسکریپت ثابت PowerShell اجرا می‌شود.

## جدول وضعیت
| قابلیت | ابزار | سطح | تأیید | بازبینی نتیجه | وضعیت |
|---|---|---|---|---|---|
| کلیک/تایپ/میانبر/کنترل‌ها (UIA) | موجود از قبل | CONTROL/FILE | `ui_click_confirmed`, `mouse_click` با تأیید | بخشی | IMPLEMENTED_UNTESTED (UIA هنوز PowerShell) |
| چیدمان پنجره (نیمه‌ی چپ/راست/بالا/پایین/وسط) | `window_arrange` | CONTROL | خیر | مستطیل پنجره دوباره خوانده می‌شود؛ بدون تغییر ⇒ UNVERIFIED | IMPLEMENTED_UNTESTED |
| صدا و دستگاه‌ها | ۱۱ ابزار `audio_*` | CONTROL | خیر | بله | IMPLEMENTED_UNTESTED (PowerShell ثابت) |
| والپیپر | `wallpaper_get/set` | CONTROL | خیر | مسیر از ویندوز خوانده می‌شود | IMPLEMENTED_UNTESTED |
| تم روشن/تاریک | `theme_get/set` | CONTROL | خیر | بله | IMPLEMENTED_UNTESTED |
| Taskbar (پنهان‌شدن خودکار، چینش) | `taskbar_get/set` | CONTROL | خیر | autohide بله؛ چینش فقط رجیستری | LIMITED (چینش فقط ویندوز ۱۱) |
| اعلان‌ها | `notifications_get/set` | CONTROL | خیر | رجیستری | LIMITED (فقط سوییچ کلی بنر؛ Focus/DND پشتیبانی نمی‌شود) |
| ماوس (سرعت، جابه‌جایی دکمه) | `mouse_get/set` | CONTROL + `requires_confirmation` | **بله، با نمایش مقدار فعلی ← جدید** | بله | IMPLEMENTED_UNTESTED |
| کیبورد (سرعت/تأخیر تکرار) | `keyboard_get/set` | CONTROL + `requires_confirmation` | **بله** | بله | IMPLEMENTED_UNTESTED |
| Power plan و Timeout صفحه/Sleep | `power_get/set` | CONTROL + `requires_confirmation` | **بله** | `powercfg /query` | IMPLEMENTED_UNTESTED |
| روشنایی **صفحه‌ی داخلی لپ‌تاپ** | `laptop_brightness_get/set` | CONTROL | خیر | مقدار Power plan (خود پنل UNVERIFIED) | LIMITED — کنترل عمومی مانیتورها نیست؛ روی PC بدون باتری رد می‌شود؛ مانیتور خارجی UNSUPPORTED |
| برگرداندن آخرین تغییر | `settings_undo` | CONTROL | خیر | بازخوانی | IMPLEMENTED_UNTESTED |
| رزولوشن/Refresh/Scaling/جهت | — | — | — | — | UNSUPPORTED (در فاز بعدی) |
| تنظیم صدای میکروفون مستقل، Focus Assist | — | — | — | — | UNSUPPORTED |

## عملیات نیازمند UAC
هیچ‌کدام از ابزارهای فاز ۲ UAC نمی‌خواهند. Sleep/Restart/Shutdown عمداً در فاز ۴ است و `power_set` فقط تنظیمات را عوض می‌کند.

## ریسک‌های باقی‌مانده
- هیچ تست عملی روی ویندوز واقعی انجام نشد؛ رفتار `SystemParametersInfo`، `SHAppBarMessage`، `powercfg` و رجیستری باید روی سیستم واقعی دیده شود.
- Group Policy/سازمانی می‌تواند نوشتن رجیستری یا Power را رد کند (خطای `permission_denied` گزارش می‌شود).
- تم و چینش Taskbar ممکن است چند لحظه بعد (یا بعد از ریستارت Explorer) اعمال شود.
- روشنایی از طریق Power plan اعمال می‌شود، نه خواندن مستقیم پنل.
- UIA و صدا هنوز به PowerShell ثابت وابسته‌اند؛ مهاجرت به Python/COM پیشنهاد فاز بعدی است.

## فاز بعدی پیشنهادی
فاز ۳ (بلوتوث/USB/چاپگر/دوربین/Wi-Fi/DNS)، و پیش از آن مهاجرت UIA و صدا از PowerShell به `comtypes`/`pycaw` اگر در تست واقعی مشکل دیدی.


## بازبینی پس از تحویل فاز ۲ (اصلاحات)
1. **مجوز و تأیید:** `mouse_set`، `keyboard_set` و `power_set` حالا قبل از اجرا مقدار فعلی ← مقدار جدید را نشان می‌دهند و تأیید همان عملیات را می‌گیرند (سطح CONTROL + ویژگی مستقل `requires_confirmation`؛ از Phase 2r2 دیگر PROTECTED نیستند). والپیپر، تم، Taskbar، اعلان و روشنایی لپ‌تاپ برگشت‌پذیر و بازخوانی‌شونده‌اند و بدون تأیید می‌مانند. در فاز ۲ ابزار شبکه‌ای وجود ندارد؛ `network_adapter_set` (فاز قبل) از قبل ELEVATED + تأیید + UAC است و شبکه در فاز ۳ با همین قاعده می‌آید.
2. **تراکنش و Rollback:** هر `*_set` اول وضعیت فعلی را می‌خواند؛ اگر مرحله‌ای شکست بخورد یا بازخوانی با مقدار خواسته‌شده نخواند، وضعیت قبلی نوشته و دوباره خوانده می‌شود. پیام نتیجه می‌گوید بازگردانی تأیید شد یا وضعیت `UNKNOWN` است. در `power_set` اول مقدارها و آخر تعویض plan انجام می‌شود تا Rollback فقط یک plan را درگیر کند. آخرین تغییر موفق با `settings_undo` برمی‌گردد (فقط در همان اجرای برنامه).
3. **روشنایی:** نام ابزار `laptop_brightness_*` شد و توضیح مدل می‌گوید فقط صفحه‌ی داخلی لپ‌تاپ از طریق Power plan است؛ روی PC بدون باتری رد می‌شود و هیچ‌جا «کنترل مانیتورها» معرفی نمی‌شود.
4. **Taskbar و Explorer:** Kira هیچ‌وقت Explorer را ریستارت نمی‌کند. اگر چینش بلافاصله دیده نشود، نتیجه `UNVERIFIED` است و به کاربر گفته می‌شود خروج/ورود یا ریستارت Explorer را خودش انجام دهد. ریستارت Explorer در صورت نیاز باید ابزار جداگانه‌ی تأییدشده باشد (فعلاً وجود ندارد).
5. **PowerShell:** وابستگی UIA، صدا و Bluetooth در `docs/TECH_DEBT_FA.md` ثبت شد و فهرست آن‌ها در کد منجمد است (`POWERSHELL_FROZEN`)؛ ثبت قابلیت جدید با Backend وابسته به PowerShell خطا می‌دهد تا مهاجرت بررسی شود.


## Phase 2r2 — تفکیک Permission از Confirmation + ممیزی ایستا
- `requires_confirmation` ویژگی مستقل شد (`Tool`, `Capability`, `Policy.needs_confirmation`)؛ PROTECTED یعنی «فقط با درخواست مستقیم و صریح کاربر در همان پیام» و `intent_rx` برایش اجباری است؛ بعد از خواندن محتوای خارجی در همان نوبت رد می‌شود. تأیید راه دور زدن آن نیست: اول درخواست مستقیم بررسی می‌شود، بعد تأیید.
- مثال‌ها: ماوس/کیبورد/Power/`settings_undo` = CONTROL + تأیید؛ `process_kill` و `app_uninstall` = PROTECTED + درخواست مستقیم + تأیید؛ `network_adapter_set` = ELEVATED + تأیید + UAC.
- **محدودیت‌های مستند:** `settings_undo` فقط در همان اجرای برنامه کار می‌کند و فقط آخرین تغییر را برمی‌گرداند. `UNKNOWN` یعنی وضعیت واقعی ویندوز نامشخص است (نه موفقیت و نه شکست قطعی).
- **Rollback و Journal:** Rollback فقط داخل عملیاتی اجرا می‌شود که قبلاً مجوز/تأیید گرفته (handler بعد از آن اجرا می‌شود) و فقط مقادیری را برمی‌گرداند که همان فراخوانی چند لحظه قبل خوانده بود. نتیجه‌اش (`verified` یا `unknown`) با `AccessManager.record_event` در Journal ثبت می‌شود؛ `settings_undo` خودش یک ابزار جدا با تأیید است.
- **قفل PowerShell واقعاً اعمال می‌شود:** `POWERSHELL_FROZEN` در `registry.py` تعریف شد و هم در `ToolRegistry.register()` (برای هر ابزاری) و هم در `WindowsControlLayer._validate()` اعمال می‌شود؛ ثبت ابزار جدید با Backend ‎`powershell-fixed`/`uia`‎ ValueError می‌دهد.


---

# T6 — فاز ۳: دستگاه‌ها و شبکه

> بدون PowerShell برای ابزارهای جدید (قفل `POWERSHELL_FROZEN` اعمال است)، بدون Administrator مگر `dns_flush` (ELEVATED + تأیید + UAC). منابع: `psutil` (اختیاری) + رجیستری، `netsh`/`ping`/`pnputil` از System32 با آرگومان ثابت (`kira/tools/sysexe.py`)، `ctypes` (چاپگر). **هیچ تستی اجرا نشد؛ فقط `py_compile` و `ruff`.**

## معیار پذیرش هر ابزار
| ابزار | ورودی ← خروجی | سطح / تأیید | بازبینی نتیجه | شکست یا توقف | بازگردانی |
|---|---|---|---|---|---|
| `network_status` | `show_all` ← IP/Gateway/DNS/DHCP/سرعت هر آداپتور | READ / خیر | — | بدون psutil: فقط فهرست رجیستری، وضعیت زنده «نامعلوم» | — |
| `network_ping` | `host` (اعتبارسنجی‌شده)، `count` ۱ تا ۸ ← پاسخ/افت | READ / خیر | شمارش `TTL=` | «بدون پاسخ» دلیل قطعی نیست (ICMP) | — |
| `network_diagnose` | — ← ۴ مرحله + «علت محتمل» | READ / خیر | هر مرحله جدا | نتیجه همیشه «احتمال» است | — |
| `wifi_status/profiles/scan` | — ← SSID/سیگنال/نام‌های ذخیره‌شده/شبکه‌های دیده‌شده | READ / خیر | — | ویندوز غیرانگلیسی ⇒ **UNVERIFIED** | — |
| `wifi_connect` | `profile` از فهرست ذخیره‌شده ← اتصال | CONTROL + **تأیید** (از ← به) | وضعیت `netsh wlan show interfaces` تا ۱۵ ثانیه + تست دسترسی | شکست ⇒ **Rollback به شبکه‌ی قبلی** و خط Journal (`wifi.rollback`)؛ وضعیت ناخواندنی ⇒ UNVERIFIED/UNKNOWN | بله (همان Rollback) |
| `wifi_disconnect` | — ← قطع | CONTROL + **تأیید** | state ≠ connected تا ۱۰ ثانیه | هنوز وصل ⇒ خطا | با `wifi_connect` |
| `dns_flush` | — ← پاک‌سازی کش | **ELEVATED + تأیید + UAC** | کش قابل بازخوانی نیست ⇒ **UNVERIFIED** | رد UAC ⇒ بدون تغییر | لازم نیست (کش خودبه‌خود پر می‌شود) |
| `device_list` | `kind` ∈ usb/bluetooth/camera/microphone/printer ← نام + سازنده + وضعیت | READ / خیر | — | pnputil قدیمی ⇒ `missing_component`؛ سریال دستگاه نشان داده نمی‌شود | — |
| `printer_list` / `printer_set_default` | نام دقیق چاپگر نصب‌شده | READ / CONTROL، بدون تأیید | پیش‌فرض دوباره خوانده می‌شود | نچسبید ⇒ چاپگر قبلی برگردانده و Journal (`printer.rollback`) | بله |
| `device_privacy_get` | — ← مجاز/مسدود بودن دوربین و میکروفون | READ / خیر | — | کلید رجیستری نبود ⇒ «خوانده نشد» | — |

## جدول وضعیت
| قابلیت | وضعیت |
|---|---|
| IP / DNS / Gateway / DHCP، ping، عیب‌یابی مرحله‌ای | IMPLEMENTED_UNTESTED |
| Wi-Fi: وضعیت، پروفایل‌های ذخیره‌شده، اسکن | LIMITED (برچسب‌های انگلیسی netsh؛ وگرنه UNVERIFIED) |
| Wi-Fi: اتصال/قطع (فقط پروفایل ذخیره‌شده) | LIMITED — شبکه‌ی جدید با رمز، ساخت پروفایل و ذخیره‌ی رمز: **UNSUPPORTED عمداً** |
| Ethernet: وصل/قطع آداپتور | IMPLEMENTED_UNTESTED (`network_adapter_set`، ELEVATED، فاز قبل) |
| پاک‌سازی کش DNS | IMPLEMENTED_UNTESTED، نتیجه UNVERIFIED (UAC) |
| تغییر DNS / IP ثابت / release-renew / Winsock reset | UNSUPPORTED (Administrator + ریسک قطع شبکه؛ فقط به‌صورت ELEVATED محدود در فاز بعدی) |
| فهرست USB / Bluetooth / دوربین / چاپگر | LIMITED (pnputil ویندوز ۱۰ نسخه‌ی 2004 به بعد) |
| فهرست میکروفون | LIMITED (حدس از نام نقطه‌ی صدا؛ کامل‌بودن تضمین نیست) |
| چاپگر پیش‌فرض | IMPLEMENTED_UNTESTED |
| جفت‌کردن/وصل/قطع دستگاه Bluetooth | UNSUPPORTED (WinRT؛ بعد از مهاجرت PowerShell) |
| خاموش/روشن Bluetooth | از قبل (`bluetooth_on/off`، PowerShell ثابت، منجمد) |
| Eject/غیرفعال‌کردن USB، فعال/غیرفعال‌کردن دوربین یا میکروفون | UNSUPPORTED (Administrator یا تصمیم حریم خصوصی) |
| تغییر مجوز دسترسی برنامه‌ها به دوربین/میکروفون | **PROTECTED به‌معنای سیاست: فقط گزارش و راهنمایی دستی** (`device_privacy_get` فقط می‌خواند) |
| صف چاپ، چاپ سند | UNSUPPORTED |

## عملیات نیازمند UAC
`dns_flush` (جدید)، `network_adapter_set`، `service_restart`. همه ELEVATED: تأیید همان عملیات ← UAC فقط برای همان یک عملیات.

## محدودیت‌های سخت‌افزاری و نرم‌افزاری
Wi-Fi بدون آداپتور/سرویس WLAN؛ ویندوز غیرانگلیسی (برچسب netsh)؛ pnputil قدیمی؛ نبود `psutil`؛ فیلتر/ICMP مسدود روی شبکه‌ی شما نتیجه‌ی ping و تست اینترنت را فریب می‌دهد (هدف‌های تست چندتاست و نتیجه «احتمال» گزارش می‌شود).

## ریسک‌های باقی‌مانده
- هیچ تست واقعی روی ویندوز؛ رفتار `netsh wlan connect`، `pnputil /enum-devices`، `SetDefaultPrinterW` و ساختار رجیستری شبکه باید روی سیستم واقعی دیده شود.
- قطع Wi-Fi یا اتصال به شبکه‌ی دیگر ارتباط Kira با مدل‌های ابری را می‌بُرد؛ برای همین هر دو تأیید می‌گیرند و Rollback دارند.
- Rollback وقتی خود Wi-Fi قطع است ممکن است نتواند وضعیت را تأیید کند؛ آن‌گاه `UNKNOWN` گزارش می‌شود.

## فاز بعدی پیشنهادی
فاز ۴ (CPU/RAM/GPU/دیسک، سرویس‌ها، Sleep/Hibernate/Restart/Shutdown، عملیات Administrator، آماده‌سازی Office). پیش از آن اگر Bluetooth یا UIA/صدا در تست مشکل داشتند، مهاجرت PowerShell → Python/COM (`docs/TECH_DEBT_FA.md`).


---

# T6 — فاز ۴: Power و نشست کاربر

**وضعیت: IMPLEMENTED_UNTESTED.** هیچ تست یا اجرایی انجام نشد؛ فقط Syntax، ثبت در رجیستری و بررسی ایستای دروازه‌ی نیت/تأیید. همه‌ی کدها در `kira/tools/power.py` و فقط **Win32 (ctypes)** هستند: بدون PowerShell (فهرست منجمد رعایت شد)، بدون `shutdown.exe`، بدون Shell، **بدون UAC**.

## ابزارها و سطح مجوز
| ابزار | کار | سطح | تأیید | نیت مستقیم در همان پیام |
|---|---|---|---|---|
| `power_status` | Hibernate در دسترس است؟ صفحه قفل است؟ خاموشی/ریستارت زمان‌بندی‌شده‌ی Kira | READ | خیر | خیر |
| `power_lock` | قفل ویندوز (مثل Win+L) | CONTROL | خیر (بدون از دست رفتن کار؛ با رمز برمی‌گردد) | بله |
| `power_cancel` | لغو ریستارت/خاموشی زمان‌بندی‌شده + Sleep/Hibernate/Logoff که هنوز شروع نشده | CONTROL | خیر | بله |
| `power_sleep` | Sleep (۳ ثانیه بعد از پاسخ) | PROTECTED | **بله** | بله |
| `power_hibernate` | Hibernate (۳ ثانیه بعد) | PROTECTED | **بله** | بله |
| `power_restart` | ریستارت با شمارش معکوس (پیش‌فرض ۳۰ ثانیه، ۱۰ تا ۶۰۰) | PROTECTED | **بله** | بله |
| `power_shutdown` | خاموشی با شمارش معکوس | PROTECTED | **بله** | بله |
| `power_logoff` | خروج از حساب (۳ ثانیه بعد) | PROTECTED | **بله** | بله |

«PROTECTED» در این نسخه‌ی T5 یعنی: فقط وقتی اجرا یا حتی پیشنهاد می‌شود که **پیام فعلی کاربر** مستقیماً آن را خواسته (`intent_rx` اختصاصی هر ابزار؛ «ریستارت کن» اجازه‌ی خاموش‌کردن نمی‌دهد)، در نوبتی که محتوای خارجی خوانده شده هرگز، و سپس تأیید صریح همان ابزار با همان پارامترها (یک‌بارمصرف، ۵ دقیقه، Stop باطلش می‌کند). Agent هیچ‌کدام را به ابتکار خودش نمی‌تواند اجرا کند.

## طراحی ایمنی
- **بدون Administrator و بدون UAC:** کاربر عادی ویندوز حق خاموش‌کردن (`SeShutdownPrivilege`) را دارد ولی غیرفعال است؛ Kira فقط همان حق موجود را برای فرایند خودش فعال می‌کند (مثل منوی Start). اگر سیاست سیستم/سازمان آن را نداده باشد، نتیجه `permission_denied` است و Kira دور نمی‌زند و Administrator هم درخواست نمی‌کند.
- **بدون اجبار به بستن برنامه‌ها:** `bForceAppsClosed=FALSE` و بدون `EWX_FORCE`؛ برنامه‌ی دارای کار ذخیره‌نشده می‌تواند ریستارت/خاموشی/خروج را متوقف کند و ویندوز دیالوگ خودش را نشان می‌دهد. این عمداً است تا کار کاربر از بین نرود؛ پس «پذیرفته شدن درخواست» با «انجام شدن» یکی نیست.
- **شمارش معکوس قابل‌لغو:** ریستارت/خاموشی حداقل ۱۰ ثانیه تأخیر دارند و ویندوز اعلان خودش را نشان می‌دهد. Sleep/Hibernate/Logoff سه ثانیه بعد از پاسخ شروع می‌شوند تا Kira بتواند بگوید چه می‌شود و `power_cancel` بتواند متوقفشان کند.
- **Hibernate بی‌صدا به Sleep تبدیل نمی‌شود:** پیش از پرسش، پشتیبانی S4 و وجود فایل hibernation خوانده می‌شود؛ اگر نبود یا نامعلوم بود (`UNKNOWN`) اجرا نمی‌شود. فعال‌کردن Hibernate (`powercfg /hibernate on`) Administrator می‌خواهد و **عمداً ساخته نشد** (فقط راهنمای دستی).
- اگر یک خاموشی/ریستارت از قبل زمان‌بندی شده باشد، دومی رد می‌شود و پیام می‌گوید اول لغو کن.

## بررسی نتیجه (صادقانه)
| عملیات | وضعیت نتیجه |
|---|---|
| restart / shutdown / sleep / hibernate / logoff | **UNVERIFIED** همیشه: خود Kira با سیستم/نشست تمام می‌شود و وضعیت نهایی قابل‌خواندن نیست؛ فقط «ویندوز درخواست را پذیرفت» گزارش می‌شود و ژورنال `verification=unverified` می‌گیرد |
| lock | بررسی تقریبی (Heuristic): دسکتاپ ورودی دیگر در دسترس نیست؛ اگر تأیید نشد UNVERIFIED |
| cancel | پاسخ واقعی ویندوز؛ «چیزی در جریان نبود» خطا نیست و صریح گفته می‌شود |
| sleep/hibernate/logoff شکست‌خورده بعد از پاسخ | در `power_status` («آخرین عملیات تأخیری شکست خورد») دیده می‌شود |

علت‌های خطا با `kind` ثبت می‌شوند: `permission_denied`، `missing_component` (Hibernate فعال نیست)، `api_failure` (خاموشی از قبل زمان‌بندی‌شده / رد API)، `bad_args` (تأخیر خارج از بازه). ژورنال مرکزی `uac_required=false` و `uac_used=false` را برای همه نشان می‌دهد.

## محدودیت‌ها و ریسک‌های باقی‌مانده
- هیچ‌چیز روی ویندوز واقعی آزموده نشد: ساختارهای `ctypes` (توکن/Privilege، `InitiateSystemShutdownExW`، `SetSuspendState`، `CallNtPowerInformation`) مهم‌ترین نقاط خطرند؛ اشتباه در آن‌ها معمولاً به شکل خطای صریح می‌آید ولی تأیید نشده.
- افست‌های بایت `SYSTEM_POWER_CAPABILITIES` (S4=بایت ۶، HiberFilePresent=بایت ۸) از مستندات برداشته شده؛ اگر روی ویندوز واقعی اشتباه بود، Hibernate به‌جای اجرا خطای `UNKNOWN` می‌دهد (اجرای ناخواسته‌ی Sleep ممکن نیست).
- تشخیص قفل‌بودن با `OpenInputDesktop` یک روش رایج ولی غیررسمی است.
- Stop تأییدهای در انتظار را باطل می‌کند ولی خاموشی/ریستارتی را که قبلاً زمان‌بندی شده **خودکار لغو نمی‌کند**؛ برای آن «لغو کن» لازم است.
- `power_status` نمی‌تواند خاموشی‌ای را که برنامه‌ی دیگری زمان‌بندی کرده بخواند (Windows API عمومی برایش ندارد)، ولی `power_cancel` آن را هم لغو می‌کند.
- نام‌گذاری دستورها: `power_cancel` عبارت‌های «نکن/stop/صبر کن» را هم به‌عنوان نیت می‌پذیرد؛ بی‌خطر است چون فقط لغو می‌کند.
- Sleep/Hibernate را به‌جای CONTROL با تأیید، PROTECTED گذاشتم تا هرگز به ابتکار مدل (مثلاً شنیدن اشتباه در Voice) رخ ندهند؛ اگر سبک‌تر می‌خواهی در فاز بعد قابل‌تغییر است.

## بعدی (پیشنهاد)
فاز ۵: سرویس‌ها و عملیات Administrator با UAC (گسترش `elevation.py`، از جمله فعال‌سازی Hibernate)، سپس Office و تنظیمات پیشرفته‌ی نمایشگر.
