# Kira UI redesign

## Stage 2: navigation and responsive shell

- Replaced the two-icon-plus-overflow-menu navigation with a persistent navigation rail exposing all six main destinations: Chat, Assistant, Voice, Character, General settings, and Routes.
- Added dedicated line icons for Assistant, Voice, Character, and Settings.
- Kept the existing `QTabWidget` as the page stack. Page construction, settings storage, route handling, and feature callbacks remain in place.
- Added a compact rail mode for narrow windows. It switches to icon-only navigation and hides secondary labels; the avatar panel also collapses sooner to preserve chat width.
- Moved the existing Save settings action into the navigation rail and retained its original callback and visibility rule.
- Added Persian/English localization for the navigation section heading and registered nav labels/tooltips with the existing translation mechanism.
- Added a consistent dark-glass rail surface and active/hover states to the shared theme.

## Stage 2 safety boundaries

Stage 2 changes presentation and navigation only. It does not change provider credentials, route priority, model selection, chat persistence, memory, voice, or tool execution logic.

## Stage 2 verification

- `python -m compileall -q kira` passed.
- `git diff --check` passed.
- 58 targeted unit tests passed; 3 were skipped because PySide6 is unavailable in this build environment or the test requires Windows DPAPI.
- GUI rendering and interactive resize behavior still need a run on the Windows 11 target machine with the project's installed PySide6 dependencies.


## Stage 3: chat presentation and interaction

- Added safe inline Markdown presentation for bold/italic/strikethrough, inline code, headings, lists, fenced code blocks, and blockquotes. Raw HTML remains escaped; code and quote containers use a restrained dark-glass palette.
- Added a per-message copy action. It copies the original message text, not the rendered HTML. Streaming updates omit the copy payload until the final flush to avoid repeatedly encoding a growing response.
- Routed local `kira-copy:` links through a dedicated handler; regular web and file links continue to open through the operating system.
- Added an animated, compact processing indicator for connection, waiting, attachment upload, failover, and tool/plan activity. It is hidden when streaming begins and when the request finishes.
- Added a short eased scroll for discrete messages. Streaming continues to track the live response without repeatedly restarting the scroll animation.
- Kept message persistence, router behavior, route selection, memory, voice, and tool execution unchanged.

## Stage 3 verification

- `python -m compileall -q kira tests` passed.
- Targeted chat-render tests passed: 8 passed, 2 skipped because PySide6 is unavailable.
- Full suite: **524 tests, OK; 79 skipped; 0 failures/errors**.
- Qt widget behavior, clickable copy actions, animation timing, and Windows 11 rendering remain `IMPLEMENTED_UNTESTED` until exercised on the Windows target with PySide6 installed.
