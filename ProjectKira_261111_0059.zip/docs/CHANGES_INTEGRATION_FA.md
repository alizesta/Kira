# تغییرات T0 تا T4 در Kira (انگلیسی‌سازی، حافظه‌ی شواهدمحور، مغز چندمرحله‌ای، MCP/ایجنت، مصرف)

این فایل با هر تحویل (هر تسک) کامل‌تر می‌شود. قواعد: هیچ تستی ساخته یا اجرا نشده؛ برنامه اجرا نشده؛ فقط بررسی ایستای syntax انجام شده است.

## v7 — T0: انگلیسی‌سازی متن‌های چینی/ژاپنی

**چه چیزی پیدا شد:** در کل پروژه فقط ۱۳ خط در ۷ فایل `.py` حاوی کاراکتر چینی/ژاپنی بود. همه *کاراکتر عملکردی* بودند، نه متن توضیحی.

**چه کاری شد:** کاراکترها با escape یونیکد (`\uXXXX`) جایگزین شدند و بالای هر مورد کامنت انگلیسی آمد. مقدار نهایی رشته‌ها و ساختار regexها بایت‌به‌بایت (از نظر معنایی) یکسان است؛ این موضوع با مقایسه‌ی AST و parse کردن regexهای قبل و بعد بررسی شد.

| فایل | چه بود | الان |
|---|---|---|
| `kira/cloud_voice.py` | پایان‌دهنده‌های جمله `。！？` | `。！？` + کامنت |
| `kira/emotion/parser.py` | کلیدواژه‌ی «احساس» به چینی و `：` | escape + کامنت |
| `kira/leak_guard.py` | `：` تمام‌عرض (۳ جا) | `：` + کامنت |
| `kira/persona_memory.py` | `？` تمام‌عرض (۴ جا) | `？` + کامنت |
| `kira/speech_split.py` | `TERMS` و توضیح docstring | escape + توضیح انگلیسی |
| `kira/strings.py` | جمله‌ی نمونه‌ی ژاپنی TTS | escape + ترجمه‌ی انگلیسی در کامنت |
| `kira/tools/tasks.py` | `：` در جداکننده‌ی «مرحله اضافه کن» | `：` + کامنت |

**عمداً دست نخورد:** متن فارسی (پیام‌های کاربر، regexهای فارسی، مستندات `_FA.md`). این‌ها زبان خود محصول‌اند و ترجمه‌شان رفتار را تغییر می‌دهد.

**قانون از این به بعد:** همه‌ی کد، کامنت و پرامپت‌های جدید انگلیسی نوشته می‌شوند؛ فقط متنی که به کاربر نشان داده می‌شود فارسی است.

---

## v8 — T1: حافظه‌ی مبتنی بر شواهد

مستندات کامل: `docs/MEMORY_EVIDENCE_FA.md`.

**فایل‌های جدید**
- `kira/evidence_memory.py` — ذخیره‌ی واقعیت + شاهد، تناقض/عدم‌قطعیت، BM25، Embedding اختیاری، RRF، قرنطینه، پر کردن از تاریخچه.
- `docs/MEMORY_EVIDENCE_FA.md`

**فایل‌های تغییرکرده**
- `kira/persona_memory.py` — `extract_facts_detailed` (همان قواعد قبلی + نقل‌قول)، `extract_facts` همان خروجی قبلی؛ `observe` به لایه‌ی شواهد هم می‌نویسد؛ حذف/ویرایش/فراموشی هر دو لایه را هماهنگ می‌کند؛ `build_block(query, budget)` با fallback کامل به رفتار قبلی.
- `kira/memory.py` — فقط‌خواندنی: `rows_with_ids`، `max_message_id`.
- `kira/main.py` — سه خط: `configure` در شروع و بعد از ذخیره‌ی تنظیمات، و ارسال پیام فعلی و بودجه به `build_block`.
- `kira/config.py` — پنج کلید پیش‌فرض.
- `kira/storage.py` — پشتیبان‌گیری از `kira_evidence.sqlite3`.

**چه چیزی عمداً دست نخورد:** Active Mode، شخصیت، Relationship Memory (لحظه‌ها، عادت‌ها، خلاصه‌ها)، پنجره‌ی حافظه، Web Research، Taskها.
**عمداً پیاده نشد:** فراخوانی خودکار مدل برای استخراج واقعیت (مصرف API)؛ UI برای تنظیمات Embedding (خارج از محدوده).

**نیاز به اعتبارسنجی روی Windows**
1. اولین اجرا با دیتابیس قدیمی: ساخته شدن `kira_evidence.sqlite3` و نبود خطا.
2. پنجره‌ی حافظه: افزودن، ویرایش، حذف و «فراموش‌کردن همه».
3. جمله‌ی «اسمم X است» و بعد «نه، اسمم Y است»: فقط Y در prompt بیاید.
4. با `embedding_backend=ollama` و مدل واقعی: سرعت اولین پیام و رفتار هنگام خاموش بودن Ollama.
5. اندازه‌ی واقعی بلوک حافظه روی Qwen 3.5 4B با `num_ctx=4096`.

---

## v9 — T2: مغز چندمرحله‌ای

مستندات: `docs/BRAIN_FA.md`.

**فایل‌های جدید:** `kira/brain.py`، `docs/BRAIN_FA.md`

**فایل‌های تغییرکرده**
- `kira/hybrid_ai.py` — `role_scope(role, route_id)`؛ route ترجیحی اول می‌آید و بقیه‌ی ترتیب/failover/cooldown دست‌نخورده است؛ فیلد `role` در metrics.
- `kira/evidence_memory.py` — `current_value`، `writer_cursor`، `set_writer_cursor`.
- `kira/main.py` — `StreamWorker(role, route_id)`؛ `start_worker` مرحله را تعیین و پرامپت را (فقط در صورت نیاز) گسترش می‌دهد؛ `on_stream_done` → `brain.after_turn`؛ `clear_chat` → `brain.reset_state`.
- `kira/config.py` — چهار کلید پیش‌فرض.

**عمداً پیاده نشد:** بازنویسی پاسخ پس از نمایش؛ تماس مدل خودکار در حالت پیش‌فرض؛ UI برای `role_routes`.

**نیاز به اعتبارسنجی روی Windows**
1. پیام ساده: پرامپت و رفتار دقیقاً مثل قبل.
2. پیام بلند/تحلیلی: deep انتخاب شود و پاسخ عادی بیاید؛ روی Qwen 4B (`num_ctx=4096`) بلوک اضافه نشود.
3. `role_routes.deep` روی یک route دیگر: همان route اول امتحان شود و در خطا به ترتیب عادی برگردد.
4. ادعای «انجام دادم» بدون ابزار موفق: نوبت بعد فقط یک یادداشت کوتاه اعمال شود.
5. `brain_reflection="model"` و `brain_memory_writer="idle"`: فریز نشدن UI و رعایت سقف‌ها.

---

## v10 — T3: MCP و ایجنت‌های مستقل

مستندات: `docs/MCP_AGENTS_FA.md`، نمونه: `docs/kira_mcp.example.json`.

**فایل‌های جدید:** `kira/mcp/{__init__,config,client,hub,agents}.py`، دو فایل docs بالا.

**فایل‌های تغییرکرده**
- `kira/tools/registry.py` — قفل و `unregister_where` (ثبت ابزار از thread پس‌زمینه).
- `kira/tools/protocol.py` — دسته‌های `mcp` و `agents`، `set_gate_words`، `MCP_RULES` (فقط وقتی مربوط باشد).
- `kira/tools/agent.py` — `install` در `ToolAgent.__init__` (در try)، برچسب ابزارها، قواعد MCP.
- `kira/config.py` — `mcp_mode`.

**عمداً پیاده نشد:** ثبت سرور توسط مدل؛ UI؛ OAuth؛ اعلان خودکار پایان کار.

**نیاز به اعتبارسنجی روی Windows:** فهرست در `docs/MCP_AGENTS_FA.md`.

---

## v11 — T4: ردیابی مصرف و هزینه

مستندات: `docs/USAGE_FA.md`.

**فایل جدید:** `kira/usage.py`، `docs/USAGE_FA.md`

**فایل‌های تغییرکرده**
- `kira/hybrid_ai.py` — `last_usage` و `_note_usage` در provider؛ `stream_options.include_usage` برای Groq/OpenRouter؛ `_ledger` در `_finish` و مسیر شکست کامل؛ اعمال محدودیت‌ها در `_candidates`.
- `kira/main.py` — `usage.install` (شروع و بعد از ذخیره‌ی تنظیمات)، دستور `/usage`.
- `kira/config.py` — `model_prices`، `usage_limits`.
- قلاب‌های T1/T2 (`evidence_memory.usage_hook`، `brain.budget_check`) حالا وصل‌اند.

**عمداً پیاده نشد:** UI مصرف، تخمین توکن از طول متن، قطع گفتگو به‌خاطر محدودیت.

**نیاز به اعتبارسنجی روی Windows:** `docs/USAGE_FA.md`.

---

## v12 — یکپارچه‌سازی T0 تا T4

**ممیزی (بدون اجرای تست تا قبل از مرحله ۱۰):** گراف importها بررسی شد؛ چرخه‌ی واقعی در زمان import وجود ندارد (`kira.mcp` فقط به‌صورت lazy از `ToolAgent` بارگذاری می‌شود). داده‌های جدید همه در `DATA_DIR` (`%LOCALAPPDATA%\Kira`) هستند و با به‌روزرسانی برنامه از بین نمی‌روند: `kira_evidence.sqlite3`، `kira_brain_state.json`، `kira_jobs.json`، `kira_usage.sqlite3` و `kira_mcp.json`.

**اصلاح‌ها**
1. پلنر خودکار (`autonomy._cats_for`): بدون دسته‌ی تشخیص‌داده‌شده، کاتالوگ MCP و ایجنت به پرامپت نمی‌رود (فقط وقتی نام‌شان آمده باشد).
2. `brain.check_reply`: «نیازمند تأیید» دیگر «پنهان‌کردن خطا» حساب نمی‌شود (فقط error/denied/bad_args/unknown).
3. `brain._small_context`: پیش‌نمایش route داخل نقش درست انجام می‌شود (تشخیص مدل کوچک محلی روی route نقش deep).
4. embedding محلی (Ollama) در دفتر مصرف «محلی» ثبت می‌شود، نه Unknown.
5. `agent_ask`: ایجنت ناشناخته قبل از بررسی نقل‌قول گزارش می‌شود.
6. کلید قیمت `model_prices` می‌تواند فقط نام provider باشد.
7. pipeهای زیرپروسه‌ی MCP هنگام بستن آزاد می‌شوند.
8. حذف ارجاع‌های پروژه‌ی مرجع از کد و docs؛ فایل تغییرات به `CHANGES_INTEGRATION_FA.md` تغییر نام داد؛ README فهرست مستندات جدید را دارد.

**تست‌ها (مرحله ۱۰)**
- فایل جدید `tests/test_integration_t0_t4.py` — ۲۷ تست: حافظه (supersede، رد نقل‌قول نامعتبر)، مغز (مرحله، hint تک‌بار، ماندگاری state)، route نقش و failover، دفتر مصرف (توکن گزارش‌شده، Unknown، هزینه، شکست، محدودیت provider و نقش)، MCP با سرور واقعی stdio (سطح پیش‌فرض، نادیده‌گرفتن annotation، env بدون کلید، allow/deny، سرور خراب)، ایجنت‌ها با سرور HTTP محلی (نقل‌قول، تأیید، idempotency، پاسخ کاربر، سلامت، ری‌استارت، توقف) و سیم‌کشی `ToolAgent`.
- مجموعه‌ی تست‌های قبلی: همه سبز به‌جز موارد زیر که **در v6 هم دقیقاً همین‌طور بودند** (تغییر ما نیستند): `test_image_search` (نیاز به PySide6 در محیط تست)، `test_release::requirements` (تست قدیمی `psutil` را نمی‌شناسد)، و سه تست `test_streaming` (تست‌ها انتظار chunkهای جدا دارند ولی `LeakGuard` چند حرف اول را جمع می‌کند؛ یک مورد آن واقعاً نشان می‌دهد قطع ارتباط بعد از متن خیلی کوتاه می‌تواند به failover برسد).
- تست‌های GUI (PySide6) در این محیط اجرا نشدند (skipped).

**هنوز نیاز به اعتبارسنجی روی Windows 11:** فهرست‌های هر بخش در `MEMORY_EVIDENCE_FA`، `BRAIN_FA`، `MCP_AGENTS_FA` و `USAGE_FA`، به‌علاوه‌ی اجرای کامل برنامه با GUI و `run_tests.bat`.

---

## v13 — T5-A: عامل فایل

مستندات: `docs/FILE_AGENT_FA.md`.

**فایل جدید:** `kira/tools/fileagent.py`، `tests/test_file_agent.py` (۱۰ تست)، `docs/FILE_AGENT_FA.md`
**تغییرها:** `kira/tools/builtin.py` (ثبت)، `kira/tools/protocol.py` (کلمات دروازه‌ی دسته‌ی files: کپی، تغییر نام، مرتب کن، undo ...)، `kira/tools/agent.py` (برچسب‌ها).
**عمداً پیاده نشد:** Word/PDF، کنترل UI (T5-B به بعد)، حذف دائمی (همه‌ی حذف‌ها به سطل بازیافت می‌روند).

---

## v14 — T5-B: تعامل با دسکتاپ

مستندات: `docs/DESKTOP_FA.md`.

**فایل جدید:** `kira/tools/desktop.py`، `tests/test_desktop.py` (۱۴ تست با Backend جعلی)، `docs/DESKTOP_FA.md`
**تغییرها:** `wincontrol.py` (دامنه‌ی desktop)، `builtin.py` (ثبت ماژول)، `protocol.py` (دسته‌ی desktop و `DESKTOP_RULES`)، `agent.py` (برچسب‌ها و قواعد).
**عمداً پیاده نشد:** Word/Office (T5-C)، روشنایی/Wi-Fi (T5-D)، اسکرین‌شات و بینایی، کلید Windows و میانبرهای سیستمی.
**هشدار صادقانه:** منطق سیاست‌ها تست شده؛ خود فراخوانی‌های Win32 و اسکریپت UI Automation فقط روی Windows قابل اجرا هستند و اینجا اجرا نشده‌اند.

## T6-ToolFix — اطمینان ابزارها: Runner، اتصال وب، بستن برنامه

فقط سه بخش اول از تسک «Tool Reliability» انجام شد؛ بقیه‌ی تسک عمداً دست نخورد.

**فایل‌های تغییرکرده:** `kira/tools/winrunner.py`، `kira/tools/protocol.py`، `kira/tools/apps.py`، `kira/tools/builtin.py`، `kira/tools/agent.py`
**فایل جدید:** `kira/tools/appclose.py`
**حذف‌شده:** هیچ فایلی.

### ۱) Runner مشترک PowerShell (`winrunner.py`)
- PowerShell فقط با مسیر واقعی فایل پیدا می‌شود: Sysnative (فقط برای Python ‏32-bit روی ویندوز 64-bit) ← System32 ← SysWOW64. بازگشت به نام ساده‌ی `powershell.exe` از PATH حذف شد.
- اگر فایل نبود، خطای `missing_component` همراه با فهرست مسیرهای بررسی‌شده و bitness برمی‌گردد (نه فقط «پیدا نشد»).
- پوشه‌ی کاری ثابت (پوشه‌ی ویندوز)، `SystemRoot`/`windir` در محیط تضمین می‌شوند و stdin بسته است.
- خطاها جدا شدند: `permission_denied` (PermissionError / WinError 5)، WinError 193 (ناسازگاری bitness)، `timeout`، `powershell_failure`.
- JSON خروجی حتی با هشدار قبل یا بعدش خوانده می‌شود؛ stderr از قالب CLIXML پاک می‌شود؛ دیکد خروجی علاوه بر UTF-8 با کدپیج OEM/ANSI/cp1256 هم امتحان می‌شود.
- قرارداد قبلی (`FixedScript`، `KIRA_*`، کلید `fatal` و `kind`) تغییر نکرد؛ Audio و Bluetooth بدون تغییر کد از آن استفاده می‌کنند. دستور آزاد همچنان پذیرفته نمی‌شود.

### ۲) اتصال Web Intelligence (`protocol.py`)
- علت: دروازه‌ی دسته‌ی `web` فقط کلمه‌های «تحقیق / سرچ عمیق» را می‌شناخت. «سرچ کن» ساده، «GitHub» یا «اینترنت» ابزارهای وب را به مدل معرفی نمی‌کرد و مدل می‌گفت دسترسی ندارم.
- اصلاح: دروازه با «سرچ/جست‌وجو کن»، search، google/گوگل، github/گیت‌هاب، اینترنت، آنلاین، web، وب‌سایت گسترش یافت و در `WEB_RULES` قاعده‌ی «دسترسی وب را انکار نکن؛ خطای واقعی ابزار را بگو» اضافه شد.
- خود ماژول Web Intelligence و Registry تغییر نکردند.

### ۳) `close_app` و گارد باز/بستن (`appclose.py`، `apps.py`)
- ابزار جدید `close_app` (سطح CONTROL): پیام `WM_CLOSE` به پنجره‌های واقعی برنامه، سپس بررسی دوباره‌ی وضعیت: بسته شد / فقط پنجره بسته شد و برنامه در System Tray است (ناقص) / بسته نشد (پیام ذخیره، Minimize شدن، نادیده گرفتن، Not Responding، برنامه‌ی Administrator).
- فقط وقتی اجرا می‌شود که پیام فعلی کاربر صریح «ببند / close» داشته باشد (دروازه‌ی نیت مدیر دسترسی).
- تطبیق برنامه فقط با نام دقیق پردازش یا مسیر دقیق فایل است؛ Kira، کنسولی که Kira در آن اجرا شده، پردازش‌های سیستمی و Explorer هرگز بسته نمی‌شوند. PowerShell/CMD فقط با پنجره تطبیق می‌شوند و تب داخل Windows Terminal بسته نمی‌شود (Kira می‌پرسد).
- بستن اجباری فقط با ابزار موجود `process_kill` و تأیید کاربر.
- گارد در `open_app`: پیامی که «ببند» می‌گوید و «باز کن» نمی‌گوید هرگز به `open_app` نمی‌رسد. اگر کاربر یکی از برنامه‌های شناخته‌شده (Windows PowerShell، Windows Terminal، CMD، Steam، Wallpaper Engine، Notepad، Calculator) را نام برده باشد، `open_app` برنامه‌ی شناخته‌شده‌ی دیگری را به‌جای آن باز نمی‌کند.
- نام‌های فارسی و محاوره‌ای این برنامه‌ها (استیم، پاورشل، ترمینال، والپیپر انجین، ماشین حساب ...) شناخته می‌شوند. دروازه‌ی `apps` کلمه‌های «ببند / close» و نام‌های PowerShell/Terminal/CMD/Wallpaper Engine را هم گرفت.

### هنوز انجام نشده (از تسک Tool Reliability)
- باز کردن Windows PowerShell / Terminal / CMD با `open_app` (هنوز در `BLOCKED_EXES` است و مسیر ثابت ندارد).
- حافظه‌ی «سؤال باز» برای اتصال جواب کاربر به درخواست قبلی.
- سازوکار یکنواخت نتیجه‌ی `success / failed / partial / unknown` برای همه‌ی ابزارها (فقط `close_app` از `set_verification` استفاده می‌کند).
- بازبینی مسیر Audio و ابزار دوباره‌خوانی نتیجه (فقط ریشه‌ی «PowerShell پیدا نشد» در Runner اصلاح شد).

### نیازمند بررسی روی ویندوز واقعی
هیچ تستی ساخته یا اجرا نشد؛ فقط `py_compile` و یک import برای کامپایل شدن regexهای protocol. همه‌ی موارد بالا روی ویندوز آزموده نشده‌اند. به‌ویژه: رفتار `SendMessageTimeout` روی برنامه‌های Store، تشخیص Tray برای Steam و Discord، پنجره‌ی PowerShell داخل Windows Terminal، Sysnative روی Python ‏32-bit، و اینکه «سرچ کن» واقعاً ابزارهای وب را به مدل نشان می‌دهد.

## T6-GIF — ساخت GIF به‌عنوان بخشی از Image Generation

**ماژول جدید:** ندارد. منطق GIF (فریم‌ها ← یک GIF حلقه‌ای با Pillow) به انتهای `kira/imagegen.py` اضافه شد.
**ابزار جدید:** ندارد. `image_generate` پارامترهای `frames` (۱ = تصویر، ۲ تا ۸ = GIF)، `motion`، `duration_ms` و `ping_pong` گرفت.
**فایل‌های تغییرکرده:** `kira/imagegen.py`، `kira/tools/imagetool.py` (مسیر GIF و `IMAGE_RX` با کلمه‌های گیف/انیمیشن)، `kira/tools/protocol.py` (کلمه‌های گیف/انیمیشن در دروازه‌ی دسته‌ی `images`)، `kira/tools/agent.py` (برچسب)، `docs/IMAGE_GENERATION_FA.md`، `docs/TOOLS_FA.md`.
**حذف‌شده:** هیچ فایلی از نسخه‌ی قبلی T6-ToolFix.
**نکته‌ها:** بدون Backend PowerShell؛ Pillow وابستگی اختیاری است که `install.bat` از قبل نصب می‌کند.
**هشدار صادقانه:** فقط بررسی ایستا (کامپایل)؛ تست اجرا نشد و تست جدید اضافه نشد. ساخت واقعی GIF روی API و ویندوز آزموده نشده.

## T6-Experience — حافظهٔ تجربی و یادگیری محتاطانه از شکست

**ماژول جدید:** `kira/experience.py` (فقط یکی). مستند: `docs/EXPERIENCE_FA.md`.
**فایل‌های تغییرکرده:** `kira/tools/registry.py` (ثبت هر فراخوانی)، `kira/tools/sysaccess.py` (پایان نوبت)، `kira/tools/agent.py` (فلاش پایان نوبت و hint در prompt ابزار)، `kira/config.py` (تنظیم `experience_memory`).
**حذف‌شده:** هیچ فایلی.
**رفتار:** Episode + خودارزیابی ساده (Execution / Verification / Efficiency)؛ درس از «شکست ← موفقیت ابزار دیگر» فقط بعد از ۲ تأیید مستقل و بدون نقض به prompt می‌رسد؛ نوبت‌های دارای محتوای خارجی هیچ درسی نمی‌سازند. مجوزها و تأییدها دست نخوردند.
**هشدار صادقانه:** فقط بررسی ایستا (کامپایل)؛ تست اجرا نشد و تست جدید اضافه نشد. روی ویندوز و SQLite واقعی آزموده نشده.

## T6-Skills — Skill Library (مهارت به‌صورت داده) روی حافظهٔ تجربی

**ماژول جدید:** هیچ. جدول `skills` به `kira/experience.py` اضافه شد. مستند: `docs/EXPERIENCE_FA.md`.
**فایل‌های تغییرکرده:** `kira/experience.py`، `docs/EXPERIENCE_FA.md`، `docs/CHANGES_INTEGRATION_FA.md`. **تست جدید:** `tests/test_experience.py` (۱۳ تست).
**حذف‌شده:** هیچ فایلی.
**رفتار:** دنبالهٔ ابزارهای یک نوبت کاملاً موفق و بدون محتوای خارجی، به‌عنوان `candidate` ذخیره می‌شود (فقط نام ابزارها)؛ بعد از ۲ تأیید مستقل `verified` و فقط به‌صورت یک خط توصیه به prompt می‌رسد. نقض (شکست ابزارِ مهارت در درخواست مشابه) آن را برمی‌گرداند. مجوزها، تأیید و `intent_rx` دست نخوردند.
**نتیجهٔ تست:** تست‌های جدید پاس؛ کل مجموعه (۴۲۷ تست) ۵ شکست/خطای قبلی دارد (`test_streaming` ×3، `test_image_search.BubbleTests`، `test_release` requirements) که با ZIP قبلی هم دقیقاً همان‌ها هستند و به این تغییر ربطی ندارند. روی ویندوز واقعی آزموده نشده.

