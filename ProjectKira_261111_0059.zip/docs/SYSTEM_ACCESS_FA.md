# Unified System Access Manager (T5-Core)

کد: `kira/tools/sysaccess.py` (مدیر مرکزی) · `kira/tools/registry.py` (تنها نقطه‌ی اجرا: `execute()`) · `kira/tools/wincontrol.py` (اعلام قابلیت‌های ویندوز) · `kira/tools/winrunner.py` (تنها اجراکننده‌ی PowerShell).

هر ابزار — ویندوز (برنامه/بلوتوث/صدا/دسکتاپ)، فایل، وب، MCP، ایجنت — از `ToolRegistry.execute()` رد می‌شود و آنجا از مدیر مرکزی می‌پرسد. هیچ ماژولی سیستم Permission، تأیید یا ژورنال جدا ندارد؛ ماژول فقط **اعلام** می‌کند (سطح، شرط، Backend) و مدیر **اعمال** می‌کند. به هیچ Provider/مدلی وابسته نیست (پروتکل متنی همان قبلی است).

## سطوح دسترسی
**«سطح دسترسی» و «نیاز به تأیید» دو مفهوم جداگانه‌اند** (اصلاح T6-Phase2 review). `requires_confirmation` یک ویژگی مستقل است؛ ELEVATED همیشه آن را دارد، بقیه‌ی سطوح فقط اگر اعلام کنند. تأیید هرگز جای قاعده‌ی خود سطح را نمی‌گیرد.

| سطح | معنی | قاعده‌ی خودِ سطح | تأیید (`requires_confirmation`) |
|---|---|---|---|
| READ | فقط می‌خواند | — | ندارد |
| CONTROL | کنترل عادی و محدود برنامه‌ها/ویندوز | موارد حساس‌تر «درخواست صریح در همان پیام» (`intent_rx`) | اختیاری، مثلاً ماوس، کیبورد، Power، `settings_undo`، کلیک خام، کلیپ‌بورد، `process_close`، `app_install` |
| FILE | عملیات مجاز روی فایل/پوشه، همیشه داخل PathPolicy | مثل CONTROL | اختیاری، مثلاً حذف دائمی و عملیات گسترده |
| ELEVATED | نیازمند Administrator (`elevation.py`) | فقط عملیات از پیش تعریف‌شده | **همیشه** + سپس UAC فقط برای همان یک عملیات (`service_restart`، `network_adapter_set`، `dns_flush`) |
| PROTECTED | **هرگز با ابتکار Agent/مدل**: فقط وقتی پیام فعلیِ خودِ کاربر مستقیم و صریح همین را بخواهد | `intent_rx` **اجباری** (ثبت ابزار بدونش خطا می‌دهد)؛ بعد از خواندن محتوای خارجی در همان نوبت حتی برای تأیید هم پیشنهاد نمی‌شود | **همیشه** (تأیید جای درخواست مستقیم را نمی‌گیرد؛ اول درخواست مستقیم بررسی می‌شود، بعد تأیید) — مثال‌ها: `process_kill`، `app_uninstall` |

ابزارهای قدیمی بدون تغییر ثبت می‌شوند و سطحشان از `level` قدیمی می‌آید: READ→READ، ACTION→FILE (دسته‌ی files) یا CONTROL، **SENSITIVE→ همان CONTROL/FILE + `requires_confirmation`** (قبلاً PROTECTED بود؛ دیگر نیست). `windows_control_info` جدول کامل (سطح، دامنه، Backend، شرط) و آخرین عملیات را نشان می‌دهد. Journal در هر خط `confirmation_required` را جدا از `permission` ثبت می‌کند و Rollback/Undo تنظیمات هم خط جدا دارد (`settings.rollback`، `settings.undo`).

## قواعد (در کد، نه با اعتماد به مدل)
1. **تأیید به همان عملیات و پارامترها وصل است.** Agent فقط وقتی پیام خودِ کاربر یک «تأیید خالی» باشد (تأیید، بله، اوکی، انجام بده، yes ...) یک Grant یک‌بارمصرف، با انقضای ۵ دقیقه، برای همان `(ابزار، آرگومان‌ها)` می‌سازد؛ `execute()` دوباره بررسی‌اش می‌کند. Stop آن را باطل می‌کند.
2. **پیام تأیید ≠ پیام اجرا.** پیامی که عملیات را نام ببرد («حذفش کن»، «فایل دیگه رو پاک کن») دیگر تأیید حساب نمی‌شود؛ سؤال قبلی باطل و پیام به‌عنوان درخواست تازه رسیدگی می‌شود. «لغو/نه» عملیات را لغو می‌کند.
3. **درخواست صریح (`intent_rx`)**: پیام فعلی کاربر باید همان کار را بخواهد؛ مدل خودش نمی‌تواند راه بیندازد. (بلوتوث، صدا، دسکتاپ، فایل، وب، MCP؛ گارد وبِ جداگانه‌ی قبلی به همین‌جا آمد.)
4. **آلودگی (Taint)**: بعد از آنکه در همین پیام محتوای بیرونی خوانده شد (وب، `read_file`، MCP/ایجنت)، هر عملیات CONTROL/FILE که گارد صریح ندارد (مثل `open_url`، `open_app`، `open_path`) تأیید می‌خواهد؛ پس متن داخل یک صفحه یا سند نمی‌تواند بی‌صدا چیزی را باز کند.
5. **Backend**: هر عملیات Backend خودش را اعلام می‌کند (`win32`, `uia`, `com`, `sendinput`, `powershell-fixed`, `winrt`, `filesystem`, `network`, `external`). Backend جایگزین با `Capability.fallbacks` زنجیر می‌شود؛ Backend ناموجود `BackendUnavailable` می‌دهد و نفر بعدی امتحان می‌شود؛ آنکه واقعاً اجرا شد در ژورنال می‌آید.
6. **PowerShell آزاد وجود ندارد.** فقط `winrunner.FixedScript` (متن ثابت در کد، `-EncodedCommand`، داده از متغیر محیطی `KIRA_*`). UI Automation (دسکتاپ) و فهرست Store apps هم که مسیر جداگانه‌ی PowerShell داشتند حالا از همین اجراکننده می‌گذرند (و `-ExecutionPolicy Bypass` حذف شد). نام پارامترهایی مثل `command/script/shell/powershell/cmd` در ثبت رد می‌شود.
7. **ژورنال**: هر فراخوانی (مجاز، رد، منتظر تأیید، خطا) با سطح، Backend، آرگومان‌ها (متن‌های خصوصی فقط طول)، وضعیت، مدت و نتیجه‌ی واقعی در حافظه ثبت می‌شود (۳۰۰ مورد؛ روی دیسک نه). علامت «بازبینی‌شده» یعنی handler وضعیت واقعی را بعد از تغییر دوباره خوانده است.
8. اگر عملیات اجرا نشد، نتیجه‌ی ابزار `error/denied` است و مدل همان را می‌بیند؛ ادعای موفقیت از روی متن ابزار ساخته نمی‌شود.

## عملیات چندمرحله‌ای
مثال «صدای بازی رو کم کن و Notepad رو باز کن»: یک پیام تا ۳ فراخوانی در یک دور می‌دهد (`audio_list_apps` → `audio_change_app_volume` (بازبینی خودکار) → `open_app`)، و درخواست‌های بلندتر از Planner/Task موجود (`autonomy.py`) می‌گذرند که همین `execute()` و همین سیاست را صدا می‌زند. هر مرحله نتیجه‌ی واقعی خودش را دارد و گزارش نهایی هر دو را می‌گوید.

## افزودن ماژول جدید (Wallpaper / Tray / Wi-Fi / Display / Office ...)
1. دامنه در `DOMAINS` (`wincontrol.py`) هست یا یک خط اضافه کن.
2. `WinModule` با `domain` و `capabilities()` بنویس. هر `Capability`: `permission` (یا `risk`)، `intent_rx` برای CONTROL/FILE (یا `intent_optout` با دلیل)، `confirm_summary` برای ELEVATED/PROTECTED، `backend` و در صورت نیاز `fallbacks`، `verifies_result=True` اگر وضعیت را دوباره می‌خواند، `external=True` اگر خروجی‌اش محتوای دیگران است.
3. اسکریپت PowerShell لازم شد: `FixedScript(...)` در سطح ماژول + `run_fixed(script, env={"KIRA_X": json})`.
4. در `builtin.py`: `layer.register_module(MyModule(...))`. دسته‌ی نمایش تازه = یک خط در `protocol.GATES`.
هیچ Permission/تأیید/ژورنال جدا ننویس؛ اگر چیزی کم است به `sysaccess.py` اضافه کن تا برای همه باشد.

## ادغام‌شده، حذف‌شده، باقی‌مانده
- **ادغام‌شده:** گارد صریح بلوتوث/صدا/دسکتاپ در لایه (`_intent_ok`) و در Registry (دو نسخه) ← یک `check_intent` مرکزی؛ گارد وب درون handler ← مرکزی (`intent_alt` برای «ادامه‌ی تحقیق»)؛ ژورنال جدا در `WindowsControlLayer` (`OperationLog`) ← ژورنال مرکزی برای همه‌ی ابزارها؛ تشخیص تأیید با Regex پهن در Agent ← تأیید خالی + Grant؛ دو PowerShell جداگانه (دسکتاپ و Store apps) ← `winrunner`.
- **حذف‌شده (فقط سازوکار تکراری):** `OperationLog` و `WindowsControlLayer.log/info_text/_intent_ok`، `CONFIRM_RX` پهن، `_intent_ok` درون webtools، `-ExecutionPolicy Bypass`. هیچ قابلیت کاربردی حذف نشد.
- **باقی‌مانده بدون تغییر:** Audio، Bluetooth، Desktop، File Agent، App Launch، وب، MCP و Hybrid Brain؛ PathPolicy (سیاست مرکزی مسیرهای حساس و Secret)؛ گاردهای تخصصی دامنه (پنجره‌های ممنوع و کنترل‌های خطرناک در دسکتاپ) که «قاعده‌ی دامنه»‌اند نه Permission.

## محدودیت‌ها و موارد نیازمند اعتبارسنجی روی Windows 11
- هیچ تست/اجرایی انجام نشد؛ فقط Syntax (`py_compile`). همه‌ی رفتار باید روی Windows 11 آزموده شود، به‌ویژه: ترتیب تأیید (Grant) در جریان Task چندمرحله‌ای، Taint بعد از `web_*`/`read_file`، و اجرای UIA/Store از `run_fixed` (خروجی باید یک شیء JSON تک‌خطی باشد).
- **UAC (T6) روی ویندوز واقعی آزموده نشده:** مسیر `elevation.py` فقط Syntax و ثبت در رجیستری بررسی شده است. پنجره‌ی UAC نام «Windows PowerShell» (امضای Microsoft) را نشان می‌دهد نه «Kira»، چون Kira هنوز Helper امضاشده‌ی خودش را ندارد؛ توضیح دقیق عملیات در تأیید خود Kira (قبل از UAC) می‌آید.
- `ToolRegistry` خام (توسعه/تست‌های واحد) همچنان `confirmed=True` را از فراخواننده می‌پذیرد؛ فقط `ToolAgent` (برنامه‌ی واقعی) Grant اجباری می‌کند (`access.require_grants`). تست‌های قدیمی که مستقیم `confirmed=True` می‌زنند همین رفتار را می‌بینند.
- Taint ممکن است برای «جست‌وجو کن و اولین لینک را باز کن» یک تأیید اضافه بخواهد (عمدی).
- ژورنال فقط در حافظه است؛ ذخیره‌ی دائمی عمداً نیست.
- Wi-Fi، روشنایی، Wallpaper، Tray، مدیریت دستگاه‌ها، Word/Office و Clipboard کامل در این تسک ساخته نشدند؛ فقط مسیر افزودنشان آماده است.


## مسیر Administrator و UAC (T6)
Kira همیشه با دسترسی عادی کاربر اجرا می‌شود؛ هرگز Elevated شروع نمی‌شود و Elevated نمی‌ماند. تنها راه اجرای چیزی با Administrator:

1. قابلیتی با `permission=ELEVATED` (دامنه‌ی `elevated`، Backend `elevated-uac`) در `kira/tools/elevation.py`.
2. `ToolRegistry.execute()` ← مدیر مرکزی: کاربر باید **همین ابزار با همین پارامترها** را تأیید کند (Grant یک‌بارمصرف، ۵ دقیقه، Stop باطلش می‌کند). متن تأیید می‌گوید دقیقاً چه می‌شود و **چرا Administrator لازم است**. `precheck` پیش از پرسش، ورودی و وجود هدف را (با دسترسی عادی) بررسی می‌کند.
3. فقط بعد از تأیید، `ShellExecuteExW` با فعل `runas` از ویندوز UAC می‌خواهد. اگر کاربر در UAC «No» بزند، هیچ‌چیز اجرا نشده و نتیجه `user_cancelled` است؛ خودکار دوباره تلاش نمی‌شود.
4. فرایند بالارفته همان Windows PowerShell امضاشده‌ی System32 است با **بدنه‌ی ثابت و فهرست مجاز** (`OPS`). تنها بخش متغیر یک Blob به‌صورت base64 JSON است که قبلاً در Python با فهرست بسته/الگوی سخت‌گیرانه اعتبارسنجی شده و اسکریپت فقط آن را **به‌عنوان داده می‌خواند**. بدون `ExecutionPolicy Bypass`، بدون دستور آزاد، بدون فایل/Pipe قابل‌دست‌کاری: فرایند بالارفته فقط **کد خروج** می‌دهد (۰ = موفق، وگرنه HRESULT خطا).
5. کد خروج مدرک موفقیت نیست: وضعیت واقعی با یک اسکریپت ثابت **عادی (بدون Elevation)** دوباره خوانده و همان گزارش می‌شود. اگر هدف از قبل در حالت خواسته‌شده بود، UAC اصلاً درخواست نمی‌شود.

### قابلیت‌های Elevated فعلی
| ابزار | کار | محدودیت امنیتی |
|---|---|---|
| `service_restart` | Restart یک سرویس | فقط `Spooler`، `Audiosrv`، `bthserv` (فهرست بسته در `ALLOWED_SERVICES`) |
| `network_adapter_set` | فعال/غیرفعال کردن یک آداپتور شبکه | نام آداپتور با الگوی سخت‌گیرانه (بدون `* ? [ ]` و نقل‌قول)؛ هشدار قطع اینترنت هنگام غیرفعال کردن |

### آنچه عمداً **نیست**
ذخیره‌ی رمز/اعتبار Administrator، «یادآوری تأیید»، تلاش مجدد خودکار با Elevation بعد از شکست یک عملیات عادی، دور زدن UAC، Scheduled Task/سرویس دائمی، Helper همیشه‌فعال، و اجرای PowerShell آزاد. شکست یک اسکریپت PowerShell به‌تنهایی **ثابت نمی‌کند** Administrator لازم است (`needs_admin_error` فقط برای جایی است که ماژول **مطمئن** باشد).

### علت‌های خطا (`kind`) در نتیجه و ژورنال
`permission_denied` · `admin_required` · `powershell_failure` · `missing_component` · `unsupported_hardware` · `device_unavailable` · `api_failure` · `app_not_installed` · `timeout` · `user_cancelled`. ژورنال حالا برای هر عملیات این‌ها را هم دارد: `uac_required`، `uac_used`، `confirmation_required`، `verification` (`verified | unverified | not_applicable | not_run`) و `kind`. فعلاً علت‌گذاری کامل در Audio، اجراکننده‌ی PowerShell و `elevation.py` انجام شده؛ بقیه‌ی ماژول‌ها در فازهای بعد.

### برچسب Backend (اصلاح T6)
Backend صدا قبلاً «COM» نوشته می‌شد ولی کار واقعاً داخل یک اسکریپت ثابت PowerShell (که Core Audio را صدا می‌زند) اجرا می‌شود؛ حالا `powershell-fixed` ثبت می‌شود.
