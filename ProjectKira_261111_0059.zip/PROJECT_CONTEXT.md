# PROJECT_CONTEXT — Project Kira

> آخرین به‌روزرسانی: 2026-11-11 00:59 IRST · مبنا: سورس واقعی ZIP «Kira_Neon_UI_Stage2» + تغییرات UI مرحله سوم (VERSION = `"1 stable"` در `kira/config.py`)
> این فایل با `ARCHITECTURE.md`، `CHANGELOG.md` و `TASK_HANDOFF.md` یک مجموعه‌اند.

## قانون کار برای هر سشن Claude (اجباری)
1. **اول هر چهار فایل را بخوان** (`PROJECT_CONTEXT.md`, `ARCHITECTURE.md`, `CHANGELOG.md`, `TASK_HANDOFF.md`) در ریشه‌ی پروژه.
2. برای شناخت پروژه **کل سورس را دوباره نخوان**. فقط فایل‌های مرتبط با تسک جاری را بخوان.
3. اگر مستندات با کد تناقض داشتند، **کد ملاک است**؛ مستند را اصلاح کن.
4. **پایان هر تسک:** هر چهار فایل را مرور کن و فقط بخش‌هایی را عوض کن که تسک واقعاً روی آن‌ها اثر گذاشته (قابلیت/معماری ← این فایل و ARCHITECTURE؛ نسخه/فایل‌ها/تست‌ها ← CHANGELOG؛ وضعیت و ادامه ← TASK_HANDOFF). بازنویسی بی‌دلیل ممنوع.
5. اطلاعات حدسی یا پیاده‌نشده را «قابلیت موجود» ثبت نکن. هر چیز تست‌نشده برچسب `IMPLEMENTED_UNTESTED` می‌گیرد.
6. نام ZIP خروجی با تاریخ میلادی و ساعت ایران به‌روز می‌شود. **قالب فعلی (دستور کاربر، 2026-11-10):** `ProjectKira_YYMMDD_HHMM.zip` (دستور: `TZ=Asia/Tehran date '+%y%m%d_%H%M'`؛ مثال: `ProjectKira_261110_1216.zip`). ZIP Release **هرگز** `.venv`، `.uvboot`، `__pycache__`، `.ruff_cache` و `data/` نمی‌گیرد. تغییر قالب فقط با دستور صریح کاربر.

## Kira چیست؟
همراه دیجیتال انیمه‌ای برای **Windows 11** (دسکتاپ، PySide6). چت با مدل‌های محلی (Ollama) و ابری (Groq، Mistral، Google AI Studio/Gemini، Cloudflare، OpenRouter، OpenAI-compatible سفارشی)، با حافظه، صدا (STT/TTS)، ضمیمه، جست‌وجو و تحقیق وب، و یک لایه‌ی «ابزار/ایجنت» که روی خود ویندوز کار می‌کند (با سطح دسترسی و تأیید). زبان محصول فارسی است؛ **کد، کامنت و پرامپت‌های جدید انگلیسی نوشته می‌شوند** و فقط متن نمایش‌داده‌شده به کاربر فارسی است (قانون v7).

- پایتون 3.11/3.12 · وابستگی‌ها: `PySide6>=6.7,<7`, `requests`, `numpy`, `psutil` (اختیاری). بسته‌های اضافه‌ای که `install.bat` نصب می‌کند (نه در requirements.txt): `Pillow`، `sounddevice`، `edge-tts`، `SpeechRecognition`، و (بسته به نسخه‌ی پایتون) `miniaudio`، `faster-whisper`. `pypdf` فقط برای خواندن PDF لازم است و نصب خودکار ندارد.
- اجرا: `install.bat` ← `start_kira.bat`. تست: `run_tests.bat` یا `python -m unittest discover -s tests -t .`
- داده‌ی کاربر **خارج از پوشه‌ی برنامه** است: `%LOCALAPPDATA%\Kira` (`DATA_DIR`، با `KIRA_DATA_DIR` قابل override؛ تست‌ها از آن استفاده می‌کنند). کلیدهای API با DPAPI محافظت می‌شوند (`secret_store.py`).

## قابلیت‌های موجود (از سورس تأیید شده)
وضعیت «تست‌شده» = تست واحد روی لینوکس پاس شده. یک اجرای واقعی `run_tests.bat` روی ویندوز (483 تست، 15 مورد ناموفق) انجام شده و علت همه بررسی/رفع شد (Win-Fix-1)، ولی **بعد از اصلاح‌ها دوباره روی ویندوز اجرا نشده**؛ قابلیت‌های Win32/GUI تأییدشده‌ی کامل نیستند؛ همه‌ی قابلیت‌های Win32/UIA/PowerShell/Ollama واقعی `IMPLEMENTED_UNTESTED` هستند.

| حوزه | چه چیزی هست | ماژول‌ها |
|---|---|---|
| چت و مدل | استریم، Failover، Cooldown، متریک سرعت، Route/Provider جدا، مدل‌های ابری+محلی، function calling بومی (Groq/Mistral/Google؛ ترجمه به همان پروتکل متنی) | `hybrid_ai.py`, `routes.py`, `ollama_client.py`, `leak_guard.py` |
| API / Route Manager | افزودن کلید با تشخیص خودکار سرویس و مدل‌ها، اولویت، فعال/غیرفعال، تست اتصال، Benchmark | `api_manager.py`, `discovery.py`, `routes.py`, UI در `main.py` |
| شخصیت و حالت | شخصیت ثابت مستقل از مدل، Active Mode (CHAT/TASK/STRICT)، خلق‌وخو، سنجش «Kira ماندن» پاسخ | `personality.py`, `modes.py`, `mood.py`, `style_probe.py` |
| حافظه | تاریخچه‌ی SQLite با بازیابی/پشتیبان؛ حافظه‌ی شخصیت (صدا/واقعیت/لحظه/عادت/خلاصه)؛ **حافظه‌ی شواهدمحور** (BM25 + Embedding اختیاری + RRF، قرنطینه) | `memory.py`, `persona_memory.py`, `evidence_memory.py`, `storage.py` |
| مغز چندمرحله‌ای | نقش‌های surface/deep/reflection/memory، route جدا برای هر نقش، reflection رایگان با قواعد | `brain.py`, `smart.py`, `modelbench.py` |
| ابزارها | **117 ابزار** داخلی (شمارش از `build_registry`، بدون MCP): فایل 21، تنظیمات 17، سیستم 16، برنامه‌ها 15، دسکتاپ 15، صدا 11، شبکه 8، دستگاه 4، وب 4، بلوتوث 3، تصویر 2، زمان 1 | `kira/tools/*` |
| Agent / Planner | حلقه‌ی ابزار + برنامه‌ریزی چندگامی، اجرای گام‌به‌گام، Verification، Replan، ذخیره‌ی وضعیت وظیفه، توقف/ادامه/لغو | `tools/agent.py`, `autonomy.py`, `planner.py`, `tasks.py` |
| دسترسی/امنیت | سطوح READ / CONTROL / FILE / ELEVATED / PROTECTED، قفل «درخواست صریح»، taint، تأیید یک‌بارمصرف، ژورنال، UAC فقط برای یک عملیات | `tools/sysaccess.py`, `registry.py`, `elevation.py`, `access.py` |
| ویندوز | برنامه‌ها (باز/بستن)، صدا، بلوتوث، دسکتاپ (پنجره/کیبورد/ماوس/کلیپ‌بورد/UIA)، تنظیمات کاربر، شبکه/Wi-Fi، دستگاه‌ها، Power، پردازش‌ها، نرم‌افزارها | `tools/apps.py`, `appclose.py`, `audio.py`, `bluetooth.py`, `desktop.py`, `settings.py`, `network.py`, `devices.py`, `power.py`, `processes.py`, `appmanage.py` |
| فایل | جست‌وجو/خواندن؛ عامل فایل (ساخت/کپی/تغییر نام/مرتب‌سازی/دسته‌ای/undo، حذف فقط به سطل بازیافت)؛ فایل‌های بزرگ/تکراری | `tools/fileops.py`, `fileagent.py`, `files_insight.py` |
| وب | جست‌وجوی سریع (Tavily ← Gemini/Google ← DuckDuckGo)؛ تحقیق چندمنبعی بدون فراخوانی مدل با SSRF-guard؛ جست‌وجوی تصویری | `websearch.py`, `webintel/*`, `tools/webtools.py` |
| MCP و ایجنت خارجی | کلاینت MCP (stdio/HTTP)، ثبت ابزار `server__tool`، ایجنت‌های مستقل با HTTP | `mcp/*` |
| مصرف | دفتر مصرف/هزینه و محدودیت per-role/provider، دستور `/usage` | `usage.py` |
| تجربه | Episode + Lesson + Skill + few-shot Example، همگی محلی و محتاطانه | `experience.py` |
| صدا | TTS (Edge/ویندوز/Cloud)، STT (Whisper محلی/Cloud: Google AI Studio، Groq، ElevenLabs)، VAD، قطع‌کردن Kira، جمله‌به‌جمله | `voice.py`, `listener.py`, `vad.py`, `cloud_voice.py`, `cloud_voice_ui.py`, `speech_*.py` |
| تصویر | تولید تصویر/GIF (۲–۸ فریم) با هر API دارای مدل تصویر | `imagegen.py`, `tools/imagetool.py` |
| UI و آواتار | پنجره‌ی اصلی + نوار ناوبری واکنش‌گرا، چت با قالب کد/نقل‌قول و کپی پیام، نشانگر پردازش، اسکرول نرم، حالت Tray (حباب چت)، موتور احساس/انیمیشن PNG soft-body، تم، Mica/Acrylic | `main.py`, `chat_render.py`, `companion.py`, `face.py`, `rig.py`, `emotion/*`, `theme.py`, `winfx.py` |

### آنچه عمداً/هنوز **نیست**
- باز کردن PowerShell/Terminal/CMD با `open_app` (در `BLOCKED_EXES`)؛ حافظه‌ی «سؤال باز»؛ نتیجه‌ی یکنواخت `success/failed/partial/unknown` برای همه‌ی ابزارها (فقط بخشی از ابزارها `set_verification` را می‌زنند).
- Word/Office، اسکرین‌شات و بینایی روی دسکتاپ، کلید Windows/میانبرهای سیستمی.
- UI برای `role_routes`، مصرف، تنظیمات Embedding و حافظه‌ی تجربی (تنظیم فقط از `settings.json`).
- اجرای خودکار Skill از Planner؛ Self-Evaluation مبتنی بر داور؛ ثبت MCP/ایجنت توسط مدل؛ OAuth برای MCP.
- مهاجرت از PowerShell ثابت (صدا/بلوتوث/UIA) — فهرست منجمد در `docs/TECH_DEBT_FA.md`.

## ساختار پوشه‌ها
```
/                    README.md, requirements.txt, install.bat, start_kira.bat, run_tests.bat, download_model.bat, install_deps.py, reactions.json (+ این ۴ مستند)
kira/                هسته (حدود 32.8k خط؛ main.py حدود 3.7k خط)
kira/tools/          سیستم ابزار: registry، protocol، agent/autonomy/planner/tasks، sysaccess، ماژول‌های ویندوز و فایل
kira/webintel/       موتور تحقیق وب (engine, rank, extract, netguard, session)
kira/mcp/            MCP client/hub/config و ایجنت‌های مستقل
kira/emotion/        موتور احساس (parser, director, engine, library, backend_png)
emotion_library/     JSON های احساس/رویداد/ترکیب/قواعد/انیمیشن آواتار (بدون کد اجرایی)
assets/              kira_character.png، reference/ (front/side/back)، sounds/ (فقط .keep)
docs/                راهنماهای فارسی هر زیرسیستم (*_FA.md) + kira_mcp.example.json
tests/               38 فایل Python در tests (524 تست روی لینوکس؛ 79 تا skip در محیط بدون PySide6؛ اجرای مجدد کامل روی ویندوز لازم است)
```
در `.ruff_cache/` فقط کش ابزار است؛ نادیده بگیر.

## وظایف ماژول‌های اصلی (خلاصه)
- `main.py` — `MainWindow` (UI، ارسال پیام، `start_worker`، `on_stream_done`)، `StreamWorker`/`AttachWorker`/`SearchWorker`/`TaskWorker`/`BenchWorker`/`CapWorker` (QThread)، دیالوگ‌ها. **همه‌ی سیم‌کشی ماژول‌ها اینجاست.**
- `config.py` — `DEFAULTS`، بارگذاری/ذخیره‌ی `settings.json`، مهاجرت تنظیمات قدیمی.
- `hybrid_ai.py` — `HybridRouter` + Providerها؛ `routes.py` — منطق خالص Route (بدون Qt).
- `brain.py` — تصمیم نقش/route/پرامپت و reflection بعد از پاسخ. `smart.py` — انتخاب بهترین route، follow-up، اصلاح‌های کاربر، تشخیص «بهانه».
- `tools/registry.py` — تعریف/اعتبارسنجی/اجرای ابزار. `tools/sysaccess.py` — تنها تصمیم‌گیر دسترسی. `tools/protocol.py` — پروتکل متنی `<kira_tool>` و دروازه‌ی دسته‌ها.
- `tools/agent.py` (`ToolAgent`) + `autonomy.py` (`AutonomyMixin`: برنامه‌ریزی) + `planner.py` + `tasks.py` (`TaskStore`, `verify`, `classify_error`).
- `experience.py` — حافظه‌ی تجربی. `evidence_memory.py`/`persona_memory.py`/`memory.py` — لایه‌های حافظه.

جزئیات اتصال‌ها: `ARCHITECTURE.md`. تاریخچه: `CHANGELOG.md`. وضعیت و ادامه: `TASK_HANDOFF.md`. راهنماهای تفصیلی هر بخش: `docs/*_FA.md`.
