# Kira UI redesign

## Current pass: navigation and responsive shell

- Replaced the two-icon-plus-overflow-menu navigation with a persistent navigation rail exposing all six main destinations: Chat, Assistant, Voice, Character, General settings, and Routes.
- Added dedicated line icons for Assistant, Voice, Character, and Settings.
- Kept the existing `QTabWidget` as the page stack. Page construction, settings storage, route handling, and feature callbacks remain in place.
- Added a compact rail mode for narrow windows. It switches to icon-only navigation and hides secondary labels; the avatar panel also collapses sooner to preserve chat width.
- Moved the existing Save settings action into the navigation rail and retained its original callback and visibility rule.
- Added Persian/English localization for the navigation section heading and registered nav labels/tooltips with the existing translation mechanism.
- Added a consistent dark-glass rail surface and active/hover states to the shared theme.

## Safety boundaries

This pass changes presentation and navigation only. It does not change provider credentials, route priority, model selection, chat persistence, memory, voice, or tool execution logic.

## Verification

- `python -m compileall -q kira` passed.
- `git diff --check` passed.
- 58 targeted unit tests passed; 3 were skipped because PySide6 is unavailable in this build environment or the test requires Windows DPAPI.
- GUI rendering and interactive resize behavior still need a run on the Windows 11 target machine with the project's installed PySide6 dependencies.
